<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:p="http://www.sec.gov/edgar/seventeenhfiler"
    xmlns:p1="http://www.sec.gov/edgar/common">

	<xsl:template name="part2_4">
		<table role="presentation">
			<tr>
				<th>		
					<h4 class="title1">IV. FUNDING SOURCES</h4>
				</th>
				<th class="titleLong"><b>(000's omitted)</b></th>
			</tr>
			<!-- 1. -->
			<tr>
				<td class="label">
					1. Short-term borrowings:
				</td>
				<td>&#160;</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
					(a) Commercial paper
					</blockquote>
				</td>
				<td class="responseLong">
					<div class="fakeBox2">
						<xsl:value-of select="p:partTwoIV/p:shortTermBorrowings/p:commercialPaper"/>
					</div>
				</td>
				<td>[4000]</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
					(b) Bank loans-secured
					</blockquote>
				</td>
				<td class="responseLong">
					<div class="fakeBox2">
						<xsl:value-of select="p:partTwoIV/p:shortTermBorrowings/p:bankLoansSecured"/>
					</div>				
				</td>
				<td>[4005]</td>				
			</tr>
			<tr>
				<td class="label">
					<blockquote>
					(c) Bank loans-unsecured
					</blockquote>
				</td>
				<td class="responseLong">
					<div class="fakeBox2">
						<xsl:value-of select="p:partTwoIV/p:shortTermBorrowings/p:bankLoansUnSecured"/>
					</div>
				</td>
				<td>[4015]</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
					(d) Other
					</blockquote>
				</td>
				<td class="responseLong">
					<div class="fakeBox2">
						<xsl:value-of select="p:partTwoIV/p:shortTermBorrowings/p:other"/>
					</div>				
				</td>
				<td>[4020]</td>				
			</tr>
			<tr>
				<td class="label">
					<blockquote>
					(e) Total
					</blockquote>
				</td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="p:partTwoIV/p:shortTermBorrowings/p:total"/>
					</div>
				</td>
				<td>[4025]</td>			
			</tr>
			<!-- 2. -->
			<tr>
				<td class="label">
					2. Long and medium-term debt
				</td>
				<td class="responseLong">
					<div class="fakeBox2">
						<xsl:value-of select="p:partTwoIV/p:longMediumTermDebt"/>
					</div>
				</td>
				<td>[4030]</td>
			</tr>
			<!-- 3. -->
			<tr>
				<td class="label">
					3. Committed lines of credit
				</td>
				<td class="responseLong">
					<div class="fakeBox2">
						<xsl:value-of select="p:partTwoIV/p:committedLinesCredit"/>
					</div>				
				</td>
				<td>[4035]</td>					
			</tr>
			<!-- 4. -->
			<tr>
				<td class="label">
					4. Amounts borrowed under credit lines
				</td>
				<td class="responseLong">
					<div class="fakeBox2">
						<xsl:value-of select="p:partTwoIV/p:amountsBorrowedUnderCreditLines"/>
					</div>
				</td>
				<td>[4040]</td>
			</tr>		
			<!-- 5. -->
			<tr>
				<td class="label">
					5. Credit ratings for commercial paper:
				</td>
				<td>&#160;</td>
				<td>&#160;</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
					(a) Standard &amp; Poor’s Corporation
					</blockquote>
				</td>
				<td class="responseLong">
					<div class="fakeBox2">
						<xsl:value-of select="p:partTwoIV/p:creditRatingsCommercialPaper/p:standardPoorCorporation"/>
					</div>
				</td>
				<td>[4045]</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
					(b) Moody’s Investor Service
					</blockquote>
				</td>
				<td class="responseLong">
					<div class="fakeBox2">
						<xsl:value-of select="p:partTwoIV/p:creditRatingsCommercialPaper/p:moodyInvestorService"/>
					</div>				
				</td>				
				<td>[4050]</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
					(c) Other Nationally Recognized Statistical Rating Organizations
					</blockquote>
				</td>
				<td class="responseLong">
					<div class="fakeBox2">
						<xsl:value-of select="p:partTwoIV/p:creditRatingsCommercialPaper/p:otherNationallyRecognizedOrganizations"/>
					</div>
				</td>
				<td>[4055]</td>
			</tr>						
		</table>													
	</xsl:template>
</xsl:stylesheet>
<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:p="http://www.sec.gov/edgar/seventeenhfiler"
    xmlns:p1="http://www.sec.gov/edgar/common">

	<xsl:template name="part2_5">
		<table role="presentation">
			<tr>
				<th>		
					<h4 class="title1">V. REAL ESTATE</h4>
				</th>
				<th class="titleLong"><b>(000's omitted)</b></th>
			</tr>
			<!-- 1. -->
			<tr>
				<td class="label">
					1. Real estate loans:
				</td>
				<td>&#160;</td>
				<td>&#160;</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
					(a) Construction and land development
					</blockquote>
				</td>
				<td class="responseLong">
					<div class="fakeBox2">
						<xsl:value-of select="p:partTwoV/p:realEstateLoans/p:constructionLandDevelopment"/>
					</div>
				</td>
				<td>[5000]</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
					(b) Secured by farmland
					</blockquote>
				</td>
				<td class="responseLong">
					<div class="fakeBox2">
						<xsl:value-of select="p:partTwoV/p:realEstateLoans/p:securedByFarmland"/>
					</div>				
				</td>
				<td>[5005]</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
					(c) Secured by residential properties
					</blockquote>
				</td>
				<td class="responseLong">
					<div class="fakeBox2">
						<xsl:value-of select="p:partTwoV/p:realEstateLoans/p:securedByResidentialProperties"/>
					</div>
				</td>
				<td>[5015]</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
					(d) Commercial and industrial
					</blockquote>
				</td>
				<td class="responseLong">
					<div class="fakeBox2">
						<xsl:value-of select="p:partTwoV/p:realEstateLoans/p:commercialAndIndustrial"/>
					</div>				
				</td>
				<td>[5020]</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
					(e) Other
					</blockquote>
				</td>
				<td class="responseLong">
					<div class="fakeBox2">
						<xsl:value-of select="p:partTwoV/p:realEstateLoans/p:other"/>
					</div>
				</td>
				<td>
					[5025]
				</td>			
			</tr>
			<!-- 2. -->
			<tr>
				<td class="label">
					2. Real estate investments:
				</td>
				<td>&#160;</td>
				<td>&#160;</td>
				<td>&#160;</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
					(a) Construction and land development
					</blockquote>
				</td>
				<td class="responseLong">
					<div class="fakeBox2">
						<xsl:value-of select="p:partTwoV/p:realEstateInvestments/p:constructionLandDevelopment"/>
					</div>
				</td>
				<td>
					[5030]
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
					(b) Farmland
					</blockquote>
				</td>
				<td class="responseLong">
					<div class="fakeBox2">
						<xsl:value-of select="p:partTwoV/p:realEstateInvestments/p:securedByFarmland"/>
					</div>				
				</td>
				<td>
					[5035]
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
					(c) Residential properties
					</blockquote>
				</td>
				<td class="responseLong">
					<div class="fakeBox2">
						<xsl:value-of select="p:partTwoV/p:realEstateInvestments/p:securedByResidentialProperties"/>
					</div>
				</td>
				<td>
					[5040]
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
					(d) Commercial and industrial
					</blockquote>
				</td>
				<td class="responseLong">
					<div class="fakeBox2">
						<xsl:value-of select="p:partTwoV/p:realEstateInvestments/p:commercialAndIndustrial"/>
					</div>				
				</td>
				<td>
					[5045]
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
					(e) Other
					</blockquote>
				</td>
				<td class="responseLong">
					<div class="fakeBox2">
						<xsl:value-of select="p:partTwoV/p:realEstateInvestments/p:other"/>
					</div>
				</td>
				<td>[5050]</td>
			</tr>	
			<!-- 3. -->
			<tr>
				<td class="label">
					3. Provide a separate listing of the above information by geographic region 
					where the amount exceeds the Materiality Threshold (attach schedule).  
				</td>
				<td>&#160;</td>
				<td>&#160;</td>
			</tr>
			<!-- 3. -->
			<tr>
				<td class="label">
					Attach / Remove / View Part II.V.3 
				</td>
				<td>&#160;</td>
				<td>&#160;</td>
			</tr>
			<!-- 4. -->
			<tr>
				<td class="label">
					4. Provide information about risk concentration to a single borrower, location 
					or property in the investment or loan portfolio where the amount exceeds the 
					Materiality Threshold (attach schedule). 
				</td>
				<td>&#160;</td>
				<td>&#160;</td>
			</tr>
			<!-- 4. -->
			<tr>
				<td class="label">
					Attach / Remove / View Part II.V.4
				</td>
				<td>&#160;</td>
				<td>&#160;</td>
			</tr>			
		</table>	
		<h4 class="title1">
			ADDITIONAL SPACE FOR ANSWERS
		</h4>
		<div class="information">
			<p>
				The Material Associated Person may attach a document if necessary, to provide 
				further information or explanation regarding any item of information required 
				by the Form. Include the name of the Material Associated Person on each page 
				and specify the paragraph of the Form to which the additional information relates.
			</p>
		</div>
		<p>
			Attach / Remove / View for Additional Space For Answers
		</p>
	</xsl:template>
</xsl:stylesheet>
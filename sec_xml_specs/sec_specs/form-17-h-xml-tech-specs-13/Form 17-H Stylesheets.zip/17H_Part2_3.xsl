<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:p="http://www.sec.gov/edgar/seventeenhfiler"
    xmlns:p1="http://www.sec.gov/edgar/common">

	<xsl:template name="part2_3">
		<table role="presentation" id="part2">
			<tr>
				<th>&#160;</th>
				<th class="titleLong"><br/><b>(000's omitted)</b></th>
			</tr>
			<tr>
				<th colspan="3">		
					<h4 class="title1">III. BRIDGE LOANS AND OTHER EXTENSIONS OF CREDIT</h4>
				</th>
			</tr>
			<!-- 1. -->
			<tr>
				<td class="label">
					1. Bridge loans
				</td>
				<td class="responseLong">
					<div class="fakeBox2">
						<xsl:value-of select="p:partTwoIII/p:bridgeLoans"/>
					</div>
				</td>
				<td>
					[3000]
				</td>
			</tr>
		</table>					
		<!-- 2. -->
		<table role="presentation" id="part2">
			<tr>
				<td class="label">
					2.  Other material credit extensions
					<br/><br/>
					<blockquote>
						Note: This item has two data collection fields: 
						<br/>
						<blockquote>
							1) a text field for "(specify)" and 
							<br/>
							2) a numeric field for the amount.
						</blockquote>
					</blockquote>
				</td>
				<td class="responseLong">
					&#160;
				</td>
				<td>&#160;</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
					(specify)
					</blockquote>
				</td>
				<td class="responseLong" colspan="4">
					<div class="fakeBox3">
						<xsl:value-of select="p:partTwoIII/p:otherMaterialCreditExtensionDec"/>
					</div>
				</td>
			</tr>
		</table>
		<table role="presentation">
			<tr>
				<td class="label">
					&#160;
				</td>
				<td class="responseLong">
					<div class="fakeBox2">
						<xsl:value-of select="p:partTwoIII/p:otherMaterialCreditExtension"/>
					</div>
				</td>
				<td>
					[3005]
				</td>
			</tr>					
			<!-- 3. -->
			<tr>
				<td class="label">
					3. Allowance for losses for credit extensions
				</td>
				<td class="responseLong">
					<div class="fakeBox2">
						<xsl:value-of select="p:partTwoIII/p:allowanceForLossesForCreditExtensions"/>
					</div>
				</td>
				<td>
					[3015]
				</td>
			</tr>																					
		</table>													
	</xsl:template>
</xsl:stylesheet>
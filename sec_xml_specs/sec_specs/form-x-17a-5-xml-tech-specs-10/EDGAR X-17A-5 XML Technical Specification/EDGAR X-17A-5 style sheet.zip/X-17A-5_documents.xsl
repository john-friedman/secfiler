<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0" 
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:p="http://www.sec.gov/edgar/seventeenafiler" 
	xmlns:p1="http://www.sec.gov/edgar/common">

	<!-- Documents templates -->
    
	<xsl:template name="Documents">		
		<h3>
			<em>Documents</em>
		</h3>
		<xsl:call-template name="InvisibleDocumentsInfo"/>
	</xsl:template>

	<xsl:template name="InvisibleDocumentsInfo">
		<table role="presentation">
			<tr>
				<td class="label">File Name:
				</td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="p1:conformedName" />
					</div>
				</td>
			</tr>
			<tr>
                <td class="label">Type:
                </td>
                <td>
                    <div class="fakeBox">
                        <xsl:value-of select="p1:conformedDocumentType" />
                    </div>
                </td>
            </tr>
            <tr>
                <td class="label">Contents:
                </td>
                <td>
                    <div class="fakeBox">
                        <xsl:value-of select="p1:contents" />
                    </div>
                </td>
            </tr>
            <tr>
                <td class="label">Confidentiality:
                </td>
                <td>
					<xsl:choose>
						<xsl:when test="p1:confidentiality = 'true'">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:otherwise>
					</xsl:choose>
                </td>
            </tr>			
		</table>
	</xsl:template>
</xsl:stylesheet>
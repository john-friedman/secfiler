<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:cf="http://www.sec.gov/edgar/crowdfunding"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:ns1="http://www.sec.gov/edgar/common"
	xmlns:ns2="http://www.sec.gov/edgar/statecodes" 
	xmlns:ns3="http://www.sec.gov/edgar/common_drp">

	<xsl:template name="scheduleA">
		<h1>FORM FUNDING PORTAL SCHEDULE A</h1>
		<h4 class="title1">Direct Owners and Executive Officers</h4>	
		<div class="informationNoBorder">
			<ul style="list-style-type:none;">
				<li>
					<b>1. Complete Schedule A only if submitting an initial application.</b>
					Schedule A asks for information about the applicant's direct 
					owners and executive officers.  Use Schedule B to amend this information.
					<br/><br/>
					<blockquote>
						<b>Guidance:</b> To determine direct ownership and executive officer status, 
						see instruction 2 below.
					</blockquote>
				</li>
				<br/>
				<li>
					<b>2. Direct Owners and Executive Officers.</b> List below  the names of:
					<div class="information" style="padding:5px">
						(a) each Chief Executive Officer, Chief Financial Officer, Chief Operations Officer, 
						Chief Legal Officer, Chief Compliance Officer, director and any other individuals with 
						similar status or functions;
						<br/><br/>
						(b) <b>if <em>applicant</em> is organized as a corporation,</b> each shareholder that is 
						a direct owner of 5% or more of a class of the <em>applicant'</em>s voting securities, 
						unless <em>applicant</em> is a public reporting company (a company subject to Section 13 
						or 15(d) of the Exchange Act); 
						<br/><br/>
						<blockquote>
							<b>Direct owners include</b> any <i>person</i> that owns, beneficially owns, has the 
							right to vote, or has the power to sell or direct the sale of 5% or more of a class 
							of the <i>applicant</i>'s voting securities. For purposes of this Schedule, a 
							<i>person</i> beneficially owns any securities:  (i) owned by his/her child, 
							stepchild, grandchild, parent, stepparent, grandparent, spouse, sibling, mother-in-law, 
							father-in-law, son-in-law, daughter-in-law, brother-in-law, or sister-in-law, sharing 
							the same residence; or (ii) that he/she has the right to acquire, within 60 days, through 
							the exercise of any option, warrant, or right to purchase the security.
						</blockquote>
						<br/><br/>
						(c) <b>if the <i>applicant</i> is organized as a partnership, </b> <u>all</u> general partners 
						and those limited and special partners that have the right to receive upon dissolution, 
						or have contributed, 5% or more of the <em>applicant'</em>s capital.
						<br/><br/>
						(d) <b>in the case of a trust,</b> (i) a <em>person</em> that directly owns 5% or more 
						of a class of the <em>applicant'</em>s voting securities, or that has the right to receive upon 
						dissolution, or has contributed, 5% or more of the <em>applicant'</em>s capital, 
						(ii) the trust and (iii) each trustee; and
						<br/><br/>
						(e) <b>if the applicant is organized as a limited liability company ("LLC"),</b> 
						(i) those members that have the right to receive upon dissolution, or have contributed, 
						5% or more of the applicant's capital, and (ii) if managed by elected managers, all elected managers.
					</div>
				</li>
				<br/>
				<li>
					<b>3. In the DE/FE/NP column</b> below, enter "DE" if the owner is a domestic entity, "FE" if the owner 
					is an entity incorporated or domiciled in a foreign country, or "NP" if the owner or executive officer is a natural person.
				</li>
				<br/>
				<li>
					<b>4. Complete the Title or Status column</b> by entering board/management titles; status as partner, 
					trustee, sole proprietor, elected manager, shareholder, or member; and for shareholders or members, 
					the class of securities owned (if more than one is issued).
				</li>
				<br/>
				<li>
					<b>5. Ownership codes are:</b>
					<blockquote>
						<ul style="list-style-type: circle">
							<li>NA &ndash; less than 5%</li>
							<li>A &ndash; 5% but less than 10%</li>
							<li>B &ndash; 10% but less than 25%</li>
							<li>C &ndash; 25% but less than 50%</li>
							<li>D &ndash; 50% but less than 75%</li>
							<li>E &ndash; 75% or more</li>
							<li>G &ndash; Other (general partner, trustee, or elected member)</li>
						</ul>
					</blockquote>
				</li>
				<br/>
				<li>
					<b>6. Control Person:</b>
					<br/>
					<blockquote><b>(a) In the Control Person column</b>, enter "Yes" if the <em>person</em> has <em>control</em> 
						as defined in the Glossary of Terms to Form Funding Portal, and enter "No" if the <em>person</em> 
						does not have <em>control</em>. Note that under this definition, most executive officers and all 
						25% owners, general partners, elected managers, and trustees are "control persons".
						<br/>
						<b>(b) In the PR column,</b> 
						enter "PR" if the owner is a public reporting company under Section 13 or 15(d) of the Exchange Act.
					</blockquote>
				</li>
				<br/>
			</ul>		
		</div>
		<h4 class="titleNumber">Complete each of the following:</h4>
		<xsl:for-each select="cf:scheduleA/cf:entityOrNaturalPerson">
			<table role="presentation" id="scheduleA_filingInformation">
				<tr>
					<td class="label">
						<b>FULL LEGAL NAME (Natural Persons: Last Name, First Name, Middle Name)</b>
					</td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="cf:fullLegalName"/>
						</div>
					</td>
				</tr>
				<tr>
					<td class="label">
						<b>Domestic Entity/Foreign Entity (entity organized, incorporated, or domiciled in a foreign country)/Natural Person:</b>
					</td>
					<td>
						<table role="presentation">
							<tr>
								<td>
									<xsl:choose>
										<xsl:when test="contains(cf:entityType, 'DE')">
											<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
										</xsl:when>
										<xsl:otherwise>
											<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
										</xsl:otherwise>
									</xsl:choose>&#160;DE (Domestic Entity)&#160;&#160;
									<xsl:choose>
										<xsl:when test="contains(cf:entityType, 'FE')">
											<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
										</xsl:when>
										<xsl:otherwise>
											<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
										</xsl:otherwise>
									</xsl:choose>&#160;FE (Foreign Entity)&#160;&#160;
									<xsl:choose>
										<xsl:when test="contains(cf:entityType, 'NP')">
											<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
										</xsl:when>
										<xsl:otherwise>
											<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
										</xsl:otherwise>
									</xsl:choose>&#160;NP (Natural Person)
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td class="label"><b>Title or Status</b></td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="cf:titleStatus"/>
						</div>
					</td>
				</tr>	
				<tr>
					<td class="label"><b>Date Title or Status Acquired(MM/YYYY)</b></td>
					<td>
						<div class="fakeBox2">
							<xsl:value-of select="cf:dateOfTitleStatusAcquired"/>
						</div>
					</td>
				</tr>			
				<tr>
					<td class="label"><b>Ownership Code</b></td>
					<td>
						<table role="presentation">
							<tr>
								<td>
									<xsl:choose>
										<xsl:when test="cf:ownershipCode = 'NA'">
											<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
										</xsl:when>
										<xsl:otherwise>
											<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
										</xsl:otherwise>
									</xsl:choose>&#160;NA-less than 5%
								</td>
								<td>
									<xsl:choose>
										<xsl:when test="cf:ownershipCode = 'A'">
											<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
										</xsl:when>
										<xsl:otherwise>
											<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
										</xsl:otherwise>
									</xsl:choose>&#160;A-5% but less than 10%
								</td>									
								<td>
									<xsl:choose>
										<xsl:when test="cf:ownershipCode = 'B'">
											<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
										</xsl:when>
										<xsl:otherwise>
											<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
										</xsl:otherwise>
									</xsl:choose>&#160;B-10% but less than 25%
								</td>																		
							</tr>
							<tr>
								<td>
									<xsl:choose>
										<xsl:when test="cf:ownershipCode ='C'">
											<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
										</xsl:when>
										<xsl:otherwise>
											<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
										</xsl:otherwise>
									</xsl:choose>&#160;C-25% but less than 50%
								</td>
								<td>
									<xsl:choose>
										<xsl:when test="cf:ownershipCode = 'D'">
											<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
										</xsl:when>
										<xsl:otherwise>
											<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
										</xsl:otherwise>
									</xsl:choose>&#160;D-50% but less than 75%
								</td>									
								<td>
									<xsl:choose>
										<xsl:when test="cf:ownershipCode = 'E'">
											<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
										</xsl:when>
										<xsl:otherwise>
											<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
										</xsl:otherwise>
									</xsl:choose>&#160;E-75% or more
								</td>																		
							</tr>		
							<tr>
								<td colspan="3">
									<xsl:choose>
										<xsl:when test="cf:ownershipCode ='G'">
											<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
										</xsl:when>
										<xsl:otherwise>
											<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
										</xsl:otherwise>
									</xsl:choose>&#160;G - Other (general partner, trustee, or elected member)
								</td>
							</tr>								
						</table>
					</td>
				</tr>
				<tr>
					<td class="label"><b>Control Person</b></td>
					<td>
						<table role="presentation">
							<tr>
								<td>
									<xsl:choose>
										<xsl:when test="cf:controlPerson = 'Y'">
											<img src="Images/radio-checked.jpg" alt="Radio button checked"/> 
										</xsl:when>
										<xsl:otherwise>
											<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
										</xsl:otherwise>
									</xsl:choose>&#160;Yes&#160;
									<xsl:choose>
										<xsl:when test="cf:controlPerson = 'N'">
											<img src="Images/radio-checked.jpg" alt="Radio button checked"/> 
										</xsl:when>
										<xsl:otherwise>
											<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
										</xsl:otherwise>
									</xsl:choose>&#160;No
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td class="label">PR</td>
					<td>
						<table role="presentation">
							<tr>
								<td>
									<xsl:choose>
										<xsl:when test="cf:pr = 'PR'">
											<img src="Images/box-checked.jpg" alt="Checkbox checked" />
										</xsl:when>
										<xsl:otherwise>
											<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
										</xsl:otherwise>
									</xsl:choose>&#160;PR
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td class="label">CRD No</td>
					<td>
						<div class="fakeBox2">
							<xsl:value-of select="cf:crdNumber"/>
						</div>
					</td>
				</tr>			
				<tr>
					<td class="label">IRS Tax No.</td>
					<td>
						<div class="fakeBox2">
							<xsl:value-of select="cf:irsTaxNumber"/>
						</div>
					</td>
				</tr>				
				<tr>
					<td class="label">IRS Employer ID No.</td>
					<td>
						<div class="fakeBox2">
							<xsl:value-of select="cf:irsTaxEmployerIdNumber"/>
						</div>
					</td>
				</tr>							
			</table>
		</xsl:for-each>	
	</xsl:template>
	
</xsl:stylesheet>
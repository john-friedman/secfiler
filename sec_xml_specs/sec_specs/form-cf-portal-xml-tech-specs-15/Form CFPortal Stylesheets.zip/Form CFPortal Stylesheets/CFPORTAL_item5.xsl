<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:cf="http://www.sec.gov/edgar/crowdfunding"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:ns1="http://www.sec.gov/edgar/common"
	xmlns:ns2="http://www.sec.gov/edgar/statecodes" 
	xmlns:ns3="http://www.sec.gov/edgar/common_drp">

	<xsl:template name="tab5">
		<h1><xsl:value-of select="$submissionType"/>: Disclosure Information</h1>
		<div class="informationNoBorder">
			<p>
				In this Item, provide information about the <em>applicant'</em>s disciplinary history 
				and the disciplinary history of all <em>associated persons or control affiliates</em> 
				of the <em>applicant</em> (as applicable). This information is used to decide whether 
				to revoke registration, to place limitations on the <em>applicant'</em>s activities as 
				a <em>funding portal</em>, and to identify potential problem areas on which to focus 
				during examinations. One event may result in the requirement to answer "yes" to more 
				than one of the questions below.  Check all answers that apply.  Refer to the Explanation 
				of Terms section of Form Funding Portal Instructions for explanation of italicized terms.
				<br/><br/>
				If the answer is "yes" to any question in this Item, the applicant must complete the 
				appropriate Disclosure Reporting Page ("DRP") (FP) - Criminal, Regulatory Action, Civil 
				Judicial Action, Bankruptcy/SIPC, Bond, or Judgment/Lien, as applicable.
			</p>	
		</div>	
		<h4 class="title2">Criminal Disclosure</h4>
		<div class="information">
			<p>	
				If the answer is "yes" to any question below, complete a Criminal DRP.
			</p>
		</div>
		<table role="presentation" id="tab5">
			<tr>
				<td class="label">
					A. In the past ten years, has the <i>applicant or any associated person</i>:
				</td>
				<td></td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						(1) been convicted of any <em>felony</em>, or pled guilty or nolo contendere ("no contest") 
						to any charge of a <em>felony</em>, in a domestic, foreign, or military court?
					</blockquote>
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:criminalDisclosure/cf:isConvictedOfFelony = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Yes&#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:criminalDisclosure/cf:isConvictedOfFelony = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;No&#160;			
				</td>
			</tr>
			<tr>
				<td class="label"><blockquote>The response to the following question may be limited to 
				charges that are currently pending:</blockquote></td>
			</tr>
			<tr>
				<td class="label"><blockquote>(2) been <em>charged</em> with any <em>felony</em>?</blockquote></td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:criminalDisclosure/cf:isChargedWithFelony = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose> &#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:criminalDisclosure/cf:isChargedWithFelony = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>					
				</td>				
			</tr>
			<tr>
				<td class="label">
					B. In the past ten years, has the <em>applicant</em> or any <em>associated person</em>:
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						(1) been convicted of any <em>misdemeanor,</em> or pled guilty or nolo contendere ("no contest"), 
						in a domestic, foreign, or military court to any charge of a <em>misdemeanor</em> in a case 
						involving: investment-related business, or any fraud, false statements, or omissions, wrongful 
						taking of property, bribery, perjury, forgery, counterfeiting, extortion, or a conspiracy to commit any of these offenses?
					</blockquote>
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:criminalDisclosure/cf:isConvictedMisdemeanor = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose> &#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:criminalDisclosure/cf:isConvictedMisdemeanor = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>					
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						The response to the following question may be limited to charges that are currently pending:
					</blockquote>
				</td>
			</tr>	
			<tr>
				<td class="label">
					<blockquote>
						(2) been <em>charged</em> with a <em>misdemeanor</em> listed in Item 5-B(1)?
					</blockquote>
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:criminalDisclosure/cf:isChargedMisdemeanor = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose> &#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:criminalDisclosure/cf:isChargedMisdemeanor = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>					
				</td>
			</tr>
		</table>
		<h4 class="title2">Regulatory Action Disclosure</h4>
		<div class="information">
			<p>
				If the answer is "yes" to any question below, complete a Regulatory Action DRP.
			</p>
		</div>
		<table role="presentation">
			<tr>
				<td class="label">
					C. Has the <em>SEC</em> or the Commodities Futures Trading  Commission ("CFTC") ever: 
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						(1) <em>found</em> the <em>applicant</em> or any <em>associated person</em> 
						to have made a false statement or omission?
					</blockquote>
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isMadeFalseStatement = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose> &#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isMadeFalseStatement = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>					
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						(2) <em>found</em> the <em>applicant</em> or any <em>associated person</em> 
						to have been <em>involved</em> in a violation of any SEC or CFTC regulations or statutes?
					</blockquote>
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isViolatedRegulation = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose> &#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isViolatedRegulation = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>					
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						(3) <em>found</em> the <em>applicant</em> or any <em>associated person</em> 
						to have been a cause of the denial, suspension, revocation, or restriction of 
						the authorization of an <em>investment-related</em> business to operate?
					</blockquote>
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isCauseOfDenial = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose> &#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isCauseOfDenial = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>					
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						(4) entered an <em>order</em> against the applicant or any associated person 
						in connection with <em>investment-related</em> activity?
					</blockquote>
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isOrderAgainst = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose> &#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isOrderAgainst = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>					
				</td>
			</tr>	
			<tr>
				<td class="label">
					<blockquote>
						(5) imposed a civil money penalty on the <em>applicant</em> or any <em>associated person,</em> 
						or ordered the <em>applicant</em> or any <em>associated person</em> to cease and desist 
						from any activity?
					</blockquote>
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isImposedPenalty = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise> 
					</xsl:choose> &#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isImposedPenalty = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>					
				</td>
			</tr>
			<tr>
				<td class="label">
					D. Has any other federal regulatory agency, any state regulatory agency, 
					or any <em>foreign financial regulatory authority</em>: 
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						(1) ever <em>found</em> the <em>applicant</em> or any <em>associated person</em> 
						to have made a false statement or omission, or been dishonest, unfair, or unethical?
					</blockquote>
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isUnEthical = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose> &#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isUnEthical = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>					
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						(2) ever <em>found</em> the <em>applicant</em> or any <em>associated person</em> 
						to have been involved in a violation of <em>investment-related</em> regulations or statutes?
					</blockquote>
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isFoundInViolationOfRegulation = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose>  &#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isFoundInViolationOfRegulation = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>					
				</td>
			</tr>	
			<tr>
				<td class="label">
					<blockquote>
						(3) ever <em>found</em> the <em>applicant</em> or any <em>associated person</em> 
						to have been the cause of a denial, suspension, revocation, or restriction of 
						the authorization of an <em>investment-related</em> business to operate?
					</blockquote>				
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isFoundInCauseOfDenial = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose>	&#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isFoundInCauseOfDenial = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>					
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						(4) in the past ten years entered an order against the <em>applicant</em> or any
						<em>associated person</em> in connection with an <em>investment-related</em> activity?
					</blockquote>				
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isOrderAgainstActivity = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose>	&#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isOrderAgainstActivity = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>						
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						(5) ever denied, suspended, or revoked the registration or license of the <em>applicant</em> or that of any <em>associated person,</em> or otherwise prevented the <em>applicant</em> or any <em>associated person</em> of the <em>applicant,</em> by <em>order,</em> from associating with an <em>investment-related</em> business or restricted the activities of the <em>applicant</em> or any <em>associated person</em>?
					</blockquote>				
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isDeniedLicense = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes 
						</xsl:otherwise>
					</xsl:choose> &#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isDeniedLicense = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>									
				</td>
			</tr>
			<tr>
				<td class="label">
					E. Has any <em>self-regulatory organization</em> or commodities exchange ever: 
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						(1) <em>found</em> the <em>applicant</em> or any <em>associated person</em> 
						to have made a false statement or omission?
					</blockquote>				
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isFoundMadeFalseStatement = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose>	&#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isFoundMadeFalseStatement = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>					
				</td>		
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						(2) <em>found</em> the <em>applicant</em> or any <em>associated person</em> 
						to have been <em>involved</em> in a violation of its rules (other than a violation 
						designated as a <em>minor rule violation</em> under a plan approved by the <em>SEC</em>?
					</blockquote>				
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isFoundInViolationOfRules = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose>				&#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isFoundInViolationOfRules = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>					
				</td>		
			</tr>	
			<tr>
				<td class="label">
					<blockquote>
						(3) <em>found</em> the <em>applicant</em> or any <em>associated person</em> 
						to have been the cause of a denial, suspension, revocation or restriction of 
						the authorization of an <em>investment-related</em> business to operate?
					</blockquote>				
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isFoundInCauseOfSuspension = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose>	&#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isFoundInCauseOfSuspension = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>							
				</td>		
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						(4) disciplined the <em>applicant</em> or any <em>associated person</em> by expelling or suspending the 
						<em>applicant</em> or the <em>associated person</em> from membership, barring or suspending the <em>applicant</em> 
						or the associated person from association with other members, or by otherwise restricting the activities of 
						the applicant or the associated person?
					</blockquote>				
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isDisciplined = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose>	&#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isDisciplined = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>						
				</td>		
			</tr>	
			<tr>
				<td class="label">
					F. Has the <em>applicant</em> or any <em>associated person</em> ever had an authorization 
					to act as an attorney, accountant, or federal contractor revoked or suspended?
				</td>			
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isAuthorizedToActAttorney = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose>	&#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isAuthorizedToActAttorney = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>						
				</td>		
			</tr>
			<tr>
				<td class="label">
					G. Is the <em>applicant</em> or any <em>associated person</em> currently the subject 
					of any regulatory proceeding that could result in a "yes" answer to any part of Item 5-C, 5-D, or 5-E?
				</td>			
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isRegulatoryComplaint = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose>			 &#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:regulatoryActionDisclosure/cf:isRegulatoryComplaint = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>						
				</td>		
			</tr>
		</table>
		<h4 class="title2">Civil Judicial Disclosure</h4>
		<div class="information">
			<p>
				If the answer is "yes" to a question below, complete a Civil Judicial Action DRP.
			</p>
		</div>
		<table role="presentation">
			<tr>
				<td class="label">
					H. Has any domestic or foreign court:
				</td>					
			</tr>	
			<tr>
				<td class="label">
					<blockquote>
						(1) in the past ten years, <em>enjoined</em> the <em>applicant</em> or any <em>associated person</em> 
						in connection with any <em>investment-related</em> activity?
					</blockquote>				
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:civilJudicialActionDisclosure/cf:isEnjoined = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose>				&#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:civilJudicialActionDisclosure/cf:isEnjoined = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>						
				</td>		
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						(2) ever <em>found</em> that the <em>applicant</em> or any <em>associated person</em>
						was <em>involved</em> in a violation of <em>investment-related</em> statutes or regulations?
					</blockquote>				
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:civilJudicialActionDisclosure/cf:isFoundInViolationOfRegulation = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose>			&#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:civilJudicialActionDisclosure/cf:isFoundInViolationOfRegulation = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>								
				</td>		
			</tr>	
			<tr>
				<td class="label">
					<blockquote>
						(3) ever dismissed, pursuant to a settlement agreement, an <em>investment-related</em> 
						civil action brought against the <em>applicant</em> or any <em>associated person</em> 
						by a state or <em>foreign financial regulatory authority</em>?
					</blockquote>				
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:civilJudicialActionDisclosure/cf:isDismissed = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose>	&#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:civilJudicialActionDisclosure/cf:isDismissed = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>	
				</td>		
			</tr>	
			<tr>
				<td class="label">
					I. Is the <em>applicant</em> or any <em>associated person</em> now the subject 
					of any civil <em>proceeding</em> that could result in a "yes" answer to any part of Item 5-H(1)-(3)?
				</td>	
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:civilJudicialActionDisclosure/cf:isNamedInCivilProceeding = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose>				&#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:civilJudicialActionDisclosure/cf:isNamedInCivilProceeding = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>						
				</td>				
			</tr>
		</table>
		<h4 class="title2">Financial Disclosure</h4>
		<div class="information">
			<p>
				If the answer is "yes" to a question below, complete a Bankruptcy/Disclosure, 
				Bond Disclosure or Judgment/Lien DRP, as applicable.
			</p>
		</div>
		<table role="presentation">
			<tr>
				<td class="label">
					J. In the past ten years, has the <em>applicant</em> or a control <em>affiliate</em> of the 
					<em>applicant</em> ever been a securities firm or a <em>control affiliate</em> of a securities firm that:
				</td>	
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						(1) has been the subject of a bankruptcy petition?
					</blockquote>				
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:financialDisclosure/cf:hasSubjectOfBankruptcy = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose>	 &#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:financialDisclosure/cf:hasSubjectOfBankruptcy = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>						
				</td>		
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						(2) has had a trustee appointed or a direct payment procedure 
						initiated under the Securities Investor Protection Act?
					</blockquote>				
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:financialDisclosure/cf:hasTrusteeAppointed = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose>			&#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:financialDisclosure/cf:hasTrusteeAppointed = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>						
				</td>		
			</tr>
			<tr>
				<td class="label">
					K. Has a bonding company ever denied, paid out on, or revoked a bond for the <em>applicant</em>?
				</td>	
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:financialDisclosure/cf:hasBondDenied = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose> &#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:financialDisclosure/cf:hasBondDenied = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>					
				</td>						
			</tr>
			<tr>
				<td class="label">
					L. Does the <em>applicant</em> have any unsatisfied judgments or liens against it?
				</td>	
				<td>
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:financialDisclosure/cf:doesAppHaveLiens = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> Yes
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> Yes
						</xsl:otherwise>
					</xsl:choose> &#160;
					<xsl:choose>
						<xsl:when test="cf:disclosureAnswers/cf:financialDisclosure/cf:doesAppHaveLiens = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/> No
						</xsl:otherwise>
					</xsl:choose>					
				</td>						
			</tr>			
		</table>
	
	</xsl:template>
	
</xsl:stylesheet>
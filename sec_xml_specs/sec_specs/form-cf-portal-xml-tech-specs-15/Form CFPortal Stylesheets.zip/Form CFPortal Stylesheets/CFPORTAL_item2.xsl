<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:cf="http://www.sec.gov/edgar/crowdfunding"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:ns1="http://www.sec.gov/edgar/common"
	xmlns:ns2="http://www.sec.gov/edgar/statecodes" 
	xmlns:ns3="http://www.sec.gov/edgar/common_drp">

	<xsl:template name="tab2">
		<xsl:variable name="legalStatus" select="cf:formOfOrganization/cf:legalStatusForm" />
		<h1><xsl:value-of select="$submissionType"/>: Form of Organization</h1>
		
		<table role="presentation" id="tab2">
			<tr>
				<td class="label">A. Indicate legal status of <em>applicant.</em></td>
				<td>
					<xsl:choose>
						<xsl:when test="contains($legalStatus, 'Corporation')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Corporation <br/>
					<xsl:choose>
						<xsl:when test="contains($legalStatus, 'Proprietorship')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Sole Proprietorship	<br/>
					<xsl:choose>
						<xsl:when test="contains($legalStatus, 'Partnership')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Partnership	<br/>			
					<xsl:choose>
						<xsl:when test="contains($legalStatus, 'Limited')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Limited Liability Company	<br/>
					<xsl:choose>
						<xsl:when test="contains($legalStatus, 'Other')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Other (Please specify)												
				</td>
			</tr>
			<xsl:if test="contains($legalStatus, 'Other')">
				<tr>
					<td class="label"><blockquote>If you selected "Other", please specify:</blockquote></td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="cf:formOfOrganization/cf:legalStatusOtherDesc" />
						</div>
					</td>
				</tr>			
			</xsl:if>			
			<tr>
				<td class="label">
					B. If other than a sole proprietor, indicate date and place <em>applicant</em> obtained its legal status 
					(i.e., state or country where incorporated, where partnership agreement was filed, or where <em>applicant</em>
					entity was formed):
				</td>
			</tr>
			
			<xsl:if test="not(contains($legalStatus, 'Proprietorship')) and count(cf:formOfOrganization/cf:legalStatusForm) &gt; 0">
				<tr>
					<td class="label"><blockquote>State/Country of formation:</blockquote></td>
					<td>
						<div class="fakeBox">
							<xsl:if test="not(contains($legalStatus, 'Sole'))">
								<xsl:call-template name="stateDescription">
									<xsl:with-param name="stateCode"
										select="cf:formOfOrganization/cf:jurisdictionOrganization" />
								</xsl:call-template>
							</xsl:if>
						</div>
					</td>
				</tr>
				<tr>
					<td class="label"><blockquote>Date of formation:</blockquote></td>
					<td>
						<div class="fakeBox2">
							<xsl:if test="not(contains($legalStatus, 'Sole'))">
								<xsl:value-of select="cf:formOfOrganization/cf:dateIncorporation"/>
							</xsl:if>
						</div>
					</td>
				</tr>
			</xsl:if>
		</table>
	
	</xsl:template>
	
</xsl:stylesheet>
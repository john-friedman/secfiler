<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:cf="http://www.sec.gov/edgar/crowdfunding"
	xmlns:drp="http://www.sec.gov/edgar/crowdfunding_drp"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:ns1="http://www.sec.gov/edgar/common"
	xmlns:ns2="http://www.sec.gov/edgar/statecodes" 
	xmlns:ns3="http://www.sec.gov/edgar/common_drp">

	<xsl:template name="bond">
		<xsl:if test="count(cf:bondDrpInfo/drp:bondDrp) &gt; 0">
			<h1>BOND DISCLOSURE REPORTING PAGE (FP)</h1>
			<h4 class="title1">GENERAL INSTRUCTIONS</h4>
			<div class="information">
				<p>
					You must provide a valid response to each question on every section of this DRP before 
					any of your information can be saved. Invalid or incomplete responses will prevent you 
					from closing the DRP with your information saved. It is recommended that you consult 
					the Print Form of this DRP to make sure you have gathered all the required information 
					before beginning your entry of information online.			
				</p>		
			</div>
			<xsl:for-each select="cf:bondDrpInfo/drp:bondDrp">
				<table role="presentation">
					<tr>
						<td class="label">
							This Disclosure Reporting Page (DRP FP) is an INITIAL <b><em>OR</em></b> AMENDED
							response used to report details for affirmative responses to Item 5-K of Form Funding Portal.
						</td>
						<td>
							<xsl:choose>
								<xsl:when test="drp:initialOrAmended='INITIAL'">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;INITIAL&#160;
							<xsl:choose>
								<xsl:when test="drp:initialOrAmended='AMENDED'">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;AMENDED
						</td>
					</tr>
					<tr>
						<td class="label">Check item(s) being responded to:</td>
						<td>
							<xsl:choose>
								<xsl:when test="drp:respondingTo = '5-K'">
									<img src="Images/box-checked.jpg" alt="Checkbox checked" />
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
								</xsl:otherwise>
							</xsl:choose>&#160;5-K
						</td>
					</tr>
				</table>
				
				<div class="information">
					<p>
						Use a separate DRP for each event or <em>proceeding</em>. An event or <em>proceeding</em> may be reported
						for more than one <em>person</em> or entity using one DRP. File with a completed Execution Page.<br/><br/>
						One event may result in more than one affirmative answer to Item 5-K.  Use only one DRP to report details 
						related to the same event.  If an event gives rise to actions by more than one regulator, provide details 
						for each action on a separate DRP.
					</p>
				</div>
				
				<xsl:if test="drp:respondingTo = '5-K'">
					<table role="presentation">
						<tr>
							<td class="label">1. Firm Name: (Policy Holder)</td>
							<td>
								<div class="fakeBox3">
									<xsl:value-of select="drp:firmName"/>
								</div>
							</td>
						</tr>
						<tr>
							<td class="label">2. Bonding Company Name:</td>
							<td>
								<div class="fakeBox3">
									<xsl:value-of select="drp:bondingCompanyName"/>
								</div>
							</td>
						</tr>
						<tr>
							<td class="label">3. Disposition Type: (check appropriate item)</td>
							<td>
								<xsl:choose>
									<xsl:when test="drp:dispositionType = 'Denied'">
										<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
									</xsl:otherwise>
								</xsl:choose>&#160;Denied&#160;
								<xsl:choose>
									<xsl:when test="drp:dispositionType = 'Payout'">
										<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
									</xsl:otherwise>
								</xsl:choose>&#160;Payout&#160;
								<xsl:choose>
									<xsl:when test="drp:dispositionType = 'Revoked'">
										<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
									</xsl:otherwise>
								</xsl:choose>&#160;Revoked						
							</td>
						</tr>
						<tr>
							<td class="label">4. Disposition Date (MM/DD/YYYY):</td>
							<td>
								<div class="fakeBox2">
									<xsl:value-of select="drp:dispositionDate/ns1:date"/>
								</div>
							</td>
						</tr>
						<tr>
							<td class="label"><blockquote>Specify if Disposition Date is Exact or needs an Explanation</blockquote></td>
							<td>
								<xsl:choose>
									<xsl:when test="drp:dispositionDate/ns1:exactOrExplanation = 'Exact'">
										<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
									</xsl:otherwise>
								</xsl:choose>&#160;Exact&#160;&#160;
								<xsl:choose>
									<xsl:when test="drp:dispositionDate/ns1:exactOrExplanation = 'Explanation'">
										<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
									</xsl:otherwise>
								</xsl:choose>&#160;Explanation						
							</td>
						</tr>	
						<xsl:if test="drp:dispositionDate/ns1:exactOrExplanation = 'Explanation'">
							<tr>
								<td class="label"><blockquote><blockquote>If not exact, provide explanation:</blockquote></blockquote></td>
								<td>
									<div class="fakeBox3">
										<xsl:value-of select="drp:dispositionDate/ns1:explanationInfo"/>
									</div>
								</td>
							</tr>	
						</xsl:if>
						<xsl:if test="drp:dispositionType = 'Payout'">
							<tr>
								<td class="label">5. If disposition resulted in Payout, list Payout Amount and Date Paid:</td>
								<td>
								</td>
							</tr>	
							<tr>
								<td class="label"><blockquote>Payout Amount:</blockquote></td>
								<td>
									<div class="fakeBox2">
										<xsl:if test="count(drp:payoutInfo/ns3:payoutAmount) &gt; 0">
											<xsl:value-of select='format-number(drp:payoutInfo/ns3:payoutAmount , "$###,###,###,##0.00")' />
										</xsl:if>
									</div>
								</td>
							</tr>
							<tr>
								<td class="label"><blockquote>Date Paid (MM/DD/YYYY):</blockquote></td>
								<td>
									<div class="fakeBox2">
										<xsl:value-of select="drp:payoutInfo/ns3:datePaid"/>
									</div>
								</td>
							</tr>
						</xsl:if>
						<tr>
							<td class="label">
								6. Summarize the details of circumstances leading 
								to the necessity of the bonding company action:
							</td>
							<td>
								<div class="fakeBox3">
									<xsl:value-of select="drp:summarizeDetails"/>
								</div>
							</td>
						</tr>
					</table>
				</xsl:if>
			</xsl:for-each>
		</xsl:if>
	</xsl:template>
	
</xsl:stylesheet>
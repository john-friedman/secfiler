<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:cf="http://www.sec.gov/edgar/crowdfunding"
	xmlns:drp="http://www.sec.gov/edgar/crowdfunding_drp"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:ns1="http://www.sec.gov/edgar/common"
	xmlns:ns2="http://www.sec.gov/edgar/statecodes" 
	xmlns:ns3="http://www.sec.gov/edgar/common_drp">

	<xsl:variable name="drp4_filedFor">
		<xsl:choose>
			<xsl:when test="cf:edgarSubmission/cf:formData/cf:bankruptcySipcDrpInfo/drp:bankruptcyDrp/drp:drpFiledFor = 'Applicant'">
				<xsl:value-of select="cf:edgarSubmission/cf:formData/cf:bankruptcySipcDrpInfo/drp:bankruptcyDrp/drp:drpFiledFor"/>
			</xsl:when>
			<xsl:when test="contains(cf:edgarSubmission/cf:formData/cf:bankruptcySipcDrpInfo/drp:bankruptcyDrp/drp:drpFiledFor , 'Applicant and one or more control affiliate(s)')">
				<xsl:value-of select="cf:edgarSubmission/cf:formData/cf:bankruptcySipcDrpInfo/drp:bankruptcyDrp/drp:drpFiledFor"/>
			</xsl:when>
			<xsl:when test="not(contains(cf:edgarSubmission/cf:formData/cf:bankruptcySipcDrpInfo/drp:bankruptcyDrp/drp:drpFiledFor , 'Applicant'))">
				<xsl:value-of select="cf:edgarSubmission/cf:formData/cf:bankruptcySipcDrpInfo/drp:bankruptcyDrp/drp:drpFiledFor"/>
			</xsl:when>
		</xsl:choose>
	</xsl:variable>

	<xsl:template name="bankruptcy">
		<xsl:if test="count(cf:bankruptcySipcDrpInfo/drp:bankruptcyDrp) &gt; 0">
			<h1>BANKRUPTCY/SIPC DISCLOSURE REPORTING PAGE (FP)</h1>
			<h4 class="title1">GENERAL INSTRUCTIONS</h4>
			<div class="information">
				<p>
					You must provide a valid response to each question on every section of this DRP before 
					any of your information can be saved. Invalid or incomplete responses will prevent you 
					from closing the DRP with your information saved. It is recommended that you consult 
					the Print Form of this DRP to make sure you have gathered all the required information 
					before beginning your entry of information online.			
				</p>		
			</div>
			<xsl:for-each select="cf:bankruptcySipcDrpInfo/drp:bankruptcyDrp">
				<xsl:call-template name="drp4_general"/>
				<xsl:call-template name="drp4_part1"/>
				
				<xsl:if test="$drp4_filedFor = 'Applicant' or $drp4_filedFor = 'Applicant and one or more control affiliate(s)'">
					<xsl:for-each select="drp:applicant/drp:appBankruptcySipcDrpDetails">
						<xsl:call-template name="drp4_applicant"/>
						<xsl:call-template name="drp4_part2"/>
					</xsl:for-each>
				</xsl:if>
				<xsl:if test="$drp4_filedFor = 'Applicant and one or more control affiliate(s)' or not(contains($drp4_filedFor , 'Applicant'))">
					<xsl:for-each select="drp:affiliatePerson/drp:affBankruptcySipcDrpDetails">
						<xsl:call-template name="drp4_controlAffiliate"/>
						<xsl:if test="drp:isConAffRegisteredCrd = 'N'">
							<xsl:call-template name="drp4_part2"/>
						</xsl:if>
					</xsl:for-each>
				</xsl:if>
			</xsl:for-each>
		</xsl:if>
	</xsl:template>
	
	<xsl:template name="drp4_general">
		<table role="presentation">
			<tr>
				<td class="label">
					This Disclosure Reporting Page (DRP FP) is an INITIAL <em><b>OR</b></em> AMENDED
					response used to report details for affirmative responses to Items 5-J of Form Funding Portal.
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="contains(drp:initialOrAmended,'INITIAL')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Initial&#160;
					<xsl:choose>
						<xsl:when test="contains(drp:initialOrAmended,'AMENDED')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Amended
				</td>
			</tr>
			<!-- VARIABLES BEGIN -->
			<xsl:variable name="drp4_response_1">
				<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
					<xsl:if test=". = '5-J(1)'">
						<xsl:value-of select="."/>
					</xsl:if>
				</xsl:for-each>
			</xsl:variable>
			<xsl:variable name="drp4_response_2">
				<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
					<xsl:if test=". = '5-J(2)'">
						<xsl:value-of select="."/>
					</xsl:if>
				</xsl:for-each>
			</xsl:variable>
			<!-- VARIABLES END -->
			<tr>
				<td class="label">Check item(s) being responded to:</td>
				<td>
					<xsl:choose>
						<xsl:when test="$drp4_response_1 = '5-J(1)'">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;5-J(1)&#160;
					<xsl:choose>
						<xsl:when test="$drp4_response_2 = '5-J(2)'">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;5-J(2)									
				</td>
			</tr>
		</table>
		<div class="information">
			<p>
				Use a separate DRP for each event or <em>proceeding</em>. An event or <em>proceeding</em> may be reported
				for more than one <em>person</em> or entity using one DRP.  File with a completed Execution Page.
				<br/><br/>
				One event may result in more than one affirmative answer to Item 5-J.  Use only one DRP to report details 
				related to the same event.  Unrelated civil judicial actions must be reported on separate DRPs.
			</p>		
		</div>
	</xsl:template>
	<xsl:template name="drp4_part1">
		<h4 class="title2"><em>Part 1</em></h4>
		<table role="presentation">
			<tr>
				<td class="label">
					1. The <em>person</em>(s) or entity(ies) for whom this DRP is being filed is (are) the:
					<br/><br/><blockquote>Select only one:</blockquote>
				</td>
				<td>
					<br/><br/><br/>
					<xsl:choose>
						<xsl:when test="$drp4_filedFor = 'Applicant'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;<em>Applicant</em><br/>
					<xsl:choose>
						<xsl:when test="$drp4_filedFor = 'Applicant and one or more control affiliate(s)'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;<em>Applicant and one or more control affiliate(s)</em><br/>
					<xsl:choose>
						<xsl:when test="$drp4_filedFor = 'One or more of control affiliate(s)'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;One or more of <em>control affiliate(s)</em>
				</td>
			</tr>
		</table>
		<div class="information">
			<p>
				If this DRP is being filed for a <em>control affiliate</em>, give the full name of the <em>control affiliate</em> below (for individuals, Last name, First name, Middle name).
				If the <em>control affiliate</em> is registered with the CRD, provide the CRD number. If not, indicate "non-registered" by checking the appropriate checkbox.
			</p>
		</div>
	</xsl:template>
	<xsl:template name="drp4_applicant">
		<h4 class="title2"><u>Applicant</u></h4>
	</xsl:template>
	<xsl:template name="drp4_controlAffiliate">
		<h4 class="title2"><em><u>Control Affiliate(s)</u></em></h4>
		<table role="presentation">
			<tr>
				<td class="label">
					<b>FP DRP - CONTROL AFFIILIATE</b>
				</td>
				<td></td>
			</tr>
			<tr>
				<td class="label"><blockquote><em>Control Affiliate CRD Number:</em></blockquote></td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="drp:apCrdNumber"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label"><blockquote>This <em>control affiliate</em> is:</blockquote></td>
				<td>
					<xsl:choose>
						<xsl:when test="drp:controlAffiliateType = 'a firm'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;A firm&#160;
					<xsl:choose>
						<xsl:when test="drp:controlAffiliateType = 'a natural person'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;A natural person					
				</td>
			</tr>
			<tr>
				<td class="label"><blockquote><em>Registered</em></blockquote></td>
				<td>
					<xsl:choose>
						<xsl:when test="drp:isRegistered = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose> &#160;Yes&#160;
					<xsl:choose>
						<xsl:when test="drp:isRegistered = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose> &#160;No
				</td>
			</tr>
			<xsl:if test="drp:controlAffiliateType = 'a firm'">
				<tr>
					<td class="label"><blockquote>
						Full name of the <em>control affiliate</em> (including, 
						for natural persons, last, first and middle names):</blockquote>
					</td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="drp:fullNameOfFirmOrPerson"/>
						</div>
					</td>
				</tr>
			</xsl:if>
			<xsl:if test="contains($submissionType , '/A') or contains($submissionType , '-W')">
				<tr>
					<td class="label">
						<blockquote>This is an amendment that seeks to remove a DRP record because the control 
						affiliate(s) is (are) no longer associated with the funding portal.</blockquote>
					</td>
					<td>
						<xsl:choose>
							<xsl:when test="drp:isAmendmentRemoveDrp = 'Y'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;Yes&#160;
						<xsl:choose>
							<xsl:when test="drp:isAmendmentRemoveDrp = 'N'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;No
					</td>
				</tr>
			</xsl:if>
			<tr>
				<td class="label">
					2. If the <em>control affiliate</em> is registered through the CRD, has the <em>control 
					affiliate</em> submitted a DRP (with Form U-4) or BD DRP to the CRD System for 
					the event? If the answer is "Yes," no other information on this DRP must be provided.
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="drp:isConAffRegisteredCrd = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Yes&#160;
					<xsl:choose>
						<xsl:when test="drp:isConAffRegisteredCrd = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;No
				</td>						
			</tr>
		</table>
		<div class="information">
			<p>
				<b>NOTE:</b> The completion of this Form does not relieve the <em>control 
				affiliate</em> of its obligation to update its CRD records.
			</p>
		</div>
	</xsl:template>
	<xsl:template name="drp4_part2">
		<blockquote>
			<h4 class="title2"><em>Part 2</em></h4>
		</blockquote>	
		<table role="presentation">
			<!-- VARIABLES BEGIN -->
				<!-- 1. -->
				<xsl:variable name="action1">
					<xsl:for-each select="drp:actionType">
						<xsl:if test="contains(. , 'Bankruptcy')">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<!-- 2. -->
				<xsl:variable name="action2">
					<xsl:for-each select="drp:actionType">
						<xsl:if test="contains(. , 'Compromise')">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<!-- 3. -->
				<xsl:variable name="action3">
					<xsl:for-each select="drp:actionType">
						<xsl:if test="contains(. , 'Declaration')">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<!-- 4. -->
				<xsl:variable name="action4">
					<xsl:for-each select="drp:actionType">
						<xsl:if test="contains(. , 'Liquidated')">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<!-- 5. -->
				<xsl:variable name="action5">
					<xsl:for-each select="drp:actionType">
						<xsl:if test="contains(. , 'Receivership')">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<!-- 6. -->
				<xsl:variable name="action6">
					<xsl:for-each select="drp:actionType">
						<xsl:if test="contains(. , 'Other')">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
			<!-- VARIABLES END -->
			
			<tr>
				<td class="label">1.  Action Type: (check appropriate item)</td>
				<td>
					<xsl:choose>
						<xsl:when test="$action1 = 'Bankruptcy'">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;Bankruptcy<br/>
					<xsl:choose>
						<xsl:when test="$action2 = 'Compromise'">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;Compromise<br/>
					<xsl:choose>
						<xsl:when test="$action3 = 'Declaration'">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;Declaration<br/>		
					<xsl:choose>
						<xsl:when test="$action4 = 'Liquidated'">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;Liquidated<br/>
					<xsl:choose>
						<xsl:when test="$action5 = 'Receivership'">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;Receivership<br/>
					<xsl:choose>
						<xsl:when test="$action6 = 'Other'">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;Other<br/>							
				</td>
			</tr>
			<xsl:if test="$action6 = 'Other'">
				<tr>
					<td class="label"><blockquote>Other Actions:</blockquote></td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="drp:actionTypeOtherDesc"/>
						</div>
					</td>
				</tr>
			</xsl:if>
			<tr>
				<td class="label">2. Action Date (MM/DD/YYYY): </td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="drp:actionDate/ns1:date"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label"><blockquote>Specify if Action Date is Exact or needs an Explanation</blockquote></td>
				<td>
					<xsl:choose>
						<xsl:when test="drp:actionDate/ns1:exactOrExplanation = 'Exact'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose> &#160;Exact&#160;&#160;
					<xsl:choose>
						<xsl:when test="drp:actionDate/ns1:exactOrExplanation = 'Explanation'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose> &#160; Explanation
				</td>
			</tr>
			<xsl:if test="not(drp:actionDate/ns1:exactOrExplanation = 'Exact')">
				<tr>
					<td class="label">
						<blockquote>
							<blockquote>
								If not exact, provide explanation:
							</blockquote>
						</blockquote>
					</td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="drp:actionDate/ns1:explanationInfo"/>
						</div>
					</td>
				</tr>
			</xsl:if>
			
			<tr>
				<td class="label">
					3. If the financial action relates to an organization over which the <em>applicant</em>
					or <em>control affiliate person</em> exercise(s)(d) control, enter organization name and
					the <em>applicant</em>'s or <em>control affiliate</em>'s position, title or relationship:
				</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:organizationName"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">
					4.  Court action brought in (Name of Federal, State or Foreign Court), 
					Location of Court (City or County and State or Country), Docket/Case Number 
					and Bankruptcy Chapter Number (if Federal Bankruptcy Filing):
				</td>
				<td></td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>Name of Federal, State or Foreign Court,</blockquote>
				</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:nameOfCourt"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>Location of the Court:</blockquote>
				</td>
				<td></td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						<blockquote>
							City or County:
						</blockquote>
					</blockquote>
				</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:cityOrCounty"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						<blockquote>
							State/Country:
						</blockquote>
					</blockquote>
				</td>
				<td>
					<div class="fakeBox">
						<xsl:call-template name="stateDescription">
							<xsl:with-param name="stateCode" select="drp:stateOrCountry" />
						</xsl:call-template>
					</div>									
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						<blockquote>
							Docket/Case Number:
						</blockquote>
					</blockquote>
				</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:docketOrCaseNo" />
					</div>									
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						<blockquote>
							Bankruptcy Chapter Number (if Federal Bankruptcy Filing):
						</blockquote>
					</blockquote>
				</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:bankruptcyChapterNo"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">5. Is action currently pending?</td>
				<td>
					<xsl:choose>
						<xsl:when test="drp:isActionPending = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Yes&#160;
					<xsl:choose>
						<xsl:when test="drp:isActionPending = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;No					
				</td>
			</tr>
			<xsl:if test="drp:isActionPending = 'N'">
				<!-- VARIABLES BEGIN -->
				<xsl:variable name="dispositionType1">
					<xsl:for-each select="drp:dispositionType">
						<xsl:if test=". = 'Direct Payment Procedure'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="dispositionType2">
					<xsl:for-each select="drp:dispositionType">
						<xsl:if test=". = 'Discharged'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="dispositionType3">
					<xsl:for-each select="drp:dispositionType">
						<xsl:if test=". = 'Dismissed'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="dispositionType4">
					<xsl:for-each select="drp:dispositionType">
						<xsl:if test=". = 'Dissolved'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="dispositionType5">
					<xsl:for-each select="drp:dispositionType">
						<xsl:if test=". = 'Satisfied/Released'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="dispositionType6">
					<xsl:for-each select="drp:dispositionType">
						<xsl:if test=". = 'SIPA Trustee Appointed'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="dispositionType7">
					<xsl:for-each select="drp:dispositionType">
						<xsl:if test=". = 'Other'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<!-- VARIABLES END -->
				<tr>
					<td class="label">6. If not pending, provide Disposition Type: (check appropriate item)</td>
					<td>
						<xsl:choose>
							<xsl:when test="$dispositionType1 = 'Direct Payment Procedure'">
								<img src="Images/box-checked.jpg" alt="Checkbox checked" />
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
							</xsl:otherwise>
						</xsl:choose>&#160;Direct Payment Procedure<br/>
						<xsl:choose>
							<xsl:when test="$dispositionType2 = 'Discharged'">
								<img src="Images/box-checked.jpg" alt="Checkbox checked" />
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
							</xsl:otherwise>
						</xsl:choose>&#160;Discharged<br/>	
						<xsl:choose>
							<xsl:when test="$dispositionType3 = 'Dismissed'">
								<img src="Images/box-checked.jpg" alt="Checkbox checked" />
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
							</xsl:otherwise>
						</xsl:choose>&#160;Dismissed<br/>
						<xsl:choose>
							<xsl:when test="$dispositionType4 = 'Dissolved'">
								<img src="Images/box-checked.jpg" alt="Checkbox checked" />
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
							</xsl:otherwise>
						</xsl:choose>&#160;Dissolved<br/>
						<xsl:choose>
							<xsl:when test="$dispositionType5 = 'Satisfied/Released'">
								<img src="Images/box-checked.jpg" alt="Checkbox checked" />
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
							</xsl:otherwise>
						</xsl:choose>&#160;Satisfied/Released<br/>
						<xsl:choose>
							<xsl:when test="$dispositionType6 = 'SIPA Trustee Appointed'">
								<img src="Images/box-checked.jpg" alt="Checkbox checked" />
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
							</xsl:otherwise>
						</xsl:choose>&#160;SIPA Trustee Appointed<br/>	
						<xsl:choose>
							<xsl:when test="$dispositionType7 = 'Other'">
								<img src="Images/box-checked.jpg" alt="Checkbox checked" />
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
							</xsl:otherwise>
						</xsl:choose>&#160;Other								
					</td>
				</tr>
				<xsl:if test="$dispositionType7 = 'Other'">
					<tr>
						<td class="label"><blockquote>If you selected "Other", please specify:</blockquote></td>
						<td>
							<div class="fakeBox3">
								<xsl:value-of select="drp:dispositionTypeOtherDesc"/>
							</div>
						</td>
					</tr>
				</xsl:if>
				<tr>
					<td class="label">7. Disposition Date (MM/DD/YYYY):</td>
					<td>
						<div class="fakeBox2">
							<xsl:value-of select="drp:dispositionDate/ns1:date"/>
						</div>
					</td>
				</tr>
				<tr>
					<td class="label"><blockquote>Specify if Disposition Date is Exact or needs an Explanation</blockquote></td>
					<td>
						<xsl:choose>
							<xsl:when test="drp:dispositionDate/ns1:exactOrExplanation = 'Exact'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose> &#160;Exact&#160;&#160;
						<xsl:choose>
							<xsl:when test="drp:dispositionDate/ns1:exactOrExplanation = 'Explanation'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose> &#160; Explanation
					</td>
				</tr>	
				<xsl:if test="not(drp:dispositionDate/ns1:exactOrExplanation = 'Exact')">
					<tr>
						<td class="label"><blockquote><blockquote>If not exact, provide explanation:</blockquote></blockquote></td>
						<td>
							<div class="fakeBox3">
								<xsl:value-of select="drp:dispositionDate/ns1:explanationInfo"/>
							</div>
						</td>
					</tr>
				</xsl:if>						
			</xsl:if>
			<tr>
				<td class="label">8.  Provide a brief summary of events leading to the action, 
				and if not discharged, explain. (The information must fit within the space provided):</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:summaryOfEvents"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">9. If a SIPA trustee was appointed or a direct payment procedure 
				was begun, enter the amount paid by you; or the name of trustee:</td>
				<td></td>
			</tr>
			<tr>
				<td class="label"><blockquote>Amount Paid:</blockquote></td>
				<td>
					<div class="fakeBox2">
						<xsl:if test="count(drp:amountPaid) &gt; 0">
							<xsl:value-of select='format-number(drp:amountPaid , "$###,###,###,##0.00")' />
						</xsl:if>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label"><blockquote>Name of Trustee:</blockquote></td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:nameOfTrustee"/>
					</div>
				</td>
			</tr>	
			<tr>
				<td class="label">
					<blockquote>
						Currently open?
					</blockquote>
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="drp:isCurrentlyOpen = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Yes
					<xsl:choose>
						<xsl:when test="drp:isCurrentlyOpen = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;No
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						Date Direct Payment Initiated/Filed or Trustee Appointed (MM/DD/YYYY):
					</blockquote>
				</td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="drp:dateDirectPayment/ns1:date"/>
					</div>
				</td>
			</tr>	
			<tr>
				<td class="label">
					<blockquote>Specify if Date Direct Payment Initiated/Filed or 
					Trustee Appointed is Exact or needs an Explanation
					</blockquote>
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="drp:dateDirectPayment/ns1:exactOrExplanation = 'Exact'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Exact&#160;&#160;
					<xsl:choose>
						<xsl:when test="drp:dateDirectPayment/ns1:exactOrExplanation = 'Explanation'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Explanation
				</td>
			</tr>	
			<xsl:if test="not(drp:dateDirectPayment/ns1:exactOrExplanation = 'Exact')">
				<tr>
					<td class="label"><blockquote><blockquote>If not exact, provide explanation:</blockquote></blockquote></td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="drp:dateDirectPayment/ns1:explanationInfo"/>
						</div>
					</td>
				</tr>
			</xsl:if>
			<tr>
				<td class="label"><blockquote>Provide details to any status disposition. Include details as to creditors, 
				terms, conditions, amounts due and settlement schedule (if applicable):</blockquote></td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:detailsOfDisposition"/>
					</div>
				</td>
			</tr>
		</table>
	</xsl:template>
</xsl:stylesheet>
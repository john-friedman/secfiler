<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:cf="http://www.sec.gov/edgar/crowdfunding"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:ns1="http://www.sec.gov/edgar/common"
	xmlns:ns2="http://www.sec.gov/edgar/statecodes" 
	xmlns:ns3="http://www.sec.gov/edgar/common_drp">

	<xsl:template name="tab1">
		<xsl:variable name="fundingPortalName1A">
			<xsl:for-each select="cf:identifyingInformation/cf:legalNameChange">
				<xsl:if test="contains(., '1A')">
					<xsl:value-of select="."/>
				</xsl:if>
			</xsl:for-each>
		</xsl:variable>
		<xsl:variable name="businessName1B">
			<xsl:for-each select="cf:identifyingInformation/cf:legalNameChange">
				<xsl:if test="contains(., '1B')">
					<xsl:value-of select="."/>
				</xsl:if>
			</xsl:for-each>
		</xsl:variable>	
		
		<h1><xsl:value-of select="$submissionType"/>: Identifying Information</h1>
		<div class="informationNoBorder">
			<p>
				Schedule A must be completed as part of all initial applications.
				Amendments to Schedule A must be provided on Schedule B.
				Schedule C must be completed by <em>nonresident funding portals.</em> 
				If this is a withdrawal of a <em>funding portal'</em>s registration, complete Schedule D.
			</p>
		</div>

		<xsl:if test="$submissionType = 'CFPORTAL/A'">
			<table role="presentation">
				<tr>
					<td class="label">
						If this is an amendment to any part of the <em>funding portal's</em> most recent 
						Form Funding Portal, provide an explanation describing the amendment:
					</td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="cf:identifyingInformation/cf:amendmentExplanation"/>
						</div>
					</td>
				</tr>
			</table>
		</xsl:if>
		
		<h4 class="titleNumber" style="padding:10px 10px 0px 10px">Exact name, principal business address, mailing address, if different, and 
		contact information of the <em>funding portal.</em></h4>
		<table role="presentation">
			<tr>
				<td class="label">
					A. Full name of the <em>funding portal:</em>
				</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="cf:identifyingInformation/cf:nameOfPortal"/>						
					</div>
				</td>
			</tr>
			
			<xsl:choose>
				<xsl:when test="count(cf:identifyingInformation/cf:otherNamesAndWebsiteUrls) &gt; 0">
					<xsl:for-each select="cf:identifyingInformation/cf:otherNamesAndWebsiteUrls">
						<tr>
							<td class="label">
								B. Name(s) under which business is conducted, if different from Item 1A:
							</td>
							<td>
								<div class="fakeBox3">
									<xsl:value-of select="cf:otherNamesUsedPortal"/>							
								</div>
							</td>
						</tr>
						<tr>
							<td class="label">
								<blockquote>Website URL(s) under which business is conducted, if different from Item 1A:</blockquote>
							</td>
							<td>
								<div class="fakeBox3">
									<xsl:value-of select="cf:webSiteOfPortal"/>						
								</div>
							</td>
						</tr>
					</xsl:for-each>
				</xsl:when>
				<xsl:otherwise>
					<tr>
						<td class="label">
							B. Name(s) under which business is conducted, if different from Item 1A:
						</td>
						<td>
							<div class="fakeBox3">
								<xsl:value-of select="cf:identifyingInformation/cf:otherNamesAndWebsiteUrls/cf:otherNamesUsedPortal"/>							
							</div>
						</td>
					</tr>
					<tr>
						<td class="label">
							<blockquote>Website URL(s) under which business is conducted, if different from Item 1A:</blockquote>
						</td>
						<td>
							<div class="fakeBox3">
								<xsl:value-of select="cf:identifyingInformation/cf:otherNamesAndWebsiteUrls/cf:webSiteOfPortal"/>						
							</div>
						</td>
					</tr>
				</xsl:otherwise>
			</xsl:choose>
		
			<tr>
				<td class="label">C. IRS Empl. Ident. No:</td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="cf:identifyingInformation/cf:irsEmployerIdNumber"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">
					D. If a name and/or website URL in (1A) or (1B) has changed since the <em>
					funding portal'</em>s most recent Form Funding Portal, enter the previous name and/or 
					website URL and specify whether the name change is of the:
				</td>
				<td>	
					<xsl:choose>
						<xsl:when test="contains($fundingPortalName1A , '1A')">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;<em>funding portal</em> name (1A)&#160;
					<xsl:choose>
						<xsl:when test="contains($businessName1B , '1B')">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;business name/website (1B)
				</td>
			</tr>
			
			<xsl:for-each select="cf:identifyingInformation/cf:prevNamesAndWebsiteUrls">
				<xsl:for-each select="cf:prevNamesOfPortal">
					<tr>
						<td class="label"><blockquote>Previous name(s):</blockquote></td>
						<td>
							<div class="fakeBox3"><xsl:value-of select="." /></div>
						</td>
					</tr>						
				</xsl:for-each>
			</xsl:for-each>
			<xsl:for-each select="cf:identifyingInformation/cf:prevNamesAndWebsiteUrls">
				<xsl:for-each select="cf:prevWebSiteUrls">
					<tr>
						<td class="label"><blockquote>Previous website URL(s):</blockquote></td>
						<td>
							<div class="fakeBox3"><xsl:value-of select="." /></div>
						</td>
					</tr>			
				</xsl:for-each>
			</xsl:for-each>
			
			<tr>
				<td class="label">
					E. <em>Funding portal'</em>s main street address (Do not use a P.O. Box):
				</td>
				<td>
				</td>
			</tr>
			<tr>
				<td class="label"><blockquote>Address 1:</blockquote></td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="cf:identifyingInformation/cf:portalAddress/ns1:street1"/>
					</div>
				</td>
			</tr>			
			
			<tr>
				<td class="label"><blockquote>Address 2:</blockquote></td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="cf:identifyingInformation/cf:portalAddress/ns1:street2"/>
					</div>
				</td>
			</tr>
			
			<tr>
				<td class="label"><blockquote>City:</blockquote></td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="cf:identifyingInformation/cf:portalAddress/ns1:city"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label"><blockquote>State/Country:</blockquote></td>
				<td>
					<div class="fakeBox">
						<xsl:call-template name="stateDescription">
							<xsl:with-param name="stateCode" 
								select="cf:identifyingInformation/cf:portalAddress/ns1:stateOrCountry" />
						</xsl:call-template>
					</div>
				</td>
			</tr>						
			<tr>
				<td class="label"><blockquote>Mailing Zip/ Postal Code:</blockquote></td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="cf:identifyingInformation/cf:portalAddress/ns1:zipCode"/>
					</div>
				</td>
			</tr>	
			
			<tr>
				<td class="label">
					F. Mailing Address(es) (if different) and office locations (if more than one):
				</td>
				<td>
				</td>
			</tr>			
			<tr>
				<td class="label"><blockquote><b>Mailing Address</b></blockquote></td>
				<td>
				</td>
			</tr>								
			<tr>
				<td class="label"><blockquote>Check here if mailing address is the same as the 
				main address entered in Item 1.E.</blockquote></td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:identifyingInformation/cf:mailingAddressDifferent = 'true'">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>
				</td>
			</tr>			
			<tr>
				<td class="label"><blockquote><blockquote>Address 1:</blockquote></blockquote></td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="cf:identifyingInformation/cf:portalMailingAddress/ns1:street1"/>
					</div>
				</td>
			</tr>						
			<tr>
				<td class="label"><blockquote><blockquote>Address 2:</blockquote></blockquote></td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="cf:identifyingInformation/cf:portalMailingAddress/ns1:street2"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label"><blockquote><blockquote>City:</blockquote></blockquote></td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="cf:identifyingInformation/cf:portalMailingAddress/ns1:city"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label"><blockquote><blockquote>State/Country:</blockquote></blockquote></td>
				<td>
					<div class="fakeBox">
						<xsl:call-template name="stateDescription">
							<xsl:with-param name="stateCode" 
								select="cf:identifyingInformation/cf:portalMailingAddress/ns1:stateOrCountry" />
						</xsl:call-template>
					</div>
				</td>
			</tr>							
			<tr>
				<td class="label"><blockquote><blockquote>Zip/Postal Code:</blockquote></blockquote></td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="cf:identifyingInformation/cf:portalMailingAddress/ns1:zipCode"/>						
					</div>
				</td>
			</tr>						
			
			<tr>
				<td class="label"><blockquote><b>Other Office Locations</b></blockquote></td>
				<td>
				</td>
			</tr>
			<tr>
				<td class="label"><blockquote><blockquote>Address 1:</blockquote></blockquote></td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="cf:identifyingInformation/cf:otherOfficeLocationAddress/ns1:street1"/>
					</div>
				</td>
			</tr>						
			<tr>
				<td class="label"><blockquote><blockquote>Address 2:</blockquote></blockquote></td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="cf:identifyingInformation/cf:otherOfficeLocationAddress/ns1:street2"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label"><blockquote><blockquote>City:</blockquote></blockquote></td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="cf:identifyingInformation/cf:otherOfficeLocationAddress/ns1:city"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label"><blockquote><blockquote>State/Country:</blockquote></blockquote></td>
				<td>
					<div class="fakeBox">
						<xsl:call-template name="stateDescription">
							<xsl:with-param name="stateCode" 
								select="cf:identifyingInformation/cf:otherOfficeLocationAddress/ns1:stateOrCountry" />
						</xsl:call-template>
					</div>
				</td>
			</tr>							
			<tr>
				<td class="label"><blockquote><blockquote>Zip/Postal Code:</blockquote></blockquote></td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="cf:identifyingInformation/cf:otherOfficeLocationAddress/ns1:zipCode"/>						
					</div>
				</td>
			</tr>								
			
			<tr>
				<td class="label">G. Contact Information:</td>
			</tr>	
			<tr>
				<td class="label"><blockquote>Telephone Number:</blockquote></td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="cf:identifyingInformation/cf:portalContact/cf:portalContactPhone"/>					
					</div>
				</td>
			</tr>
			<tr>
				<td class="label"><blockquote>Fax Number:</blockquote></td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="cf:identifyingInformation/cf:portalContact/cf:portalContactFax"/>					
					</div>
				</td>
			</tr>	
			<tr>
				<td class="label"><blockquote>E-mail Address:</blockquote></td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="cf:identifyingInformation/cf:portalContact/cf:portalContactEmail"/>					
					</div>
				</td>
			</tr>

			<tr>
				<td class="label">
					H. Contact employee information:
				</td>
			</tr>	
			<tr>
				<td class="label"><blockquote>Prefix</blockquote></td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="cf:identifyingInformation/cf:contactEmployeeName/ns1:prefix"/>					
					</div>
				</td>
			</tr>			
			<tr>
				<td class="label"><blockquote>First Name:</blockquote></td>
				<td>
					<div class="fakeBox">	
						<xsl:value-of select="cf:identifyingInformation/cf:contactEmployeeName/ns1:firstName"/>
					</div>
				</td>
			</tr>						
			<tr>
				<td class="label"><blockquote>Middle Name:</blockquote></td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="cf:identifyingInformation/cf:contactEmployeeName/ns1:middleName"/>
					</div>
				</td>
			</tr>									
			<tr>
				<td class="label"><blockquote>Last Name:</blockquote></td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="cf:identifyingInformation/cf:contactEmployeeName/ns1:lastName"/>
					</div>
				</td>
			</tr>			
			<tr>
				<td class="label"><blockquote>Suffix:</blockquote></td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="cf:identifyingInformation/cf:contactEmployeeName/ns1:suffix"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label"><blockquote>Title:</blockquote></td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="cf:identifyingInformation/cf:contactEmployeeTitle"/>
					</div>
				</td>
			</tr>			
			<tr>
				<td class="label"><blockquote>Direct Telephone Number:</blockquote></td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="cf:identifyingInformation/cf:employeeContact/cf:portalContactPhone"/>
					</div>
				</td>
			</tr>				
			<tr>
				<td class="label"><blockquote>Fax Number:</blockquote></td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="cf:identifyingInformation/cf:employeeContact/cf:portalContactFax"/>
					</div>
				</td>
			</tr>			
			<tr>
				<td class="label"><blockquote>Direct E-Mail Address:</blockquote></td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="cf:identifyingInformation/cf:employeeContact/cf:portalContactEmail"/>
					</div>
				</td>
			</tr>			

			<tr>
				<td class="label">I. Month <em>applicant'</em>s fiscal year ends:</td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="cf:identifyingInformation/cf:fiscalYearEnd"/>
					</div>
				</td>
			</tr>				
			
			<tr><td class="label">J. Registrations</td></tr>
			<tr>
				<td class="label"><blockquote>Was the <em>applicant</em> previously registered on Form Funding 
				Portal as a <em>funding portal</em> or with the Commission in any other capacity?</blockquote></td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:identifyingInformation/cf:anyPreviousRegistrations = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> 
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose> &#160;Yes&#160;
					<xsl:choose>
						<xsl:when test="cf:identifyingInformation/cf:anyPreviousRegistrations = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose> &#160;No					
				</td>
			</tr>
			<xsl:if test="cf:identifyingInformation/cf:anyPreviousRegistrations = 'Y'">
				<xsl:for-each select="cf:identifyingInformation/cf:secFileNumbers">
					<tr>
						<td class="label"><blockquote><blockquote>SEC File No. (if any):</blockquote></blockquote></td>
						<td><div class="fakeBox"><xsl:value-of select="."/></div></td>
					</tr>
				</xsl:for-each>
			</xsl:if>
			<tr>
				<td class="label">
					K. Foreign registrations
				</td>				
			</tr>
			
			<tr>
				<td class="label"><blockquote>(1) Is the <em>applicant</em> registrant with a <em>foreign financial
					regulatory</em> authority? Answer "no" even if affiliatted with a business that
					is registered with a <em>foreign financial regulatory authority</em></blockquote>.</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:identifyingInformation/cf:anyForeignRegistrations = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> 
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose> &#160;Yes&#160;
					<xsl:choose>
						<xsl:when test="cf:identifyingInformation/cf:anyForeignRegistrations = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/> 
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose> &#160;No
				</td>
			</tr>
			<tr>
				<td class="label"><blockquote>If "yes", complete Section K.2 below.</blockquote></td>
			</tr>			
			<tr>
				<td class="label"><blockquote>(2) List the name, in English, of each <em>foreign financial regulatory authority</em> 
				and country with which the <em>applicant</em> is registered. A separate entry must be completed for each <em>foreign 
				financial regulatory authority</em> with which the <em>applicant</em> is registered.</blockquote>
				</td>
				<td></td>
			</tr>			
			<xsl:if test="cf:identifyingInformation/cf:anyForeignRegistrations = 'Y'">
				<xsl:for-each select="cf:identifyingInformation/cf:foreignRegistrations">
					<tr>
						<td class="label">
							<blockquote>
								<blockquote>
									English name of <em>Foreign Financial Regulatory Authority:</em>
								</blockquote>
							</blockquote>
						</td>
						<td>
							<div class="fakeBox3">
								<xsl:value-of select="cf:foreignFinancialRegulatory"/>
							</div>
						</td>
					</tr>
					<tr>
						<td class="label">
							<blockquote>
								<blockquote>
									Registration Number (if any):
								</blockquote>
							</blockquote>
						</td>
						<td>
							<div class="fakeBox3">
								<xsl:value-of select="cf:registrationNumber"/>
							</div>
						</td>
					</tr>
					<tr>
						<td class="label">
							<blockquote>
								<blockquote>
									Name of Country:
								</blockquote>
							</blockquote>
						</td>
						<td>
							<div class="fakeBox">
								<xsl:call-template name="stateDescription">
									<xsl:with-param name="stateCode" select="cf:country" />
								</xsl:call-template>					
							</div>
						</td>
					</tr>
				</xsl:for-each>
			</xsl:if>
		</table>
	</xsl:template>
	
</xsl:stylesheet>
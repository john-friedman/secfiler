<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:cf="http://www.sec.gov/edgar/crowdfunding"
	xmlns:drp="http://www.sec.gov/edgar/crowdfunding_drp"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:ns1="http://www.sec.gov/edgar/common"
	xmlns:ns2="http://www.sec.gov/edgar/statecodes" 
	xmlns:ns3="http://www.sec.gov/edgar/common_drp">
	
	<xsl:variable name="drp1_filedFor">
		<xsl:choose>
			<xsl:when test="cf:edgarSubmission/cf:formData/cf:criminalDrpInfo/drp:criminalDrp/drp:drpFiledFor = 'Applicant'">
				<xsl:value-of select="cf:edgarSubmission/cf:formData/cf:criminalDrpInfo/drp:criminalDrp/drp:drpFiledFor"/>
			</xsl:when>
			<xsl:when test="contains(cf:edgarSubmission/cf:formData/cf:criminalDrpInfo/drp:criminalDrp/drp:drpFiledFor , 'Applicant and one or more associated person')">
				<xsl:value-of select="cf:edgarSubmission/cf:formData/cf:criminalDrpInfo/drp:criminalDrp/drp:drpFiledFor"/>
			</xsl:when>
			<xsl:when test="contains(cf:edgarSubmission/cf:formData/cf:criminalDrpInfo/drp:criminalDrp/drp:drpFiledFor , 'One or more of')">
				<xsl:value-of select="cf:edgarSubmission/cf:formData/cf:criminalDrpInfo/drp:criminalDrp/drp:drpFiledFor"/>
			</xsl:when>
		</xsl:choose>
	</xsl:variable>
	
	<xsl:template name="criminalAction">
		<xsl:if test="count(cf:criminalDrpInfo/drp:criminalDrp) &gt; 0">
			<h1>CRIMINAL ACTION DISCLOSURE REPORTING PAGE (FP)</h1>
			<h4 class="title1"><em>General Instructions</em></h4>
			<div class="information">
				<p>
					You must provide a valid response to each question on every section of this DRP before 
					any of your information can be saved. Invalid or incomplete responses will prevent you 
					from closing the DRP with your information saved. It is recommended that you consult 
					the Print Form of this DRP to make sure you have gathered all the required information 
					before beginning your entry of information online.			
				</p>		
			</div>
				
			<xsl:for-each select="cf:criminalDrpInfo/drp:criminalDrp">
				<xsl:call-template name="drp1_general"/>
				<xsl:call-template name="drp1_part1"/>
				<xsl:if test="$drp1_filedFor = 'Applicant' or contains($drp1_filedFor , 'Applicant and one or more associated person')">
					<xsl:for-each select="drp:applicant">
						<xsl:call-template name="drp1_applicant"/>
						<xsl:call-template name="drp1_part2"/>
					</xsl:for-each>
				</xsl:if>
				<xsl:if test="contains($drp1_filedFor , 'Applicant and one or more associated person') or contains($drp1_filedFor , 'One or more of')">
					<xsl:for-each select="drp:associatedPerson">
						<xsl:call-template name="drp1_associatedPerson"/>
						<xsl:call-template name="drp1_part2"/>
					</xsl:for-each>
				</xsl:if>
			</xsl:for-each>
		</xsl:if>
	</xsl:template>
	
	<xsl:template name="drp1_general">
		<table role="presentation">
			<tr>
				<td class="label">
					This Disclosure Reporting Page (DRP FP) is an INITIAL <em><b>OR</b></em> AMENDED
					response used to report details for affirmative responses to Items 
					5-A or 5-B of Form Funding Portal.
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="drp:initialOrAmended='INITIAL'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;INITIAL&#160;
					<xsl:choose>
						<xsl:when test="drp:initialOrAmended='AMENDED'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;AMENDED
				</td>
			</tr>
			<!-- VARIABLES BEGIN -->
			<xsl:variable name="drp1_responding_5a1">
				<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
					<xsl:if test=". = '5-A(1)'">
						<xsl:value-of select="."/>
					</xsl:if>
				</xsl:for-each>
			</xsl:variable>
			<xsl:variable name="drp1_responding_5a2">
				<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
					<xsl:if test=". = '5-A(2)'">
						<xsl:value-of select="."/>
					</xsl:if>
				</xsl:for-each>
			</xsl:variable>
			<xsl:variable name="drp1_responding_5b1">
				<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
					<xsl:if test=". = '5-B(1)'">
						<xsl:value-of select="."/>
					</xsl:if>
				</xsl:for-each>
			</xsl:variable>
			<xsl:variable name="drp1_responding_5b2">
				<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
					<xsl:if test=". = '5-B(2)'">
						<xsl:value-of select="."/>
					</xsl:if>
				</xsl:for-each>
			</xsl:variable>
			<!-- VARIABLES END -->
			<tr>
				<td class="label">Check item(s) being responded to:</td>
				<td>
					<xsl:choose>
						<xsl:when test="$drp1_responding_5a1 = '5-A(1)'">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;5-A(1)&#160;
					<xsl:choose>
						<xsl:when test="$drp1_responding_5a2 = '5-A(2)'">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;5-A(2)&#160;					
					<xsl:choose>
						<xsl:when test="$drp1_responding_5b1 = '5-B(1)'">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;5-B(1)&#160;
					<xsl:choose>
						<xsl:when test="$drp1_responding_5b2 = '5-B(2)'">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;5-B(2)				
				</td>
			</tr>
		</table>
	
		<div class="information">
			<p>
				Use a separate DRP for each event or <em>proceeding</em>. The same event or <em>proceeding</em> may be
				reported for more than one person or entity using one DRP.  File with a completed Execution Page.
				<br/><br/>
				Multiple counts of the same charge arising out of the same event(s) should be 
				reported on the same DRP.  Unrelated criminal actions, including separate cases 
				arising out of the same event, must be reported on separate DRPs.  Use this DRP 
				to report all charges arising out of the same event.  One event may result in 
				more than one affirmative answer to the items listed above.
			</p>
		</div>		
	</xsl:template>
	<xsl:template name="drp1_part1">
		<h4 class="title2">Part 1</h4>
		<table role="presentation">
			<tr>
				<td class="label">
					Check all that apply:<br/><br/>
					1. The <em>person</em>(s) or entity(ies) for whom this DRP is being filed is (are) the:
					<br/><br/>
					<blockquote>
						Select only one:
					</blockquote>
				</td>
				<td>
					<br/><br/><br/><br/><br/>
					<xsl:choose>
						<xsl:when test="$drp1_filedFor = 'Applicant'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;<em>Applicant</em> <br/>
					<xsl:choose>
						<xsl:when test="contains($drp1_filedFor , 'Applicant and one or more associated person')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;<em>Applicant</em> and one or more <em>associated persons</em><br/>
					<xsl:choose>
						<xsl:when test="contains($drp1_filedFor , 'One or more of')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;One or more of <em>applicant</em>'s <em>associated persons</em>
				</td>
			</tr>
		</table>		
	</xsl:template>
	<xsl:template name="drp1_applicant">
		<h4 class="title2"><u>Applicant</u></h4>
		<xsl:if test="$submissionType = 'CFPORTAL/A' or $submissionType = 'CFPORTAL-W'">
			<table role="presentation">
				<tr>
					<td class="label">
						If this DRP is being filed for the <em>applicant,</em> and it is an amendment that seeks 
						to remove a DRP concerning the <em>applicant</em> from the record, the reason the DRP 
						should be removed is:
					</td>
					<td>
						<xsl:choose>
							<xsl:when test="contains(drp:drpRemovalReason, 'applicant is registered')">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;The <em>applicant</em> is registered or applying for 
						registration and the event or <em>proceeding</em> was resolved in the <em>applicant'</em>s favor.<br/>
						<xsl:choose>
							<xsl:when test="contains(drp:drpRemovalReason, 'The DRP was filed in error')">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;The DRP was filed in error.				
					</td>
				</tr>
			</table>
		</xsl:if>		
	</xsl:template>
	<xsl:template name="drp1_associatedPerson">
		<h4 class="title2"><u><em>Associated Person</em>(s)</u></h4>
		<table role="presentation">
			<tr>
				<td class="label">If this DRP is being filed for an <em>associated person</em>:</td>
				<td></td>
			</tr>
			<tr>
				<td class="label">The <em>associated person</em> is:</td>
				<td>
					<xsl:choose>
						<xsl:when test="drp:associatedPersonDetails/drp:personType = 'a firm'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;a firm&#160;&#160;
					<xsl:choose>
						<xsl:when test="drp:associatedPersonDetails/drp:personType = 'a natural person'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;a natural person<br/>							
				</td>
			</tr>
			<tr>
				<td class="label">This <em>associated person</em> is:</td>
				<td>
					<xsl:choose>
						<xsl:when test="contains(drp:associatedPersonDetails/drp:personRegistered, 'is registered with')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;registered with the <em>SEC</em>&#160;&#160;
					<xsl:choose>
						<xsl:when test="contains(drp:associatedPersonDetails/drp:personRegistered, 'not registered with')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;not registered with the <em>SEC</em>
				</td>
			</tr>			
			
			<tr>
				<td class="label">
					Full name of the <em>associated person</em> 
					(including, for natural persons, last, first and middle names):
				</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:associatedPersonDetails/drp:fullName"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">If the <em>associated person</em> has a CRD number, provide that number.</td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="drp:associatedPersonDetails/drp:crdNumber"/>
					</div>
				</td>
			</tr>
			<xsl:if test="$submissionType = 'CFPORTAL-W' or $submissionType = 'CFPORTAL/A'">
				<tr>
					<td class="label">If this is an amendment that seeks to remove a DRP concerning the 
						<em>associated person, the reason DRP should be removed is:</em>
					</td>
					<td>
						<xsl:choose>
							<xsl:when test="contains(drp:drpRemovalInfo/drp:drpRemoveReason, 'no longer')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;The <em>associated person</em>(s) is (are) no longer associated with the <em>applicant</em>.<br/>
						<xsl:choose>
							<xsl:when test="contains(drp:drpRemovalInfo/drp:drpRemoveReason, 'was resolved in the')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;The event or <em>proceeding</em> was resolved in the <em>associated person'</em>s favor.<br/>
						<xsl:choose>
							<xsl:when test="contains(drp:drpRemovalInfo/drp:drpRemoveReason, 'ten years ago')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;The event or <em>proceeding</em> occurred more than ten years ago.<br/>
						<xsl:choose>
							<xsl:when test="contains(drp:drpRemovalInfo/drp:drpRemoveReason, 'DRP was filed in error')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;The DRP was filed in error.
					</td>
				</tr>
				<xsl:if test="contains(drp:drpRemovalInfo/drp:drpRemoveReason, 'DRP was filed in error')">	
					<tr>
						<td class="label">
							<blockquote>
								Explain the circumstances:
							</blockquote>
						</td>
						<td>
							<div class="fakeBox3">
								<xsl:value-of select="drp:drpRemovalInfo/drp:explanation"/>
							</div>
						</td>
					</tr>
				</xsl:if>
			</xsl:if>
		</table>		
	</xsl:template>
	<xsl:template name="drp1_part2">
		<blockquote>
			<h4 class="title2">Part 2</h4>
		</blockquote>
		<table role="presentation">
			<tr>
				<td class="label">
					1. If charge(s) were brought against a firm or organization over which 
					the <em>applicant</em> or a <em>associated person</em> exercise(s)(d) <em>control</em>:
				</td>
				<td>
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						A. Enter the firm or organization's name:
					</blockquote>
				</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:criminalDrpDetails/drp:organizationName"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						B. Was the firm or organization engaged in an <em>investment-related</em> business?
					</blockquote>
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="drp:criminalDrpDetails/drp:engagedInInvestmentRelatedBusiness ='Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Yes&#160;
					<xsl:choose>
						<xsl:when test="drp:criminalDrpDetails/drp:engagedInInvestmentRelatedBusiness ='N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;No
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						C. What was the relationship of the <em>applicant</em> with the firm or organization?  
						(In the case of a <em>associated person</em>, include any position or title with the firm or organization.)
					</blockquote>
				</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:criminalDrpDetails/drp:descRelationshipWithApplicant"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">
					2. Court where formal charge(s) were brought in: (include the name of Federal, 
					Military, State or Foreign Court, Location of Court - City or County and State 
					or Country, and Docket/Case number).
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="contains(drp:criminalDrpDetails/drp:courtType, 'Federal')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>							
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Federal Court<br/>
					<xsl:choose>
						<xsl:when test="contains(drp:criminalDrpDetails/drp:courtType, 'Military')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Military Court<br/>
					<xsl:choose>
						<xsl:when test="contains(drp:criminalDrpDetails/drp:courtType, 'State')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;State Court<br/>
					<xsl:choose>
						<xsl:when test="contains(drp:criminalDrpDetails/drp:courtType, 'Foreign')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Foreign Court						
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
					A. Name of Court:
					</blockquote>
				</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:criminalDrpDetails/drp:nameOfCourt"/>
					</div>
				</td>
			</tr>	
			<tr>
				<td class="label">
					<blockquote>
						B. Location of the Court:
					</blockquote>
				</td>
				<td></td>
			</tr>	
			<tr>
				<td class="label">
					<blockquote>
						<blockquote>
							Street Address 1:
						</blockquote>
					</blockquote>
				</td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="drp:criminalDrpDetails/drp:courtAddress/ns1:street1"/>
					</div>							
				</td>
			</tr>				
			<tr>
				<td class="label">
					<blockquote>
						<blockquote>
							Street Address 2:
						</blockquote>
					</blockquote>
				</td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="drp:criminalDrpDetails/drp:courtAddress/ns1:street2"/>
					</div>							
				</td>
			</tr>			
			<tr>
				<td class="label">
					<blockquote>
						<blockquote>
							City or County:
						</blockquote>
					</blockquote>
				</td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="drp:criminalDrpDetails/drp:courtAddress/ns1:city"/>
					</div>							
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						<blockquote>
							State/Country:
						</blockquote>
					</blockquote>
				</td>
				<td>
					<div class="fakeBox">
						<xsl:call-template name="stateDescription">
							<xsl:with-param 
								name="stateCode" 
								select="drp:criminalDrpDetails/drp:courtAddress/ns1:stateOrCountry" />
						</xsl:call-template>
					</div>							
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						<blockquote>
							Postal Code:
						</blockquote>
					</blockquote>
				</td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="drp:criminalDrpDetails/drp:courtAddress/ns1:zipCode"/>
					</div>							
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						C. Docket/Case Number:
					</blockquote>
				</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:criminalDrpDetails/drp:docketOrCaseNumber"/>
					</div>
				</td>
			</tr>	
			<tr>
				<td class="label">
					3. Event Disclosure Detail (Use this for both organizational and individual charges.)
				</td>
				<td>
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						A. Date First <em>Charged</em> (MM/DD/YYYY):
					</blockquote>
				</td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="drp:criminalDrpDetails/drp:dateFirstCharged/ns1:date"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						<blockquote>
							Specify if Date First <em>Charged</em> is Exact or needs an Explanation
						</blockquote>
					</blockquote>
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="drp:criminalDrpDetails/drp:dateFirstCharged/ns1:exactOrExplanation= 'Exact'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Exact&#160;&#160;
					<xsl:choose>
						<xsl:when test="drp:criminalDrpDetails/drp:dateFirstCharged/ns1:exactOrExplanation= 'Explanation'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Explanation								
				</td>
			</tr>
			<xsl:if test="drp:criminalDrpDetails/drp:dateFirstCharged/ns1:exactOrExplanation = 'Explanation'">
				<tr>
					<td class="label">
						<blockquote>
							<blockquote>
								<blockquote>
									If not exact, provide explanation:
								</blockquote>
							</blockquote>
						</blockquote>
					</td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="drp:criminalDrpDetails/drp:dateFirstCharged/ns1:explanationInfo"/>
						</div>
					</td>
				</tr>
			</xsl:if>
			
			<tr>
				<td class="label">
					<blockquote>
					B. Event Disclosure Detail(include charge(s)/charge Description(s), 
					and for each charge provide:  (1) number of counts, (2) <em>felony</em> or <em>misdemeanor,</em> 
					(3) plea for each charge, and (4) product type if charge is <em>investment-related</em>) :
					Report all charges separately.  For each charge, provide all of the following information
					</blockquote>
				</td>
				<td></td>
			</tr>
			
			<xsl:for-each select="drp:criminalDrpDetails/drp:criminalCharge">
				<tr>
					<td class="label"><blockquote><blockquote>List the charge(s)/<em>charge</em> description:</blockquote></blockquote></td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="drp:chargeDesc"/>
						</div>
					</td>
				</tr>
				<tr>
					<td class="label"><blockquote><blockquote>(1) Number of counts:</blockquote></blockquote></td>
					<td>
						<div class="fakeBox2">
							<xsl:value-of select="drp:numberOfCounts"/>
						</div>
					</td>
				</tr>
				<tr>
					<td class="label"><blockquote><blockquote>(2) <em>Felony</em> or <em>misdemeanor</em>:</blockquote></blockquote></td>
					<td>
						<xsl:choose>
							<xsl:when test="drp:felonyOrMisdemeanor= 'Felony'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;Felony&#160;&#160;
						<xsl:choose>
							<xsl:when test="drp:felonyOrMisdemeanor= 'Misdemeanor'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;Misdemeanor								
					</td>
				</tr>
				<tr>
					<td class="label"><blockquote><blockquote>(3) Plea for this charge:</blockquote></blockquote></td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="drp:plea"/>
						</div>
					</td>
				</tr>
				<tr>
					<td class="label">
						<blockquote>
							<blockquote>
								(4) What is the product type if the charge is investment-related?
							</blockquote>
						</blockquote>
					</td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="drp:investmentProductType"/>
						</div>
					</td>
				</tr>
			</xsl:for-each>
			
			<tr>
				<td class="label">
					<blockquote>
						C. Did any of the charge(s) within the event <em>involve</em> a <em>felony</em>?
					</blockquote>
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="drp:criminalDrpDetails/drp:anyChargeFelony = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Yes&#160;&#160;
					<xsl:choose>
						<xsl:when test="drp:criminalDrpDetails/drp:anyChargeFelony = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;No
				</td>
			</tr>
			
			<tr>
				<td class="label">
					<blockquote>
						D. Current status of the event?
					</blockquote>
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="drp:criminalDrpDetails/drp:eventCurrentStatus= 'Pending'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Pending&#160;&#160;
					<xsl:choose>
						<xsl:when test="drp:criminalDrpDetails/drp:eventCurrentStatus= 'On Appeal'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;On Appeal&#160;&#160;
					<xsl:choose>
						<xsl:when test="drp:criminalDrpDetails/drp:eventCurrentStatus= 'Final'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Final
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						E. Event status date (Complete unless status is pending) (MM/DD/YYYY):
					</blockquote>
				</td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="drp:criminalDrpDetails/drp:eventStatusDate/ns1:date"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						<blockquote>
							Specify if Event status date is Exact or needs an Explanation
						</blockquote>
					</blockquote>
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="contains(drp:criminalDrpDetails/drp:eventStatusDate/ns1:exactOrExplanation, 'Exact')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Exact&#160;&#160;
					<xsl:choose>
						<xsl:when test="contains(drp:criminalDrpDetails/drp:eventStatusDate/ns1:exactOrExplanation, 'Explanation')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Explanation								
				</td>
			</tr>
			<xsl:if test="contains(drp:criminalDrpDetails/drp:eventStatusDate/ns1:exactOrExplanation, 'Explanation')">
				<tr>
					<td class="label">
						<blockquote>
							<blockquote>
								<blockquote>
									If not exact, provide explanation:
								</blockquote>
							</blockquote>
						</blockquote>
					</td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="drp:criminalDrpDetails/drp:eventStatusDate/ns1:explanationInfo"/>
						</div>
					</td>
				</tr>				
			</xsl:if>
			<tr>
				<td class="label">
					4. Disposition Disclosure Detail: Include for each charge (a) Disposition Type (<u>e.g.</u>, 
					convicted, acquitted, dismissed, pretrial, etc.), (b) Date, (c) Sentence/Penalty, (d) Duration 
					(if sentence- suspension, probation, etc.), (e) Start Date of Penalty, (f) Penalty/Fine Amount, 
					and (g) Date Paid.
				</td>
				<td>
				</td>
			</tr>
			<!-- VARIABLES BEGIN -->
				<!-- 1. -->
				<xsl:variable name="disposition1">
					<xsl:for-each select="drp:dispositionDisclosure/drp:dispositionTypes">
						<xsl:if test="contains(. , 'Acquitted')">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<!-- 2. -->
				<xsl:variable name="disposition2">
					<xsl:for-each select="drp:dispositionDisclosure/drp:dispositionTypes">
						<xsl:if test="contains(. , 'Amended')">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<!-- 3. -->
				<xsl:variable name="disposition3">
					<xsl:for-each select="drp:dispositionDisclosure/drp:dispositionTypes">
						<xsl:if test="contains(. , 'Convicted')">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<!-- 4. -->
				<xsl:variable name="disposition4">
					<xsl:for-each select="drp:dispositionDisclosure/drp:dispositionTypes">
						<xsl:if test="contains(. , 'Deferred')">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<!-- 5. -->
				<xsl:variable name="disposition5">
					<xsl:for-each select="drp:dispositionDisclosure/drp:dispositionTypes">
						<xsl:if test="contains(. , 'Dismissed')">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>		
				<!-- 6. -->
				<xsl:variable name="disposition6">
					<xsl:for-each select="drp:dispositionDisclosure/drp:dispositionTypes">
						<xsl:if test="contains(. , 'Found')">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>	
				<!-- 7. -->
				<xsl:variable name="disposition7">
					<xsl:for-each select="drp:dispositionDisclosure/drp:dispositionTypes">
						<xsl:if test="contains(. , 'Pled guilty')">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>	
				<!-- 8. -->
				<xsl:variable name="disposition8">
					<xsl:for-each select="drp:dispositionDisclosure/drp:dispositionTypes">
						<xsl:if test="contains(. , 'Pled nolo')">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>		
				<!-- 9. -->
				<xsl:variable name="disposition9">
					<xsl:for-each select="drp:dispositionDisclosure/drp:dispositionTypes">
						<xsl:if test="contains(. , 'Pled not')">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>	
				<!-- 10. -->
				<xsl:variable name="disposition10">
					<xsl:for-each select="drp:dispositionDisclosure/drp:dispositionTypes">
						<xsl:if test="contains(. , 'Pretrial')">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>	
				<!-- 11. -->
				<xsl:variable name="disposition11">
					<xsl:for-each select="drp:dispositionDisclosure/drp:dispositionTypes">
						<xsl:if test="contains(. , 'Reduced')">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>	
				<!-- 12. -->
				<xsl:variable name="disposition12">
					<xsl:for-each select="drp:dispositionDisclosure/drp:dispositionTypes">
						<xsl:if test="contains(. , 'Appealed')">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>	
				<!-- 13. -->
				<xsl:variable name="disposition13">
					<xsl:for-each select="drp:dispositionDisclosure/drp:dispositionTypes">
						<xsl:if test="contains(. , 'Other')">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<!-- 1.a -->
				<xsl:variable name="appealed1">
					<xsl:for-each select="drp:dispositionDisclosure/drp:appealTypes">
						<xsl:if test="contains(. , 'Affirmed')">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<!-- 2.a -->
				<xsl:variable name="appealed2">
					<xsl:for-each select="drp:dispositionDisclosure/drp:appealTypes">
						<xsl:if test="contains(. , 'Returned')">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<!-- 3.a -->
				<xsl:variable name="appealed3">
					<xsl:for-each select="drp:dispositionDisclosure/drp:appealTypes">
						<xsl:if test="contains(. , 'Final')">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<!-- 4.a -->
				<xsl:variable name="appealed4">
					<xsl:for-each select="drp:dispositionDisclosure/drp:appealTypes">
						<xsl:if test="contains(. , 'Other')">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
			<!-- VARIABLES END -->					
			<tr>
				<td class="label">
					<blockquote>
						(a) Disposition Type (<em><u>e.g.</u></em>, convicted, acquitted, dismissed, pretrial, etc.):
					</blockquote>
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="$disposition1 = 'Acquitted'">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;Acquitted<br/>
					<xsl:choose>
						<xsl:when test="contains($disposition2 , 'Amended')">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;Amended	<br/>	
					<xsl:choose>
						<xsl:when test="contains($disposition3 , 'Convicted')">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;Convicted	<br/>	
					<xsl:choose>
						<xsl:when test="contains($disposition4 , 'Deferred')">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;Deferred Adjudication	<br/>
					<xsl:choose>
						<xsl:when test="contains($disposition5 , 'Dismissed')">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;Dismissed	<br/>	
					<xsl:choose>
						<xsl:when test="contains($disposition6 , 'Found')">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;<em>Found</em> not guilty	<br/>	
					<xsl:choose>
						<xsl:when test="contains($disposition7 , 'Pled guilty')">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;Pled guilty	<br/>
					<xsl:choose>
						<xsl:when test="contains($disposition8 , 'Pled nolo')">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;Pled nolo contendere<br/>
					<xsl:choose>
						<xsl:when test="contains($disposition9 , 'Pled not')">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;Pled not guilty	<br/>		
					<xsl:choose>
						<xsl:when test="contains($disposition10 , 'Pretrial')">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;Pretrial diversion/intervention	<br/>
					<xsl:choose>
						<xsl:when test="contains($disposition11 , 'Reduced')">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;Reduced		<br/>	
					<!-- 12. /2 -->
					<xsl:choose>
						<xsl:when test="contains($disposition12 , 'Appealed')">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;Appealed<br/>
					<xsl:if test="$disposition12='Appealed'">
						<xsl:choose>
							<xsl:when test="$appealed1='Affirmed'">
								<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
							</xsl:otherwise>
						</xsl:choose>&#160;Affirmed<br/>
						<xsl:choose>
							<xsl:when test="contains($appealed2 ,'Returned')">
								<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
							</xsl:otherwise>
						</xsl:choose>&#160;Vacated &amp; Returned For Further Action<br/>
						<xsl:choose>
							<xsl:when test="contains($appealed3 , 'Final')">
								<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
							</xsl:otherwise>
						</xsl:choose>&#160;Vacated/Final<br/>
						<!-- 4.a /2 -->
						<xsl:choose>
							<xsl:when test="$appealed4='Other'">
								<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
							</xsl:otherwise>
						</xsl:choose>&#160;Other											
					
					</xsl:if>
				</td>
			</tr>
			<xsl:if test="$appealed4 = 'Other'">
				<tr>
					<td class="label"><blockquote>If Other, specify</blockquote></td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="drp:dispositionDisclosure/drp:appealTypeOtherDesc"/>
						</div>
					</td>
				</tr>	
			</xsl:if>
			<tr>
				<td class="label">&#160;</td>
				<td>
					<!-- 13. /2 -->
					<xsl:choose>
						<xsl:when test="$disposition13 = 'Other'">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;Other
				</td>
			</tr>
			<xsl:if test="$disposition13 = 'Other'">
				<tr>
					<td class="label"><blockquote>If Other, specify</blockquote></td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="drp:dispositionDisclosure/drp:dispositionTypeOtherDesc"/>
						</div>
					</td>
				</tr>			
			</xsl:if>	
			<tr>
				<td class="label">
					<blockquote>
						(b) Date (MM/DD/YYYY):
					</blockquote>
				</td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="drp:dispositionDisclosure/drp:dispositionDate"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						(c) Sentence/Penalty:
					</blockquote>
				</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:dispositionDisclosure/drp:sentencePenalty"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						(d) Duration (if sentence- suspension, probation, etc.):
					</blockquote>
				</td>
				<td>
					<div class="fakeBox_duration" style="float:left">
						<xsl:value-of select="drp:dispositionDisclosure/drp:duration/drp:days"/>
					</div>
					<div style="float:left">
						&#160; of days &#160;
					</div>
					<div class="fakeBox_duration" style="float:left">
						<xsl:value-of select="drp:dispositionDisclosure/drp:duration/drp:months"/>
					</div>
					<div style="float:left">						
						&#160; of months &#160;
					</div>
					<div class="fakeBox_duration" style="float:left">
						<xsl:value-of select="drp:dispositionDisclosure/drp:duration/drp:years"/>
					</div>
					<div style="float:left">
						&#160; of years &#160;
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						(e) Start Date of Penalty (MM/DD/YYYY):
					</blockquote>
				</td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="drp:dispositionDisclosure/drp:startDatePenalty"/>
					</div>
				</td>
			</tr>	
			<tr>
				<td class="label">
					<blockquote>
						(f) Penalty/Fine Amount:
					</blockquote>
				</td>
				<td>
					<div class="fakeBox2">
						<xsl:if test="count(drp:dispositionDisclosure/drp:penaltyFineAmount) &gt; 0">
							<xsl:value-of select='format-number(drp:dispositionDisclosure/drp:penaltyFineAmount , "$###,###,###,##0.00")' />
						</xsl:if>
					</div>
				</td>
			</tr>	
			<tr>
				<td class="label">
					<blockquote>
						(g) Date Paid (MM/DD/YYYY):
					</blockquote>
				</td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="drp:dispositionDisclosure/drp:datePaid"/>
					</div>
				</td>
			</tr>			
			<tr>
				<td class="label">
					5. Provide a brief summary of circumstances leading to the charge(s) as well as the disposition.
				</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:summaryOfCircumstances"/>
					</div>
				</td>
			</tr>
		</table>		
	</xsl:template>
</xsl:stylesheet>
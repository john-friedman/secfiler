<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:cf="http://www.sec.gov/edgar/crowdfunding"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:ns1="http://www.sec.gov/edgar/common"
	xmlns:ns2="http://www.sec.gov/edgar/statecodes" 
	xmlns:ns3="http://www.sec.gov/edgar/common_drp">

	<xsl:template name="scheduleD">
		<xsl:if test="$submissionType = 'CFPORTAL-W'">
			<h1>FORM FUNDING PORTAL SCHEDULE D</h1>
			<h4 class="title1" style="">If this is a withdrawal of registration:</h4>	
			<h4 class="title2">A. The date the <em>funding portal</em> ceased business or withdrew its registration request:</h4>
			<table role="presentation" id="scheduleD">
				<tr>
					<td class="label">Date (MM/DD/YYYY):</td>
					<td>
						<div class="fakeBox2">
							<xsl:value-of select="cf:scheduleD/cf:dateBusinessCeasedWithdrawn"/>
						</div>
					</td>
				</tr>
			</table>
			<h4 class="title2">B. Location of Books and Records after Registration Withdrawal:</h4>
			<div class="informationNoBorder">
				<h4 class="title3" style="font-weight:lighter">
					Complete the following information for each location at which the applicant 
						will keeps books and records after withdrawing its registration.<br/>
						Name and address of entity where books and records are kept:
				</h4>
			</div>
			<xsl:choose>
				<xsl:when test="count(cf:scheduleD/cf:bookKeepingDetails) &gt; 0">
					<xsl:for-each select="cf:scheduleD/cf:bookKeepingDetails">
						<table role="presentation" id="scheduleD">
							<tr>
								<td class="label">Name:</td>
								<td>
									<div class="fakeBox3">
										<xsl:value-of select="cf:bookKeepingEntityName"/>
									</div>
								</td>
							</tr>
							<tr>
								<td class="label">Address 1:</td>
								<td>
									<div class="fakeBox">
										<xsl:value-of select="cf:bookKeepingEntityAddress/ns1:street1"/>
									</div>
								</td>
							</tr>
							<tr>
								<td class="label">Address 2:</td>
								<td>
									<div class="fakeBox">
										<xsl:value-of select="cf:bookKeepingEntityAddress/ns1:street2"/>
									</div>
								</td>
							</tr>
							<tr>
								<td class="label">City:</td>
								<td>
									<div class="fakeBox">
										<xsl:value-of select="cf:bookKeepingEntityAddress/ns1:city"/>
									</div>
								</td>
							</tr>			
							<tr>
								<td class="label">State/Country:</td>
								<td>
									<div class="fakeBox">
										<xsl:call-template name="stateDescription">
											<xsl:with-param name="stateCode" select="cf:bookKeepingEntityAddress/ns1:stateOrCountry" />
										</xsl:call-template>							
									</div>
								</td>
							</tr>
							<tr>
								<td class="label">Mailing Zip/ Postal Code:</td>
								<td>
									<div class="fakeBox2">
										<xsl:value-of select="cf:bookKeepingEntityAddress/ns1:zipCode"/>
									</div>
								</td>
							</tr>
							<tr>
								<td class="label">Phone Number</td>
								<td>
									<div class="fakeBox2">
										<xsl:value-of select="cf:bookKeepingEntityPhone"/>
									</div>
								</td>
							</tr>	
							<tr>
								<td class="label">Fax Number</td>
								<td>
									<div class="fakeBox2">
										<xsl:value-of select="cf:bookKeepingEntityFax"/>
									</div>
								</td>
							</tr>	
							<tr>
								<td class="label">This is (check one):</td>
								<td>
									<xsl:choose>
										<xsl:when test="cf:bookKeepingEntityType = 'BO'">
											<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
										</xsl:when>
										<xsl:otherwise>
											<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
										</xsl:otherwise>
									</xsl:choose>&#160;one of <em>applicant’</em>s branch offices or affiliates. <br/>
									<xsl:choose>
										<xsl:when test="cf:bookKeepingEntityType = 'TP'">
											<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
										</xsl:when>
										<xsl:otherwise>
											<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
										</xsl:otherwise>
									</xsl:choose>&#160;a third party unaffiliated recordkeeper.<br/>
									<xsl:choose>
										<xsl:when test="cf:bookKeepingEntityType = 'O'">
											<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
										</xsl:when>
										<xsl:otherwise>
											<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
										</xsl:otherwise>
									</xsl:choose>&#160;other.<br/>
								</td>
							</tr>			
							<tr>
								<td class="label">If this address is a private residence, check this box:</td>
								<td>
									<xsl:choose>
										<xsl:when test="cf:isAddressPrivateResidence = 'Y'">
											<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
										</xsl:when>
										<xsl:otherwise>
											<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
										</xsl:otherwise>
									</xsl:choose>&#160;Yes&#160;
									<xsl:choose>
										<xsl:when test="cf:isAddressPrivateResidence = 'N'">
											<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
										</xsl:when>
										<xsl:otherwise>
											<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
										</xsl:otherwise>
									</xsl:choose>&#160;No						
								</td>
							</tr>	
							<tr>
								<td class="label">Briefly describe the books and records kept at this location:</td>
								<td>
									<div class="fakeBox3">
										<xsl:value-of select="cf:bookKeepingLocationDesc"/>
									</div>
								</td>
							</tr>
						</table>
					</xsl:for-each>
				</xsl:when>
				<xsl:otherwise>
					<table role="presentation" id="scheduleD">
						<tr>
							<td class="label">Name:</td>
							<td>
								<div class="fakeBox3">
								</div>
							</td>
						</tr>
						<tr>
							<td class="label">Address 1:</td>
							<td>
								<div class="fakeBox">
								</div>
							</td>
						</tr>
						<tr>
							<td class="label">Address 2:</td>
							<td>
								<div class="fakeBox">
								</div>
							</td>
						</tr>
						<tr>
							<td class="label">City:</td>
							<td>
								<div class="fakeBox">
								</div>
							</td>
						</tr>			
						<tr>
							<td class="label">State/Country:</td>
							<td>
								<div class="fakeBox">
								</div>
							</td>
						</tr>
						<tr>
							<td class="label">Mailing Zip/ Postal Code:</td>
							<td>
								<div class="fakeBox2">
								</div>
							</td>
						</tr>
						<tr>
							<td class="label">Phone Number</td>
							<td>
								<div class="fakeBox2">
								</div>
							</td>
						</tr>	
						<tr>
							<td class="label">Fax Number</td>
							<td>
								<div class="fakeBox2">
								</div>
							</td>
						</tr>	
						<tr>
							<td class="label">This is (check one):</td>
							<td>
								<xsl:choose>
									<xsl:when test="cf:bookKeepingEntityType = 'BO'">
										<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
									</xsl:otherwise>
								</xsl:choose>&#160;one of <em>applicant’</em>s branch offices or affiliates. <br/>
								<xsl:choose>
									<xsl:when test="cf:bookKeepingEntityType = 'TP'">
										<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
									</xsl:otherwise>
								</xsl:choose>&#160;a third party unaffiliated recordkeeper.<br/>
								<xsl:choose>
									<xsl:when test="cf:bookKeepingEntityType = 'O'">
										<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
									</xsl:otherwise>
								</xsl:choose>&#160;other.<br/>
							</td>
						</tr>			
						<tr>
							<td class="label">If this address is a private residence, check this box:</td>
							<td>
								<xsl:choose>
									<xsl:when test="cf:isAddressPrivateResidence = 'Y'">
										<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
									</xsl:otherwise>
								</xsl:choose>&#160;Yes&#160;
								<xsl:choose>
									<xsl:when test="cf:isAddressPrivateResidence = 'N'">
										<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
									</xsl:otherwise>
								</xsl:choose>&#160;No						
							</td>
						</tr>	
						<tr>
							<td class="label">Briefly describe the books and records kept at this location:</td>
							<td>
								<div class="fakeBox3">
								</div>
							</td>
						</tr>
					</table>
				</xsl:otherwise>
			</xsl:choose>
			
			<h4 class="title2">C. Is the <em>funding portal</em> now the subject of or named in any <em>investment-related</em></h4>
			<table role="presentation" id="scheduleD">
				<tr>
					<td class="label">1. Investigation</td>
					<td>
						<xsl:choose>
							<xsl:when test="cf:scheduleD/cf:isInvestigated ='Y'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;Yes&#160;
						<xsl:choose>
							<xsl:when test="cf:scheduleD/cf:isInvestigated ='N'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;No					
					</td>
				</tr>
				<tr>
					<td class="label">2. Investor initiated complaint</td>
					<td>
						<xsl:choose>
							<xsl:when test="cf:scheduleD/cf:investorInitiatedComplaint ='Y'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;Yes&#160;
						<xsl:choose>
							<xsl:when test="cf:scheduleD/cf:investorInitiatedComplaint ='N'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;No					
					</td>				
				</tr>
				<tr>
					<td class="label">3. Private civil litigation</td>
					<td>
						<xsl:choose>
							<xsl:when test="cf:scheduleD/cf:privateCivilLitigation ='Y'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;Yes&#160;
						<xsl:choose>
							<xsl:when test="cf:scheduleD/cf:privateCivilLitigation ='N'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;No					
					</td>				
				</tr>			
			</table>
		</xsl:if>
	</xsl:template>
</xsl:stylesheet>
<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:cf="http://www.sec.gov/edgar/crowdfunding"
	xmlns:drp="http://www.sec.gov/edgar/crowdfunding_drp"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:ns1="http://www.sec.gov/edgar/common"
	xmlns:ns2="http://www.sec.gov/edgar/statecodes" 
	xmlns:ns3="http://www.sec.gov/edgar/common_drp">

	<xsl:variable name="drp2_filedFor">
		<xsl:choose>
			<xsl:when test="cf:edgarSubmission/cf:formData/cf:regulatoryDrpInfo/drp:regulatoryDrp/drp:drpFiledFor = 'Applicant (the funding portal)'">
				<xsl:value-of select="cf:edgarSubmission/cf:formData/cf:regulatoryDrpInfo/drp:regulatoryDrp/drp:drpFiledFor"/>
			</xsl:when>
			<xsl:when test="contains(cf:edgarSubmission/cf:formData/cf:regulatoryDrpInfo/drp:regulatoryDrp/drp:drpFiledFor , 'and one or more of the applicant')">
				<xsl:value-of select="cf:edgarSubmission/cf:formData/cf:regulatoryDrpInfo/drp:regulatoryDrp/drp:drpFiledFor"/>
			</xsl:when>
			<xsl:when test="not(contains(cf:edgarSubmission/cf:formData/cf:regulatoryDrpInfo/drp:regulatoryDrp/drp:drpFiledFor , 'Applicant'))">
				<xsl:value-of select="cf:edgarSubmission/cf:formData/cf:regulatoryDrpInfo/drp:regulatoryDrp/drp:drpFiledFor"/>
			</xsl:when>
		</xsl:choose>
	</xsl:variable>

	<xsl:template name="regulatoryAction">
		<xsl:if test="count(cf:regulatoryDrpInfo/drp:regulatoryDrp) &gt; 0">
			<h1>REGULATORY ACTION DISCLOSURE REPORTING PAGE (FP)</h1>
			<h4 class="title1"><em>GENERAL INSTRUCTIONS</em></h4>
			<div class="information">
				<p>
					You must provide a valid response to each question on every section of this DRP before 
					any of your information can be saved. Invalid or incomplete responses will prevent you 
					from closing the DRP with your information saved. It is recommended that you consult 
					the Print Form of this DRP to make sure you have gathered all the required information 
					before beginning your entry of information online.			
				</p>		
			</div>
			
			<xsl:for-each select="cf:regulatoryDrpInfo/drp:regulatoryDrp">
				<xsl:call-template name="drp2_general"/>
				<xsl:call-template name="dpr2_part1"/>
				<xsl:if test="$drp2_filedFor = 'Applicant (the funding portal)' or contains($drp2_filedFor, 'and one or more of the applicant')">
					<xsl:for-each select="drp:applicant">
						<xsl:call-template name="drp2_applicant"/>
						<xsl:call-template name="drp2_part2"/>
					</xsl:for-each>
				</xsl:if>
				<xsl:if test="contains($drp2_filedFor, 'and one or more of the applicant') or not(contains($drp2_filedFor , 'Applicant'))">
					<xsl:for-each select="drp:associatedPerson">
						<xsl:call-template name="drp2_associatedPerson"/>
						<xsl:call-template name="drp2_part2"/>
					</xsl:for-each>
				</xsl:if>
			</xsl:for-each>		
		</xsl:if>
	</xsl:template>
	
	<xsl:template name="drp2_general">
		<table role="presentation">
			<tr>
				<td class="label">
					This Disclosure Reporting Page (DRP FP) is an INITIAL <em>OR</em> AMENDED response used 
					to report details for affirmative responses to Items 5-C, 5-E, 5-F, or 5-G of Form Funding Portal.
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="contains(drp:initialOrAmended, 'INITIAL')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;INITIAL&#160;
					<xsl:choose>
						<xsl:when test="contains(drp:initialOrAmended, 'AMENDED')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;AMENDED
				</td>
			</tr>
			<!-- VARIABLES BEGIN -->
				<xsl:variable name="drp1_response_1">
					<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
						<xsl:if test=". = '5-C(1)'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="drp1_response_2">
					<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
						<xsl:if test=". = '5-C(2)'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="drp1_response_3">
					<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
						<xsl:if test=". = '5-C(3)'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="drp1_response_4">
					<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
						<xsl:if test=". = '5-C(4)'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="drp1_response_5">
					<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
						<xsl:if test=". = '5-C(5)'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="drp1_response_6">
					<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
						<xsl:if test=". = '5-D(1)'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="drp1_response_7">
					<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
						<xsl:if test=". = '5-D(2)'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="drp1_response_8">
					<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
						<xsl:if test=". = '5-D(3)'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="drp1_response_9">
					<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
						<xsl:if test=". = '5-D(4)'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="drp1_response_10">
					<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
						<xsl:if test=". = '5-D(5)'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="drp1_response_11">
					<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
						<xsl:if test=". = '5-E(1)'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="drp1_response_12">
					<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
						<xsl:if test=". = '5-E(2)'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="drp1_response_13">
					<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
						<xsl:if test=". = '5-E(3)'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="drp1_response_14">
					<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
						<xsl:if test=". = '5-E(4)'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="drp1_response_15">
					<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
						<xsl:if test=". = '5-F'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="drp1_response_16">
					<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
						<xsl:if test=". = '5-G'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
			<!-- VARIABLES END -->
			<tr>
				<td class="label">Check item(s) being responded to:</td>
				<td>
					<table role="presentation">
						<tr>
							<td>
								<xsl:choose>
									<xsl:when test="$drp1_response_1 = '5-C(1)'">
										<img src="Images/box-checked.jpg" alt="Checkbox checked" />
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
									</xsl:otherwise>
								</xsl:choose>&#160;5-C(1)
							</td>
							<td>
								<xsl:choose>
									<xsl:when test="$drp1_response_2 = '5-C(2)'">
										<img src="Images/box-checked.jpg" alt="Checkbox checked" />
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
									</xsl:otherwise>
								</xsl:choose>&#160;5-C(2)
							</td>
							<td>
								<xsl:choose>
									<xsl:when test="$drp1_response_3 = '5-C(3)'">
										<img src="Images/box-checked.jpg" alt="Checkbox checked" />
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
									</xsl:otherwise>
								</xsl:choose>&#160;5-C(3)
							</td>
							<td>
								<xsl:choose>
									<xsl:when test="$drp1_response_4='5-C(4)'">
										<img src="Images/box-checked.jpg" alt="Checkbox checked" />
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
									</xsl:otherwise>
								</xsl:choose>&#160;5-C(4)
							</td>
							<td>
								<xsl:choose>
									<xsl:when test="$drp1_response_5= '5-C(5)'">
										<img src="Images/box-checked.jpg" alt="Checkbox checked" />
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
									</xsl:otherwise>
								</xsl:choose>&#160;5-C(5)
							</td>
							<td>
								<xsl:choose>
									<xsl:when test="$drp1_response_6='5-D(1)'">
										<img src="Images/box-checked.jpg" alt="Checkbox checked" />
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
									</xsl:otherwise>
								</xsl:choose>&#160;5-D(1)
							</td>
							<td>
								<xsl:choose>
									<xsl:when test="$drp1_response_7 = '5-D(2)'">
										<img src="Images/box-checked.jpg" alt="Checkbox checked" />
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
									</xsl:otherwise>
								</xsl:choose>&#160;5-D(2)
							</td>
							<td>
								<xsl:choose>
									<xsl:when test="$drp1_response_8= '5-D(3)'">
										<img src="Images/box-checked.jpg" alt="Checkbox checked" />
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
									</xsl:otherwise>
								</xsl:choose>&#160;5-D(3)
							</td>
							<td>
								<xsl:choose>
									<xsl:when test="$drp1_response_9='5-D(4)'">
										<img src="Images/box-checked.jpg" alt="Checkbox checked" />
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
									</xsl:otherwise>
								</xsl:choose>&#160;5-D(4)
							</td>
							<td>
								<xsl:choose>
									<xsl:when test="$drp1_response_10= '5-D(5)'">
										<img src="Images/box-checked.jpg" alt="Checkbox checked" />
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
									</xsl:otherwise>
								</xsl:choose>&#160;5-D(5)
							</td>
						</tr>
						<tr>
							<td>
								<xsl:choose>
									<xsl:when test="$drp1_response_11= '5-E(1)'">
										<img src="Images/box-checked.jpg" alt="Checkbox checked" />
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
									</xsl:otherwise>
								</xsl:choose>&#160;5-E(1)
							</td>
							<td>
								<xsl:choose>
									<xsl:when test="$drp1_response_12 = '5-E(2)'">
										<img src="Images/box-checked.jpg" alt="Checkbox checked" />
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
									</xsl:otherwise>
								</xsl:choose>&#160;5-E(2)
							</td>
							<td>
								<xsl:choose>
									<xsl:when test="$drp1_response_13 = '5-E(3)'">
										<img src="Images/box-checked.jpg" alt="Checkbox checked" />
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
									</xsl:otherwise>
								</xsl:choose>&#160;5-E(3)
							</td>
							<td>
								<xsl:choose>
									<xsl:when test="$drp1_response_14 = '5-E(4)'">
										<img src="Images/box-checked.jpg" alt="Checkbox checked" />
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
									</xsl:otherwise>
								</xsl:choose>&#160;5-E(4)
							</td>
							<td>
								<xsl:choose>
									<xsl:when test="$drp1_response_15 ='5-F'">
										<img src="Images/box-checked.jpg" alt="Checkbox checked" />
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
									</xsl:otherwise>
								</xsl:choose>&#160;5-F
							</td>
							<td>
								<xsl:choose>
									<xsl:when test="$drp1_response_16 = '5-G'">
										<img src="Images/box-checked.jpg" alt="Checkbox checked" />
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
									</xsl:otherwise>
								</xsl:choose>&#160;5-G
							</td>
							<td>&#160;</td>
							<td>&#160;</td>
							<td>&#160;</td>
							<td>&#160;</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
		
		<div class="information">	
			<p>
				Use a separate DRP for each event or proceeding.  An event or proceeding may be 
				reported for more than one person or entity using one DRP.  File with a completed 
				Execution Page.
				<br/><br/>
				One event may result in more than one affirmative answer to Items 5-C, 
				5-D, 5-E, 5- F or 5-G.  Use only one DRP to report details related to 
				the same event.  If an event gives rise to actions by more than one regulator, 
				provide details for each action on a separate DRP.
			</p>
		</div>
	</xsl:template>
	<xsl:template name="dpr2_part1">
		<h4 class="title2"><em>Part 1</em></h4>
		<table role="presentation">
			<tr>
				<td class="label">
					The <em>person</em>(s) or entity(ies) for whom this DRP is being filed is (are) the:
				</td>
				<td></td>
			</tr>
			<tr>
				<td class="label">Select only one:</td>
				<td>
					<xsl:choose>
						<xsl:when test="drp:drpFiledFor = 'Applicant (the funding portal)'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;<em>Applicant (the funding portal)</em> <br/>
					<xsl:choose>
						<xsl:when test="contains(drp:drpFiledFor, 'and one or more of the applicant')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;<em>Applicant and one or more of the applicant's associated person(s)</em><br/>
					<xsl:choose>
						<xsl:when test="not(contains(drp:drpFiledFor, 'Applicant'))">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;One or more of <em>applicant</em>'s <em>associated person(s)</em>
				</td>
			</tr>
		</table>
	</xsl:template>
	<xsl:template name="drp2_applicant">
		<h4 class="title2"><u>Applicant</u></h4>
		<xsl:if test="$submissionType = 'CFPORTAL/A' or $submissionType = 'CFPORTAL-W'">
			<table role="presentation">
				<tr>
					<td class="label">
						If this DRP is being filed for the applicant, and it is an amendment that seeks to remove 
						a DRP concerning the applicant from the record, the reason the DRP should be removed is:
					</td>
					<td>
						<xsl:choose>
							<xsl:when test="contains(drp:drpRemovalReason, 'applicant is registered')">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;The <em>applicant</em> is registered or applying for 
						registration and the event or <em>proceeding</em> was resolved in the <em>applicant'</em>s favor.<br/>
						<xsl:choose>
							<xsl:when test="contains(drp:drpRemovalReason , 'error')">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;The DRP was filed in error.				
					</td>
				</tr>
			</table>
		</xsl:if>
	</xsl:template>
	<xsl:template name="drp2_associatedPerson">
		<h4 class="title2"><u>Associated Person</u></h4>
		<table role="presentation">
			<tr>
				<td class="label">If this DRP is being filed for an <em>associated person</em>:</td>
			<td></td>
			</tr>
			<tr>
				<td class="label"><blockquote>The <em>associated person</em> is:</blockquote></td>
				<td>
					<xsl:choose>
						<xsl:when test="drp:associatedPersonDetails/drp:personType = 'a firm'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;a firm&#160;&#160;
					<xsl:choose>
						<xsl:when test="drp:associatedPersonDetails/drp:personType = 'a natural person'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;a natural person							
				</td>
			</tr>	
			<tr>
				<td class="label"><blockquote>This <em>associated person</em> is:</blockquote></td>
				<td>
					<xsl:choose>
						<xsl:when test="contains(drp:associatedPersonDetails/drp:personRegistered, 'is registered')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;registered with the <em>SEC</em>&#160;&#160;
					<xsl:choose>
						<xsl:when test="contains(drp:associatedPersonDetails/drp:personRegistered, 'not')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;The <em>associated person</em> is not registered with the <em>SEC</em>
				</td>
			</tr>						
			<tr>
				<td class="label"><blockquote>Full name of the <em>associated person</em> 
				(including, for natural persons, last, first and middle names):</blockquote>
				</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:associatedPersonDetails/drp:fullName"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label"><blockquote>If the <em>associated person</em> has a <em>CRD</em> number, provide that number.</blockquote></td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="drp:associatedPersonDetails/drp:crdNumber"/>
					</div>
				</td>
			</tr>
			<xsl:if test="$submissionType = 'CFPORTAL/A'">
				<tr>
					<td class="label">
						If this is an amendment that seeks to remove a DRP concerning the <em>associated person</em>, the reason the DRP should be removed is:
					</td>
					<td>
						<xsl:choose>
							<xsl:when test="contains(drp:drpRemovalReason, 'no longer')">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;The <em>associated person</em>(s) is (are) no longer associated with the <em>applicant</em>.<br/>
						<xsl:choose>
							<xsl:when test="contains(drp:drpRemovalReason, 'was resolved in the')">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;The event or <em>proceeding</em> was resolved in the <em>associated person'</em>s favor.<br/>
						<xsl:choose>
							<xsl:when test="contains(drp:drpRemovalReason, 'error')">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;The DRP was filed in error.
					</td>
				</tr>
				<xsl:if test="contains(drp:drpRemovalReason, 'error')">
					<tr>
						<td class="label">
							<blockquote>
								Explain the circumstances:
							</blockquote>
						</td>
						<td>
							<div class="fakeBox3">
								<xsl:value-of select="drp:circumstancesExplanation"/>
							</div>
						</td>
					</tr>
				</xsl:if>
			</xsl:if>
		</table>
	</xsl:template>
	<xsl:template name="drp2_part2">
		<blockquote>
			<h4 class="title2"><em>Part 2</em></h4>
		</blockquote>
		<table role="presentation">
			<tr>
				<td class="label">1. Regulatory Action was initiated by :</td>
				<td>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:regulatoryActionInitiatedBy = 'SEC'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;<em>SEC</em><br/>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:regulatoryActionInitiatedBy = 'Foreign Authority'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Foreign Authority<br/>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:regulatoryActionInitiatedBy = 'Other Federal Authority'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Other Federal Authority<br/>						
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:regulatoryActionInitiatedBy = 'State'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;State<br/>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:regulatoryActionInitiatedBy = 'SRO'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;<em>SRO</em>
				</td>
			</tr>
			<tr>
				<td class="label"><blockquote>(Full name of regulator, <em>foreign financial regulatory authority,</em> 
					federal authority, state or <em>SRO</em>)</blockquote>
				</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:regulatoryDrpDetails/drp:regulatorName"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">2. Principal Sanction (check appropriate item):</td>
				<td>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalSanction 
									= 'Civil and Administrative Penalty(ies)/Fine(s)'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Civil and Administrative Penalty(ies)/Fine(s)<br/>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalSanction = 'Restitution'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Restitution <br/>							
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalSanction = 'Bar'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Bar<br/>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalSanction = 'Cease and Desist'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Cease and Desist<br/>									
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalSanction = 'Censure'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Censure<br/>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalSanction = 'Denial'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Denial<br/>							
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalSanction = 'Expulsion'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Expulsion<br/>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalSanction = 'Revocation'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Revocation<br/>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalSanction = 'Injunction'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Injunction<br/>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalSanction = 'Prohibition'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Prohibition<br/>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalSanction = 'Reprimand'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Reprimand<br/>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalSanction = 'Disgorgement'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Disgorgement<br/>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalSanction = 'Suspension'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Suspension<br/>		
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalSanction = 'Undertaking'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Undertaking<br/>	
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalSanction = 'Other'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Other
				</td>
			</tr>
			<xsl:if test="drp:regulatoryDrpDetails/drp:principalSanction = 'Other'">
				<tr>
					<td class="label"><blockquote>If Other is selected, please specify</blockquote></td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="drp:regulatoryDrpDetails/drp:otherPrincipalSanctionDesc"/>
						</div>
					</td>
				</tr>
			</xsl:if>
			<tr>
				<td class="label"><blockquote>Other Sanctions:</blockquote></td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:regulatoryDrpDetails/drp:otherSanctionsDesc"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">3. Date Initiated (MM/DD/YYYY):</td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="drp:regulatoryDrpDetails/drp:dateInitiated/ns1:date"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>Specify if Date Initiated is Exact or needs an Explanation</blockquote>
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:dateInitiated/ns1:exactOrExplanation = 'Exact'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Exact&#160;&#160;
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:dateInitiated/ns1:exactOrExplanation = 'Explanation'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Explanation					
				</td>
			</tr>					
			<xsl:if test="drp:regulatoryDrpDetails/drp:dateInitiated/ns1:exactOrExplanation = 'Explanation'">
				<tr>
					<td class="label">
						<blockquote>
							<blockquote>
								If not exact, provide explanation:
							</blockquote>
						</blockquote>
					</td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="drp:regulatoryDrpDetails/drp:dateInitiated/ns1:explanationInfo"/>
						</div>
					</td>
				</tr>
			</xsl:if>
			<tr>
				<td class="label">4. Docket/Case Number:</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:regulatoryDrpDetails/drp:docketOrCaseNumber"/>
					</div>
				</td>
			</tr>
			<xsl:if test="count(drp:associatedPersonDetails) &gt; 0">
				<tr>
					<td class="label">5. <em>Associated person'</em>s Employing Firm when activity 
					occurred that led to the regulatory action (if applicable):</td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="drp:regulatoryDrpDetails/drp:apEmployingFirm"/>
						</div>
					</td>
				</tr>
			</xsl:if>
			<tr>
				<td class="label">
					6.Principal Product Type (check appropriate item):
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalProductType = 'Annuity(ies) - Fixed'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Annuity(ies) - Fixed<br/>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalProductType = 'Annuity(ies) - Variable'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Annuity(ies) - Variable<br/>	
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalProductType = 'Money Market Fund(s)'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Money Market Fund(s)<br/>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalProductType = 'CD(s)'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;CD(s)<br/>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalProductType = 'Commodity Option(s)'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Commodity Option(s)<br/>	
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalProductType = 'Debt - Asset Backed'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Debt - Asset Backed<br/>							
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalProductType = 'Debt - Corporate'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Debt - Corporate<br/>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalProductType = 'Debt - Government'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Debt - Government<br/>	
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalProductType = 'Debt - Municipal'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Debt - Municipal<br/>								
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalProductType = 'Derivative(s)'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Derivative(s)<br/>	
					<xsl:choose>
						<xsl:when test="contains(drp:regulatoryDrpDetails/drp:principalProductType, 'Direct Investment(s)')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Direct Investment(s) - DPP &amp; LP Interest(s)<br/>							
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalProductType = 'Equity - OTC'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Equity - OTC<br/>	
					<xsl:choose>
						<xsl:when test="contains(drp:regulatoryDrpDetails/drp:principalProductType, 'Equity Listed')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Equity Listed (Common &amp; Preferred Stock)<br/>							
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalProductType = 'Futures - Commodity'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Futures - Commodity<br/>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalProductType = 'Futures - Financial'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Futures - Financial<br/>	
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalProductType = 'Index Option(s)'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Index Option(s)<br/>							
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalProductType = 'Insurance'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Insurance<br/>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalProductType = 'Investment Contract(s)'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Investment Contract(s)<br/>	
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalProductType = 'Mutual Fund(s)'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Mutual Fund(s)<br/>								
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalProductType = 'Options'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Options<br/>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalProductType = 'Penny Stock(s)'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Penny Stock(s)<br/>	
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalProductType = 'Unit Investment Trust(s)'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Unit Investment Trust(s)<br/>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalProductType = 'Other'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Other<br/>		
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:principalProductType = 'No Product'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;No Product
				</td>
			</tr>	
			<xsl:if test="drp:regulatoryDrpDetails/drp:principalProductType = 'Other'">
				<tr>
					<td class="label"><blockquote>If Other is selected, please specify:</blockquote></td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="drp:regulatoryDrpDetails/drp:principalProductTypeOtherDesc"/>
						</div>
					</td>
				</tr>
			</xsl:if>	
			<tr>
				<td class="label"><blockquote>Other Product Types:</blockquote></td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:regulatoryDrpDetails/drp:otherProductDesc"/>
					</div>
				</td>
			</tr>						
			<tr>
				<td class="label">7. Describe the allegations related to this regulatory action.
				(The response must fit within the space provided.)</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:regulatoryDrpDetails/drp:descAllegations"/>
					</div>
				</td>
			</tr>	
			<tr>
				<td class="label">8. Current status of the event?</td>
				<td>
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:currentStatus = 'Pending'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Pending&#160;&#160;
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:currentStatus = 'On Appeal'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;On Appeal&#160;&#160;	
					<xsl:choose>
						<xsl:when test="drp:regulatoryDrpDetails/drp:currentStatus = 'Final'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Final							
				</td>
			</tr>						
			<xsl:if test="drp:regulatoryDrpDetails/drp:currentStatus = 'On Appeal'">				
				<tr>
					<td class="label">9. If on appeal, to whom the regulatory action was
					appealed (<em>SEC, SRO,</em> Federal or State Court) and date appeal filed:</td>
					<td>
						<div class="fakeBox3">
								<xsl:value-of select="drp:regulatoryDrpDetails/drp:appealedTo"/>
						</div>
					</td>
				</tr>
			</xsl:if>
			<tr>
				<td colspan="2" style="padding:0">
					<div class="information">
						<p>
							If Final or On Appeal, complete all items below.  For Pending Actions, complete Item 13 only.
						</p>
					</div>
				</td>
			</tr>
			<xsl:if test="not(contains(drp:regulatoryDrpDetails/drp:currentStatus , 'Pending'))">
				<tr>
					<td class="label">10. How was matter resolved (check appropriate item):</td>
					<td>
						<xsl:choose>
							<xsl:when test="contains(drp:regulatoryDrpDetails/drp:matterResolvedType, 'Acceptance')">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;Acceptance, Waiver &amp; Consent (AWC)<br/>
						<xsl:choose>
							<xsl:when test="drp:regulatoryDrpDetails/drp:matterResolvedType='Consent'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;Consent<br/>							
						<xsl:choose>
							<xsl:when test="drp:regulatoryDrpDetails/drp:matterResolvedType='Decision'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;Decision<br/>	
						<xsl:choose>
							<xsl:when test="contains(drp:regulatoryDrpDetails/drp:matterResolvedType, 'Order of Offer')">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;Decision &amp; Order of Offer of Settlement<br/> 
						<xsl:choose>
							<xsl:when test="drp:regulatoryDrpDetails/drp:matterResolvedType='Dismissed'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;Dismissed<br/>	
						<xsl:choose>
							<xsl:when test="drp:regulatoryDrpDetails/drp:matterResolvedType='Withdrawn'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;Withdrawn<br/>								
						<xsl:choose>
							<xsl:when test="drp:regulatoryDrpDetails/drp:matterResolvedType='Settled'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;Settled<br/>		
						<xsl:choose>
							<xsl:when test="contains(drp:regulatoryDrpDetails/drp:matterResolvedType, 'Stipulation')">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;Stipulation &amp; Consent<br/>
						<xsl:choose>
							<xsl:when test="drp:regulatoryDrpDetails/drp:matterResolvedType='Vacated'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;Vacated<br/>
						<xsl:choose>
							<xsl:when test="drp:regulatoryDrpDetails/drp:matterResolvedType='Order'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;<em>Order</em><br/>
						<xsl:choose>
							<xsl:when test="drp:regulatoryDrpDetails/drp:matterResolvedType='Other'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;Other
					</td>
				</tr>
				<xsl:if test="drp:regulatoryDrpDetails/drp:matterResolvedType='Other'">
					<tr>
						<td class="label"><blockquote>If Other is selected, please specify:</blockquote></td>
						<td>
							<div class="fakeBox3">
								<xsl:value-of select="drp:regulatoryDrpDetails/drp:matterResolvedTypeOtherDesc"/>
							</div>
						</td>
					</tr>
				</xsl:if>
				<tr>
					<td class="label">11. Resolution Date (MM/DD/YYYY): </td>
					<td>
						<div class="fakeBox2">
							<xsl:value-of select="drp:regulatoryDrpDetails/drp:resolutionDateExactExplain/ns1:date"/>
						</div>
					</td>
				</tr>	
				<tr>
					<td class="label">
						<blockquote>Specify if Resolution Date is Exact or needs an Explanation</blockquote></td>
					<td>
						<xsl:choose>
							<xsl:when test="drp:regulatoryDrpDetails/drp:resolutionDateExactExplain/ns1:exactOrExplanation = 'Exact'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;Exact&#160;&#160;
						<xsl:choose>
							<xsl:when test="drp:regulatoryDrpDetails/drp:resolutionDateExactExplain/ns1:exactOrExplanation = 'Explanation'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;Explanation								
					</td>
				</tr>
				<xsl:if test="drp:regulatoryDrpDetails/drp:resolutionDateExactExplain/ns1:exactOrExplanation = 'Explanation'">
					<tr>
						<td class="label">
							<blockquote>
								<blockquote>
									If not exact, provide explanation:
								</blockquote>
							</blockquote>
						</td>
						<td>
							<div class="fakeBox3">
								<xsl:value-of select="drp:regulatoryDrpDetails/drp:resolutionDateExactExplain/ns1:explanationInfo"/>
							</div>
						</td>
					</tr>
				</xsl:if>

				<xsl:variable name="element12_moneytary">
					<xsl:for-each select="drp:regulatoryDrpDetails/drp:sanctionsOrderedDetails/drp:sanctionsOrdered/drp:sanctionOrdered">
						<xsl:if test="contains(. , 'Monetary')"><xsl:value-of select="."/></xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="element12_moneytary_bar">
					<xsl:for-each select="drp:regulatoryDrpDetails/drp:sanctionsOrderedDetails/drp:sanctionsOrdered/drp:sanctionOrdered">
						<xsl:if test="contains(. , 'Bar')"><xsl:value-of select="."/></xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="element12_moneytary_revocation">
					<xsl:for-each select="drp:regulatoryDrpDetails/drp:sanctionsOrderedDetails/drp:sanctionsOrdered/drp:sanctionOrdered">
						<xsl:if test="contains(. , 'Revocation')"><xsl:value-of select="."/></xsl:if>
					</xsl:for-each>
				</xsl:variable>	
				<xsl:variable name="element12_moneytary_disgorgement">
					<xsl:for-each select="drp:regulatoryDrpDetails/drp:sanctionsOrderedDetails/drp:sanctionsOrdered/drp:sanctionOrdered">
						<xsl:if test="contains(. , 'Disgorgement')"><xsl:value-of select="."/></xsl:if>
					</xsl:for-each>
				</xsl:variable>	
				<xsl:variable name="element12_moneytary_cease">
					<xsl:for-each select="drp:regulatoryDrpDetails/drp:sanctionsOrderedDetails/drp:sanctionsOrdered/drp:sanctionOrdered">
						<xsl:if test="contains(. , 'Cease')"><xsl:value-of select="."/></xsl:if>
					</xsl:for-each>
				</xsl:variable>	
				<xsl:variable name="element12_moneytary_censure">
					<xsl:for-each select="drp:regulatoryDrpDetails/drp:sanctionsOrderedDetails/drp:sanctionsOrdered/drp:sanctionOrdered">
						<xsl:if test="contains(. , 'Censure')"><xsl:value-of select="."/></xsl:if>
					</xsl:for-each>
				</xsl:variable>	
				<xsl:variable name="element12_moneytary_suspension">
					<xsl:for-each select="drp:regulatoryDrpDetails/drp:sanctionsOrderedDetails/drp:sanctionsOrdered/drp:sanctionOrdered">
						<xsl:if test="contains(. , 'Suspension')"><xsl:value-of select="."/></xsl:if>
					</xsl:for-each>
				</xsl:variable>		
				<tr>
					<td class="label">
						12. Resolution Detail:<br/><br/>
						<blockquote>
							A. Were any of the following Sanctions Ordered (check appropriate item):
						</blockquote>
					</td>
					<td>
						<br/><br/>						
						<xsl:choose>
							<xsl:when test="contains($element12_moneytary , 'Fine')">
								<img src="Images/box-checked.jpg" alt="Checkbox checked" />
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
							</xsl:otherwise>
						</xsl:choose>&#160;Monetary/Fine<br/>
						<xsl:choose>
							<xsl:when test="$element12_moneytary_bar = 'Bar'">
								<img src="Images/box-checked.jpg" alt="Checkbox checked" />
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
							</xsl:otherwise>
						</xsl:choose>&#160;Bar<br/>
						<xsl:choose>
							<xsl:when test="contains($element12_moneytary_revocation , 'Revocation')">
								<img src="Images/box-checked.jpg" alt="Checkbox checked" />
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
							</xsl:otherwise>
						</xsl:choose>&#160;Revocation/Expulsion/Denial<br/>
						<xsl:choose>
							<xsl:when test="$element12_moneytary_disgorgement = 'Disgorgement'">
								<img src="Images/box-checked.jpg" alt="Checkbox checked" />
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
							</xsl:otherwise>
						</xsl:choose>&#160;Disgorgement<br/>
						<xsl:choose>
							<xsl:when test="contains($element12_moneytary_cease , 'Cease')">
								<img src="Images/box-checked.jpg" alt="Checkbox checked" />
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
							</xsl:otherwise>
						</xsl:choose>&#160;Cease and Desist/ Injunction<br/>
						<xsl:choose>
							<xsl:when test="$element12_moneytary_censure = 'Censure'">
								<img src="Images/box-checked.jpg" alt="Checkbox checked" />
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
							</xsl:otherwise>
						</xsl:choose>&#160;Censure<br/>						
						<xsl:choose>
							<xsl:when test="$element12_moneytary_suspension = 'Suspension'">
								<img src="Images/box-checked.jpg" alt="Checkbox checked" />
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
							</xsl:otherwise>
						</xsl:choose>&#160;Suspension	
					</td>
				</tr>
				
				<xsl:if test="contains($element12_moneytary , 'Monetary')">
					<tr>
						<td class="label">
							<blockquote>
								<blockquote>
									Amount:
								</blockquote>
							</blockquote>
						</td>
						<td>
							<div class="fakeBox2">
								<xsl:if test="count(drp:regulatoryDrpDetails/drp:sanctionsOrderedDetails/drp:amountPaid) &gt; 0">
									<xsl:value-of select='format-number(drp:regulatoryDrpDetails/drp:sanctionsOrderedDetails/drp:amountPaid , "$###,###,###,##0.00")' />
								</xsl:if>
							</div>
						</td>
					</tr>
				</xsl:if>
				<tr>
					<td class="label">
						<blockquote>B. Other Sanctions Ordered:</blockquote>
					</td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="drp:regulatoryDrpDetails/drp:sanctionsOrderedDetails/drp:otherSanctions"/>
						</div>
					</td>
				</tr>
				<tr>
					<td class="label"><blockquote>C. Sanction detail:  If suspended, <em>enjoined</em> or barred, 
						provide duration including start date and capacities affected (General 
						Securities Principal, Financial Operations Principal, etc.).  If requalification 
						by exam/retraining was a condition of the sanction, provide length of time given 
						to requalify/retrain, type of exam required and whether condition has been satisfied. 
						If disposition resulted in a fine, penalty, restitution, disgorgement or monetary compensation, 
						provide total amount, portion levied against the applicant or an <em>associated person,</em> 
						date paid and if any portion of penalty was waived:</blockquote>
					</td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="drp:regulatoryDrpDetails/drp:sanctionsOrderedDetails/drp:sanctionDetail"/>
						</div>
					</td>
				</tr>
			</xsl:if>
			<tr>
				<td class="label">
					13. Provide a brief summary of details related to 
					the action status and (or) disposition, and include relevant terms, 
					conditions and dates:
				</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:regulatoryDrpDetails/drp:summaryOfDetails"/>
					</div>
				</td>
			</tr>				
		</table>	
	</xsl:template>
</xsl:stylesheet>
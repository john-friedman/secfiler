<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:cf="http://www.sec.gov/edgar/crowdfunding"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:ns1="http://www.sec.gov/edgar/common"
	xmlns:ns2="http://www.sec.gov/edgar/statecodes" 
	xmlns:ns3="http://www.sec.gov/edgar/common_drp">

	<xsl:template name="tab7">
		<h1><xsl:value-of select="$submissionType"/>: Qualified Third Party Arrangements; Compensation Arrangements</h1>
		<table role="presentation">
			<tr>
				<td class="label">
					A. Qualified Third Party Arrangements. Complete the following information 
					for each <em>person</em> that will hold investor funds in escrow or otherwise pursuant 
					to the requirements of Rule 303(e) of Regulation Crowdfunding (17 CFR 227.303(e)).								
				</td>
				<td></td>
			</tr>
			<xsl:for-each select="cf:escrowArrangements/cf:investorFundsContacts">
				<tr>
					<td class="label">
						<blockquote>Name of <em>person</em>:</blockquote>
					</td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="cf:investorFundsContactName"/>
						</div>
					</td>
				</tr>
				<tr>
					<td class="label">
						<blockquote>Address 1:
						</blockquote>
					</td>
					<td>
						<div class="fakeBox">
							<xsl:value-of select="cf:investorFundsAddress/ns1:street1"/>
						</div>
					</td>
				</tr>
				<tr>
					<td class="label"><blockquote>Address 2:</blockquote></td>
					<td>
						<div class="fakeBox">
							<xsl:value-of select="cf:investorFundsAddress/ns1:street2"/>
						</div>
					</td>
				</tr>
				<tr>
					<td class="label"><blockquote>City:</blockquote></td>
					<td>
						<div class="fakeBox">
							<xsl:value-of select="cf:investorFundsAddress/ns1:city"/>
						</div>
					</td>
				</tr>
				<tr>
					<td class="label"><blockquote>State/Country:</blockquote></td>
					<td>
						<div class="fakeBox">
							<xsl:call-template name="stateDescription">
								<xsl:with-param name="stateCode" 
									select="cf:investorFundsAddress/ns1:stateOrCountry" />
							</xsl:call-template>
						</div>					
					</td>
				</tr>
				<tr>
					<td class="label"><blockquote>Mailing Zip/ Postal Code:</blockquote></td>
					<td>
						<div class="fakeBox2">
							<xsl:value-of select="cf:investorFundsAddress/ns1:zipCode"/>
						</div>
					</td>
				</tr>	
				<tr>
					<td class="label"><blockquote>Phone Number:</blockquote></td>
					<td>
						<div class="fakeBox2">
							<xsl:value-of select="cf:investorFundsContactPhone"/>
						</div>
					</td>
				</tr>
			</xsl:for-each>
			<tr>
				<td class="label">
					B. Compensation. Please describe any compensation arrangements <em>the funding portal</em> has with issuers.
				</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="cf:escrowArrangements/cf:compensationDesc"/>
					</div>
				</td>
			</tr>			
		</table>
	
	</xsl:template>
	
</xsl:stylesheet>
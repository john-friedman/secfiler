<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:cf="http://www.sec.gov/edgar/crowdfunding"
	xmlns:drp="http://www.sec.gov/edgar/crowdfunding_drp"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:ns1="http://www.sec.gov/edgar/common"
	xmlns:ns2="http://www.sec.gov/edgar/statecodes" 
	xmlns:ns3="http://www.sec.gov/edgar/common_drp">

	<xsl:template name="judgementLien">
		<xsl:for-each select="cf:judgementDrpInfo/drp:judgementDrp">
			<h1>JUDGEMENT/LIEN DISCLOSURE REPORTING PAGE (FP)</h1>
			<h4 class="title1">GENERAL INSTRUCTIONS</h4>
			<div class="information">
				<p>
					You must provide a valid response to each question on every section of this DRP before 
					any of your information can be saved. Invalid or incomplete responses will prevent you 
					from closing the DRP with your information saved. It is recommended that you consult 
					the Print Form of this DRP to make sure you have gathered all the required information 
					before beginning your entry of information online.			
				</p>		
			</div>
			<table role="presentation">
				<tr>
					<td class="label">
						This Disclosure Reporting Page (DRP FP) is an INITIAL <b><em>OR</em></b> AMENDED response 
						used to report details for affirmative responses to Item 5-L of Form Funding Portal.
					</td>
					<td>
						<xsl:choose>
							<xsl:when test="drp:initialOrAmended='INITIAL'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;INITIAL&#160;
						<xsl:choose>
							<xsl:when test="drp:initialOrAmended='AMENDED'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;AMENDED
					</td>
				</tr>
				<tr>
					<td class="label">Check item(s) being responded to:</td>
					<td>
						<xsl:choose>
							<xsl:when test="drp:respondingTo = '5-L'">
								<img src="Images/box-checked.jpg" alt="Checkbox checked" />
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
							</xsl:otherwise>
						</xsl:choose>&#160;5-L								
					</td>
				</tr>
			</table>
			<div class="information">
				<p>
					Use a separate DRP for each event or <em>proceeding</em>.  An event or <em>proceeding</em> may be reported 
					for more than one <em>person</em> or entity using one DRP.  File with a completed Execution Page.  
					One event may result in more than one affirmative answer to Item 5-L.  Use only one DRP 
					to report details related to the same event.  If an event gives rise to actions by more 
					than one regulator, provide details for each action on a separate DRP.
				</p>
			</div>
			<xsl:if test="drp:respondingTo = '5-L'">
				<table role="presentation">
					<tr>
						<td class="label">1. Judgment/Lien Amount:</td>
						<td>
							<div class="fakeBox2">
								<xsl:if test="count(drp:judgementOrLienAmount) &gt; 0">
									<xsl:value-of select='format-number(drp:judgementOrLienAmount , "$###,###,###,##0.00")' />
								</xsl:if>
							</div>
						</td>
					</tr>
					<tr>
						<td class="label">2. Judgment/Lien Holder:</td>
						<td>
							<div class="fakeBox3">
								<xsl:value-of select="drp:judgementOrLienHolder"/>
							</div>
						</td>
					</tr>
					<tr>
						<td class="label">3. Judgment/Lien Type: (check appropriate item)</td>
						<td>
							<xsl:choose>
								<xsl:when test="drp:judgementOrLienType = 'Civil'">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;Civil&#160;
							<xsl:choose>
								<xsl:when test="drp:judgementOrLienType = 'Default'">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;Default&#160;
							<xsl:choose>
								<xsl:when test="drp:judgementOrLienType = 'Tax'">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;Tax						
						</td>
					</tr>
					<tr>
						<td class="label">4. Date Filed (MM/DD/YYYY): </td>
						<td>
							<div class="fakeBox2">
								<xsl:value-of select="drp:dateFiled/ns1:date"/>
							</div>
						</td>
					</tr>	
					<tr>
						<td class="label"><blockquote>Specify if Disposition Date is Exact or needs an Explanation</blockquote></td>
						<td>
							<xsl:choose>
								<xsl:when test="drp:dateFiled/ns1:exactOrExplanation = 'Exact'">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;Exact&#160;&#160;
							<xsl:choose>
								<xsl:when test="drp:dateFiled/ns1:exactOrExplanation = 'Explanation'">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;Explanation						
						</td>
					</tr>
					<xsl:if test="drp:dateFiled/ns1:exactOrExplanation = 'Explanation'">
						<tr>
							<td class="label"><blockquote><blockquote>If not exact, provide explanation:</blockquote></blockquote></td>
							<td>
								<div class="fakeBox3">
									<xsl:value-of select="drp:dateFiled/ns1:explanationInfo"/>
								</div>
							</td>
						</tr>		
					</xsl:if>
					<tr>
						<td class="label">5. Is Judgment/Lien outstanding?:</td>
						<td>
							<xsl:choose>
								<xsl:when test="drp:judgementLienOutstanding/drp:isJudgementLienOutstanding = 'Y'">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;Yes&#160;
							<xsl:choose>
								<xsl:when test="drp:judgementLienOutstanding/drp:isJudgementLienOutstanding = 'N'">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;No						
						</td>
					</tr>
					<xsl:if test="drp:judgementLienOutstanding/drp:isJudgementLienOutstanding = 'N'">
						<tr>
							<td class="label"><blockquote>If No, provide explanation:</blockquote></td>
							<td>
								<div class="fakeBox3">
									<xsl:value-of select="drp:judgementLienOutstanding/drp:provideExplanationDesc"/>
								</div>
							</td>
						</tr>	
						<tr>
							<td class="label"><blockquote>If No, how was matter resolved? (check appropriate item):</blockquote></td>
							<td>
								<xsl:choose>
									<xsl:when test="drp:judgementLienOutstanding/drp:matterResolved = 'Discharged'">
										<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
									</xsl:otherwise>
								</xsl:choose>&#160;Discharged&#160;&#160;
								<xsl:choose>
									<xsl:when test="drp:judgementLienOutstanding/drp:matterResolved = 'Released'">
										<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
									</xsl:otherwise>
								</xsl:choose>&#160;Released&#160;&#160;
								<xsl:choose>
									<xsl:when test="drp:judgementLienOutstanding/drp:matterResolved = 'Removed'">
										<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
									</xsl:otherwise>
								</xsl:choose>&#160;Removed&#160;&#160;
								<xsl:choose>
									<xsl:when test="drp:judgementLienOutstanding/drp:matterResolved = 'Satisfied'">
										<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
									</xsl:otherwise>
								</xsl:choose>&#160;Satisfied							
							</td>
						</tr>					
					</xsl:if>
					<tr>
						<td class="label">6. Court where judgment was given: (include the).</td>
						<td></td>
					</tr>
					<tr>
						<td class="label">
							<blockquote>
								A. Name of Court:
							</blockquote>
						</td>
						<td>
							<div class="fakeBox3">
								<xsl:value-of select="drp:nameOfCourt"/>
							</div>
						</td>
					</tr>				
					<tr>
						<td class="label">
							<blockquote>
								B. Location of the Court:
							</blockquote>
						</td>
						<td></td>
					</tr>				
					<tr>
						<td class="label"><blockquote><blockquote>Street Address 1:</blockquote></blockquote></td>
						<td>
							<div class="fakeBox">
								<xsl:value-of select="drp:courtAddress/ns1:street1"/>
							</div>
						</td>
					</tr>
					<tr>
						<td class="label"><blockquote><blockquote>Street Address 2:</blockquote></blockquote></td>
						<td>
							<div class="fakeBox">
								<xsl:value-of select="drp:courtAddress/ns1:street2"/>
							</div>
						</td>
					</tr>
					<tr>
						<td class="label"><blockquote><blockquote>City or County:</blockquote></blockquote></td>
						<td>
							<div class="fakeBox">
								<xsl:value-of select="drp:courtAddress/ns1:city"/>
							</div>
						</td>
					</tr>
					<tr>
						<td class="label"><blockquote><blockquote>State/Country:</blockquote></blockquote></td>
						<td>
							<div class="fakeBox">
								<xsl:call-template name="stateDescription">
									<xsl:with-param name="stateCode" select="drp:courtAddress/ns1:stateOrCountry" />
								</xsl:call-template>
							</div>														
						</td>
					</tr>
					<tr>
						<td class="label"><blockquote><blockquote>Postal Code:</blockquote></blockquote></td>
						<td>
							<div class="fakeBox">
								<xsl:value-of select="drp:courtAddress/ns1:zipCode"/>
							</div>
						</td>
					</tr>
					<tr>
						<td class="label"><blockquote>C. Docket/Case Number:</blockquote></td>
						<td>
							<div class="fakeBox3">
								<xsl:value-of select="drp:docketOrCaseNumber"/>
							</div>
						</td>
					</tr>
					<tr>
						<td class="label">7. Provide a brief summary of events leading 
						to the action and any payment schedule details, including current status (if applicable):</td>
						<td>
							<div class="fakeBox3">
								<xsl:value-of select="drp:summaryOfEvents"/>
							</div>
						</td>
					</tr>				
				</table>
			</xsl:if>
		</xsl:for-each>
	</xsl:template>
	
</xsl:stylesheet>
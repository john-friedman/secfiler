<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:cf="http://www.sec.gov/edgar/crowdfunding"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:ns1="http://www.sec.gov/edgar/common"
	xmlns:ns2="http://www.sec.gov/edgar/statecodes" 
	xmlns:ns3="http://www.sec.gov/edgar/common_drp">

	<xsl:template name="scheduleB">
		<xsl:if test="not($submissionType = 'CFPORTAL')">
			<h1>FORM FUNDING PORTAL SCHEDULE B</h1>
			<h4 class="title1">Amendments to Schedule A</h4>
			<div class="informationNoBorder">
				<ul style="list-style-type:none;">
					<li>
						<b>1. Use Schedule B only to amend information requested on Schedule A.</b>
						Refer to Schedule A for specific instructions for completing this Schedule B.  
						Complete each column. File with a completed Execution Page.
					</li>
					<br/>
					<li>
						<b>2. In the Type of Amendment column, </b> indicate "A" (addition), 
						"D" (deletion), or "C" (change in information about the same person).
					</li>		
					<br/>
					<li>
						<b>3. Ownership codes are:</b>
						<br/>
						<blockquote>
							<ul style="list-style-type: circle">
								<li>NA &ndash; less than 5%</li>
								<li>A &ndash; 5% but less than 10%</li>
								<li>B &ndash; 10% but less than 25%</li>
								<li>C &ndash; 25% but less than 50%</li>
								<li>D &ndash; 50% but less than 75%</li>
								<li>E &ndash; 75% or more</li>
								<li>G &ndash; Other (general partner, trustee, or elected member)</li>
							</ul>
						</blockquote>
					</li>
					<br/>
					<li>
						<b>4. List below all changes to Schedule A </b>(Direct Owners and Executive Officers):
					</li>
					<br/>
				</ul>
			</div>
			<table role="presentation" id="scheduleB_instruction">
				<xsl:for-each select="cf:scheduleB/cf:amendEntityOrNaturalPerson">	
					<tr>
						<td class="label"><b>FULL LEGAL NAME <br/>(Natural Persons: Last Name, First Name, Middle Name)</b></td>
						<td>
							<div class="fakeBox3">
								<xsl:value-of select="cf:fullLegalName"/>
							</div>
						</td>
					</tr>
					<tr>
						<td class="label">
							<b>Domestic Entity/Foreign Entity (entity organized, incorporated, or domiciled in a foreign country)/Natural Person:</b>
						</td>
						<td>
							<xsl:choose>
								<xsl:when test="contains(cf:entityType, 'DE')">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;DE (Domestic Entity)&#160;&#160;
							<xsl:choose>
								<xsl:when test="contains(cf:entityType, 'FE')">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;FE (Foreign Entity)&#160;&#160;
							<xsl:choose>
								<xsl:when test="contains(cf:entityType, 'NP')">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;NP (Natural Person)							
						</td>
					</tr>
					<tr>
						<td class="label"><b>Type of Amendment</b></td>
						<td>
							<xsl:choose>
								<xsl:when test="cf:typeOfAmendment = 'C'">
									<div class="fakeBox">
										C (change in information about the same<em>person</em>)
									</div>						
								</xsl:when>
								<xsl:otherwise>
									<div class="fakeBox2">
										<xsl:if test="cf:typeOfAmendment = 'A'">
											A (addition)
										</xsl:if>
										<xsl:if test="cf:typeOfAmendment = 'D'">
											D (deletion)
										</xsl:if>
									</div>								
								</xsl:otherwise>
							</xsl:choose>
						</td>
					</tr>
					<tr>
						<td class="label"><b>Title or Status</b></td>
						<td>
							<div class="fakeBox3">
								<xsl:value-of select="cf:titleStatus"/>
							</div>
						</td>
					</tr>	
					<tr>
						<td class="label"><b>Date Title or Status Acquired (MM/YYYY)</b></td>
						<td>
							<div class="fakeBox2">
								<xsl:value-of select="cf:dateOfTitleStatusAcquired"/>
							</div>
						</td>
					</tr>			
					<tr>
						<td class="label"><b>Ownership Code</b></td>
						<td>
							<xsl:choose>
								<xsl:when test="cf:ownershipCode = 'G'">
									<div class="fakeBox">
										G - Other (general partner, trustee, or elected member)
									</div>									
								</xsl:when>
								<xsl:otherwise>
									<div class="fakeBox2">
										<xsl:if test="cf:ownershipCode = 'NA'">
											NA - less than 5%
										</xsl:if>
										<xsl:if test="cf:ownershipCode = 'A'">
											A - 5% but less than 10%
										</xsl:if>
										<xsl:if test="cf:ownershipCode = 'B'">
											B - 10% but less than 25%
										</xsl:if>
										<xsl:if test="cf:ownershipCode = 'C'">
											C - 25% but less than 50%
										</xsl:if>
										<xsl:if test="cf:ownershipCode = 'D'">
											D - 50% but less than 75%
										</xsl:if>
										<xsl:if test="cf:ownershipCode = 'E'">
											E - 75% or more
										</xsl:if>
									</div>							
								</xsl:otherwise>
							</xsl:choose>
						</td>
					</tr>
					<tr>
						<td class="label"><b>Control Person</b></td>
						<td>
							<xsl:choose>
								<xsl:when test="cf:controlPerson = 'Y'">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;Yes&#160;
							<xsl:choose>
								<xsl:when test="cf:controlPerson = 'N'">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;No					
						</td>
					</tr>
					
					<tr>
						<td class="label">PR</td>
						<td>
							<xsl:choose>
								<xsl:when test="cf:pr = 'PR'">
									<img src="Images/box-checked.jpg" alt="Checkbox checked" />
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
								</xsl:otherwise>
							</xsl:choose>&#160;PR
						</td>
					</tr>
					<tr>
						<td class="label">CRD No. (If applicable)</td>
						<td>
							<div class="fakeBox2">
								<xsl:value-of select="cf:crdNumber"/>
							</div>
						</td>
					</tr>			
					<tr>
						<td class="label">IRS Tax No.</td>
						<td>
							<div class="fakeBox2">
								<xsl:value-of select="cf:irsTaxNumber"/>
							</div>
						</td>
					</tr>				
					<tr>
						<td class="label">IRS Employer ID No.</td>
						<td>
							<div class="fakeBox2">
								<xsl:value-of select="cf:irsTaxEmployerIdNumber"/>
							</div>
						</td>
					</tr>
				</xsl:for-each>
			</table>
		</xsl:if>
	</xsl:template>
	
</xsl:stylesheet>
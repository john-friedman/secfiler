<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:cf="http://www.sec.gov/edgar/crowdfunding"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:ns1="http://www.sec.gov/edgar/common"
	xmlns:ns2="http://www.sec.gov/edgar/statecodes" 
	xmlns:ns3="http://www.sec.gov/edgar/common_drp">

	<xsl:template name="tab3">	
		<h1><xsl:value-of select="$submissionType"/>: Successions</h1>
		<table role="presentation">
			<tr>
				<td class="label">
					A. Is the <em>applicant</em> at the time of this filing succeeding to the business of a currently 
					registered <em>funding portal</em>?	Do not report previous successions already reported on Form
					Funding	Portal. If "yes," complete Section 3.B. below.
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:successions/cf:isSucceedingBusiness = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose> &#160;Yes&#160;
					<xsl:choose>
						<xsl:when test="cf:successions/cf:isSucceedingBusiness = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose> &#160;No
				</td>
			</tr>
			<xsl:if test="cf:successions/cf:isSucceedingBusiness = 'Y'">
				<tr>
					<td class="label">
						B. Complete the following information if succeeding to the business of a currently &ndash;
						registered <em>funding portal</em>. If the <em>applicant</em> acquired more than one <em>funding
						portal</em> in the succession being reported on this Form Funding Portal, a separate entry must be
						completed for each acquired firm.
					</td>
					<td></td>
				</tr>
				<xsl:for-each select="cf:successions/cf:acquiredHistoryDetails">
					<tr>
						<td class="label"><blockquote>Name of Acquired <em>Funding Portal:</em></blockquote></td>
						<td>
							<div class="fakeBox3">
								<xsl:value-of select="cf:acquiredFundingPortal"/>
							</div>
						</td>
					</tr>
					<tr>
						<td class="label"><blockquote>Acquired <em>Funding Portal'</em>s <em>SEC</em> File No:</blockquote></td>
						<td>
							<div class="fakeBox2">
								<xsl:value-of select="cf:acquiredPortalFileNumber"/>
							</div>
						</td>					
					</tr>
					<tr>
						<td class="label">
							C. Briefly describe details of the succession including any assets or 
							liabilities not assumed by the <em>successor.</em>
						</td>
						<td>
							<div class="fakeBox3">
								<xsl:value-of select="cf:acquiredDesc"/>
							</div>
						</td>						
					</tr>
				</xsl:for-each>
			</xsl:if>
		</table>
	
	</xsl:template>
	
</xsl:stylesheet>
<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:cf="http://www.sec.gov/edgar/crowdfunding"
	xmlns:drp="http://www.sec.gov/edgar/crowdfunding_drp"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:ns1="http://www.sec.gov/edgar/common"
	xmlns:ns2="http://www.sec.gov/edgar/statecodes" 
	xmlns:ns3="http://www.sec.gov/edgar/common_drp">

	<xsl:variable name="drp3_filedFor">
		<xsl:choose>
			<xsl:when test="cf:edgarSubmission/cf:formData/cf:civilJudicialDrpInfo/drp:civilJudicialDrp/drp:drpFiledFor = 'Applicant'">
				<xsl:value-of select="cf:edgarSubmission/cf:formData/cf:civilJudicialDrpInfo/drp:civilJudicialDrp/drp:drpFiledFor"/>
			</xsl:when>
			<xsl:when test="contains(cf:edgarSubmission/cf:formData/cf:civilJudicialDrpInfo/drp:civilJudicialDrp/drp:drpFiledFor , 'and one or more of')">
				<xsl:value-of select="cf:edgarSubmission/cf:formData/cf:civilJudicialDrpInfo/drp:civilJudicialDrp/drp:drpFiledFor"/>
			</xsl:when>
			<xsl:when test="not(contains(cf:edgarSubmission/cf:formData/cf:civilJudicialDrpInfo/drp:civilJudicialDrp/drp:drpFiledFor , 'Applicant'))">
				<xsl:value-of select="cf:edgarSubmission/cf:formData/cf:civilJudicialDrpInfo/drp:civilJudicialDrp/drp:drpFiledFor"/>
			</xsl:when>
		</xsl:choose>
	</xsl:variable>

	<xsl:template name="civilJudicial">	
		<xsl:if test="count(cf:civilJudicialDrpInfo/drp:civilJudicialDrp) &gt; 0">
			<h1>CIVIL JUDICIAL ACTION DISCLOSURE REPORTING PAGE (FP)</h1>
			<h4 class="title1">GENERAL INSTRUCTIONS</h4>
			<div class="information">
				<p>
					You must provide a valid response to each question on every section of this DRP before 
					any of your information can be saved. Invalid or incomplete responses will prevent you 
					from closing the DRP with your information saved. It is recommended that you consult 
					the Print Form of this DRP to make sure you have gathered all the required information 
					before beginning your entry of information online.			
				</p>		
			</div>
			
			<xsl:for-each select="cf:civilJudicialDrpInfo/drp:civilJudicialDrp">
				<xsl:call-template name="drp3_general"/>		
				<xsl:call-template name="drp3_part1"/>
				<xsl:if test="not(contains($drp3_filedFor , 'associated')) or contains($drp3_filedFor , 'Applicant and')">
					<xsl:for-each select="drp:applicant">
						<xsl:call-template name="drp3_applicant"/>
						<xsl:call-template name="drp3_part2"/>
					</xsl:for-each>
				</xsl:if>
				<xsl:if test="contains($drp3_filedFor , 'Applicant and') or not(contains($drp3_filedFor , 'Applicant'))">
					<xsl:for-each select="drp:associatedPerson">
						<xsl:call-template name="drp3_associatedPerson"/>
						<xsl:call-template name="drp3_part2"/>
					</xsl:for-each>
				</xsl:if>			
			</xsl:for-each>
		</xsl:if>
	</xsl:template>
	
	<xsl:template name="drp3_general">
		<table role="presentation">
			<tr>
				<td class="label">
					This Disclosure Reporting Page (DRP FP) is an INITIAL <em>OR</em> AMENDED
					response used to report details for affirmative responses to Items 5-H,  
					or 5-I of Form Funding Portal.
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="drp:initialOrAmended='INITIAL'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Initial&#160;
					<xsl:choose>
						<xsl:when test="drp:initialOrAmended='AMENDED'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Amended
				</td>
			</tr>
			<!-- VARIABLES BEGIN -->
				<xsl:variable name="drp3_response_1">
					<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
						<xsl:if test=". = '5-H(1)'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="drp3_response_2">
					<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
						<xsl:if test=". = '5-H(2)'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="drp3_response_3">
					<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
						<xsl:if test=". = '5-H(3)'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
				<xsl:variable name="drp3_response_4">
					<xsl:for-each select="drp:respondingTo/drp:responseQuestion">
						<xsl:if test=". = '5-I'">
							<xsl:value-of select="."/>
						</xsl:if>
					</xsl:for-each>
				</xsl:variable>
			<!-- VARIABLES END -->
			<tr>
				<td class="label">Check item(s) being responded to:</td>
				<td>
					<xsl:choose>
						<xsl:when test="$drp3_response_1 = '5-H(1)'">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;5-H(1)&#160;
					<xsl:choose>
						<xsl:when test="$drp3_response_2 = '5-H(2)'">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;5-H(2)&#160;
					<xsl:choose>
						<xsl:when test="$drp3_response_3 = '5-H(3)'">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;5-H(3)&#160;
					<xsl:choose>
						<xsl:when test="$drp3_response_4 = '5-I'">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>&#160;5-I										
				</td>
			</tr>
		</table>
		
		<div class="information">
			<p>Use a separate DRP for each event or <em>proceeding</em>. An event or <em>proceeding</em> may be reported
				for more than one <em>person</em> or entity using one DRP.  File with a completed Execution Page.
				<br/><br/>
				One event may result in more than one affirmative answer to Item 5-H or 5-I. Use only one DRP to report 
				details related to the same event. Unrelated civil judicial actions must be reported on separate DRPs.
			</p>
		</div>
	</xsl:template>
	<xsl:template name="drp3_part1">
		<h4 class="title2"><em>Part 1</em></h4>
		<table role="presentation">
			<tr>
				<td class="label">
					The <em>person</em>(s) or entity(ies) for whom this DRP is being filed is (are) the:
					<br/><br/><blockquote>Select only one:</blockquote>
				</td>
				<td>
					<br/><br/><br/>
					<xsl:choose>
						<xsl:when test="not(contains(drp:drpFiledFor, 'associated'))">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;<em>Applicant</em><br/>
					<xsl:choose>
						<xsl:when test="contains(drp:drpFiledFor, 'Applicant and')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;<em>Applicant and one or more of the applicant's associated person</em>(s)<br/>
					<xsl:choose>
						<xsl:when test="not(contains(drp:drpFiledFor, 'Applicant'))">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;One or more of <em>applicant's associated</em> person(s)
				</td>
			</tr>
		</table>		
	</xsl:template>
	<xsl:template name="drp3_applicant">
		<h4 class="title2"><u>Applicant</u></h4>
		<xsl:if test="contains($submissionType , '/A') or contains($submissionType , '-W')">
			<table role="presentation">
				<tr>
					<td class="label">If this DRP is being filed for the <em>applicant,</em> and it is an amendment that seeks to 
						remove a DRP concerning the <em>applicant</em> from the record, the reason the DRP should be removed is:</td>
					<td>
						<xsl:choose>
							<xsl:when test="contains(drp:drpRemovalReason, 'applying for')">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;The <em>applicant</em> is registered or applying for registration and the event 
						or <em>proceeding</em> was resolved in the <em>applicant’</em>s favor.<br/>
						<xsl:choose>
							<xsl:when test="contains(drp:drpRemovalReason, 'error')">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;The DRP was filed in error.				
					</td>
				</tr>
			</table>
		</xsl:if>		
	</xsl:template>
	<xsl:template name="drp3_associatedPerson">
		<h4 class="title2"><u>Associated Person</u></h4>
		<table role="presentation">
			<tr>
				<td class="label">If this DRP is being filed for an <em>associated person</em>:</td>
				<td></td>
			</tr>
			<tr>
				<td class="label">
					<blockquote>
						This <em>associated person</em> is:
					</blockquote>
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="drp:associatedPersonDetails/drp:personType = 'a firm'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;a firm&#160;&#160;
					<xsl:choose>
						<xsl:when test="drp:associatedPersonDetails/drp:personType = 'a natural person'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;a natural person
				</td>
			</tr>
			<tr>
				<td class="label"><blockquote>The <em>associated person</em> is:</blockquote></td>
				<td>
					<xsl:choose>
						<xsl:when test="not(contains(drp:associatedPersonDetails/drp:personRegistered , 'not'))">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;registered with the <em>SEC</em>&#160;&#160;
					<xsl:choose>
						<xsl:when test="contains(drp:associatedPersonDetails/drp:personRegistered , 'not')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;not registered with the <em>SEC</em>							
				</td>
			</tr>					
			<tr>
				<td class="label"><blockquote>Full name of the <em>associated person</em> 
				(including, for natural persons, last, first and middle names):</blockquote>
				</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:associatedPersonDetails/drp:fullName"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label"><blockquote>If the <em>associated person</em> has a CRD number, provide that number.</blockquote></td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="drp:associatedPersonDetails/drp:crdNumber"/>
					</div>
				</td>
			</tr>
			<xsl:if test="$submissionType = 'CFPORTAL/A' or $submissionType = 'CFPORTAL-W'">
				<tr>
					<td class="label">If this is an amendment that seeks to remove a DRP concerning the 
						<em>associated person, the reason DRP should be removed is:</em>
					</td>
					<td>
						<xsl:choose>
							<xsl:when test="contains(drp:drpRemovalReason, 'no longer')">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;The <em>associated person</em>(s) is (are) no longer associated with the applicant.<br/>
						<xsl:choose>
							<xsl:when test="contains(drp:drpRemovalReason, 'was resolved in the')">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;The event or <em>proceeding</em> was resolved in the associated person’s favor.<br/>
						<xsl:choose>
							<xsl:when test="contains(drp:drpRemovalReason, 'error')">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;The DRP was filed in error.
					</td>
				</tr>
				<xsl:if test="contains(drp:drpRemovalReason, 'error')">
					<tr>
						<td class="label"><blockquote>Explain the circumstances:</blockquote></td>
						<td>
							<div class="fakeBox3">
								<xsl:value-of select="drp:circumstancesExplanation"/>
							</div>
						</td>
					</tr>
				</xsl:if>
			</xsl:if>
		</table>
	</xsl:template>
	<xsl:template name="drp3_part2">
		<blockquote>
			<h4 class="title2"><em>Part 2</em></h4>
		</blockquote>	
		<table role="presentation">
			<tr>
				<td class="label">
					1. Court Action initiated by: (Name of regulator, <em>foreign financial regulatory
					authority, SRO,</em> commodities exchange, agency, firm, private plaintiff, etc.)
				</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:civilJudicialDrpDetails/drp:courtActionInitiatorName"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">
					2. Principal Relief Sought (check appropriate item):
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="contains(drp:civilJudicialDrpDetails/drp:principalReliefSought, 'Cease and Desist')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Cease and Desist (Private/Civil Complaint)<br/>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalReliefSought='Restraining Order'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Restraining Order <br/>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalReliefSought='Injunction'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Injunction<br/>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalReliefSought='Disgorgement'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Disgorgement<br/>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalReliefSought='Civil Penalty(ies)/Fine(s)'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Civil Penalty(ies)/Fine(s)<br/>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalReliefSought='Restitution'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Restitution<br/>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalReliefSought='Money Damages'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Money Damages<br/>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalReliefSought='Other'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Other
				</td>
			</tr>
			<xsl:if test="drp:civilJudicialDrpDetails/drp:principalReliefSought='Other'">
				<tr>
					<td class="label">
						<blockquote>
							If Other, please specify
						</blockquote>
					</td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="drp:civilJudicialDrpDetails/drp:otherPrincipleReliefSought"/>
						</div>
					</td>
				</tr>
			</xsl:if>
			<tr>
				<td class="label">
					<blockquote>
						Other Relief Sought:
					</blockquote>
				</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:civilJudicialDrpDetails/drp:otherReliefSought"/>
					</div>
				</td>
			</tr>						
			
			
			<tr>
				<td class="label">3. Filing Date of Court Action (MM/DD/YYYY): </td>
				<td>
					<div class="fakeBox2">	
						<xsl:value-of select="drp:civilJudicialDrpDetails/drp:filingDateOfCourtActionExactOrExplain/ns1:date"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label"><blockquote>Specify if Filing Date of Court Action  is Exact or needs an Explanation</blockquote></td>
				<td>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:filingDateOfCourtActionExactOrExplain/ns1:exactOrExplanation = 'Exact'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Exact&#160;&#160;
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:filingDateOfCourtActionExactOrExplain/ns1:exactOrExplanation = 'Explanation'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Explanation
				</td>
			</tr>
			<xsl:if test="drp:civilJudicialDrpDetails/drp:filingDateOfCourtActionExactOrExplain/ns1:exactOrExplanation = 'Explanation'">
				<tr>
					<td class="label">
						<blockquote>
							<blockquote>
								If not exact, provide explanation:
							</blockquote>
						</blockquote>
					</td>
					<td>
						<div class="fakeBox3"> 
							<xsl:value-of select="drp:civilJudicialDrpDetails/drp:filingDateOfCourtActionExactOrExplain/ns1:explanationInfo"/>
						</div>
					</td>
				</tr>
			</xsl:if>
			<tr>
				<td class="label">4. Principal Product Type (check appropriate item):</td>
				<td>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalProductType = 'Annuity(ies) - Fixed'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Annuity(ies) - Fixed<br/>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalProductType = 'Annuity(ies) - Variable'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Annuity(ies) - Variable<br/>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalProductType = 'Money Market Fund(s)'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Money Market Fund(s)<br/>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalProductType = 'Mutual Fund(s)'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Mutual Fund(s)<br/>
					<xsl:choose>
						<xsl:when test="contains(drp:civilJudicialDrpDetails/drp:principalProductType, 'Equity Listed (Common')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Equity Listed (Common &amp; Preferred Stock)<br/>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalProductType = 'Debt - Asset Backed'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Debt - Asset Backed<br/>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalProductType = 'Debt - Corporate'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Debt - Corporate<br/>	
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalProductType = 'Debt - Government'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Debt - Government<br/>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalProductType = 'Debt - Municipal'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Debt - Municipal<br/>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalProductType = 'Derivative(s)'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Derivative(s)<br/>
					<xsl:choose>
						<xsl:when test="contains(drp:civilJudicialDrpDetails/drp:principalProductType, 'Direct Investment(s) - DPP')">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Direct Investment(s) - DPP &amp; LP Interest(s)<br/>	
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalProductType = 'CD(s)'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;CD(s)<br/>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalProductType = 'Commodity Option(s)'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Commodity Option(s)<br/>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalProductType = 'Futures - Commodity'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Futures - Commodity<br/>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalProductType = 'Futures - Financial'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Futures - Financial<br/>	
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalProductType = 'Index Option(s)'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Index Option(s)<br/>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalProductType = 'Insurance'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Insurance<br/>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalProductType = 'Investment Contract(s)'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Investment Contract(s)<br/>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalProductType = 'Equity - OTC'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Equity - OTC<br/>	
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalProductType = 'No Product'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;No Product<br/>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalProductType = 'Options'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Options<br/>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalProductType = 'Penny Stock(s)'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Penny Stock(s)<br/>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalProductType = 'Unit Investment Trust(s)'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Unit Investment Trust(s)<br/>
					<xsl:choose>
						<xsl:when test="drp:civilJudicialDrpDetails/drp:principalProductType = 'Other'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Other
				</td>
			</tr>
			
			<xsl:if test="drp:civilJudicialDrpDetails/drp:principalProductType = 'Other'">
				<tr>
					<td class="label"><blockquote>If Other, please specify</blockquote></td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="drp:civilJudicialDrpDetails/drp:otherPrincipalProductType"/>
						</div>
					</td>
				</tr>
			</xsl:if>
			<tr>
				<td class="label"><blockquote>Other Product Types:</blockquote></td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="drp:civilJudicialDrpDetails/drp:otherProductType"/>
					</div>
				</td>
			</tr>					
				<tr>
					<td class="label">
						5. Formal Action was brought in (include the name of the Federal, State, 
						or Foreign Court; Location of Court - City or County and State or Country; and Docket/Case Number).
					</td>
					<td>
						<xsl:choose>
							<xsl:when test="drp:civilJudicialDrpDetails/drp:civilActionCourtType = 'Federal Court'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;Federal Court<br/>
						<xsl:choose>
							<xsl:when test="drp:civilJudicialDrpDetails/drp:civilActionCourtType = 'State Court'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;State Court<br/>
						<xsl:choose>
							<xsl:when test="drp:civilJudicialDrpDetails/drp:civilActionCourtType = 'Foreign Court'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;Foreign Court
					</td>
				</tr>
				<tr>
					<td class="label">
						<blockquote>
						A. Name of Court:
						</blockquote>
					</td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="drp:civilJudicialDrpDetails/drp:civilActionCourtName" />
						</div>
					</td>
				</tr>
				<tr>
					<td class="label"><blockquote>B. Location of the Court:</blockquote></td>
					<td></td>
				</tr>	
				<tr>
					<td class="label"><blockquote><blockquote>City or County:</blockquote></blockquote></td>
					<td>
						<div class="fakeBox">
							<xsl:value-of select="drp:civilJudicialDrpDetails/drp:cityOrCounty" />
						</div>
					</td>
				</tr>	
				<tr>
					<td class="label"><blockquote><blockquote>State or Country:</blockquote></blockquote></td>
					<td>
						<div class="fakeBox">
							<xsl:call-template name="stateDescription">
								<xsl:with-param name="stateCode"
								select="drp:civilJudicialDrpDetails/drp:stateOrCountry" />
							</xsl:call-template>
						</div>								
					</td>
				</tr>
				<tr>
					<td class="label"><blockquote>C. Docket/Case Number:</blockquote></td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="drp:civilJudicialDrpDetails/drp:docketOrCaseNumber" />
						</div>
					</td>
				</tr>
				<xsl:if test="count(drp:associatedPersonDetails) &gt; 0">
					<tr>
						<td class="label">
							6. Associated person's Employing Firm when activity occurred that led to the civil judicial action (if applicable):
						</td>
						<td>
							<div class="fakeBox3">
								<xsl:value-of select="drp:civilJudicialDrpDetails/drp:associatePersonEmployingFirm"/>
							</div>
						</td>
					</tr>	
				</xsl:if>					
				<tr>
					<td class="label">
						7. Describe the allegations related to this civil action.  (The response must fit within the space provided.)
					</td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="drp:civilJudicialDrpDetails/drp:describeCivilActionAllegations"/>
						</div>
					</td>
				</tr>
				<tr>
					<td class="label">8. Current status?</td>
					<td>
						<xsl:choose>
							<xsl:when test="drp:civilJudicialDrpDetails/drp:eventCurrentStatus = 'Pending'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;Pending&#160;&#160;
						<xsl:choose>
							<xsl:when test="drp:civilJudicialDrpDetails/drp:eventCurrentStatus = 'On Appeal'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;On Appeal&#160;&#160;
						<xsl:choose>
							<xsl:when test="drp:civilJudicialDrpDetails/drp:eventCurrentStatus = 'Final'">
								<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
							</xsl:otherwise>
						</xsl:choose>&#160;Final
					</td>
				</tr>
				<xsl:if test="drp:civilJudicialDrpDetails/drp:eventCurrentStatus = 'On Appeal'">
					<tr>
						<td class="label">
							9. If on appeal, court to which the action was appealed (provide name of the court) and Date Appeal Filed (MM/DD/YYYY):
						</td>
						<td>
							<div class="fakeBox3">
								<xsl:value-of select="drp:civilJudicialDrpDetails/drp:courtNameAndDateAppeal"/>
							</div>
						</td>
					</tr>
				</xsl:if>
				<xsl:if test="drp:civilJudicialDrpDetails/drp:eventCurrentStatus = 'Pending'">
					<tr>
						<td class="label">
							10.  If pending, date notice/process was served  (MM/DD/YYYY): 
						</td>
						<td>
							<div class="fakeBox2">
								<xsl:value-of select="drp:civilJudicialDrpDetails/drp:processingDateCourtActionExactOrExplain/ns1:date"/>
							</div>
						</td>
					</tr>
					<tr>
						<td class="label"><blockquote>Specify if notice/process date of Court Action is Exact or needs an Explanation</blockquote>
						</td>
						<td>
							<xsl:choose>
								<xsl:when test="drp:civilJudicialDrpDetails/drp:processingDateCourtActionExactOrExplain/ns1:exactOrExplanation = 'Exact'">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;Exact&#160;&#160;
							<xsl:choose>
								<xsl:when test="drp:civilJudicialDrpDetails/drp:processingDateCourtActionExactOrExplain/ns1:exactOrExplanation = 'Explanation'">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;Explanation							
						</td>
					</tr>
					<xsl:if test="drp:civilJudicialDrpDetails/drp:processingDateCourtActionExactOrExplain/ns1:exactOrExplanation = 'Explanation'">
						<tr>
							<td class="label">
								<blockquote>
									<blockquote>
										If not exact, provide explanation:
									</blockquote>
								</blockquote>
							</td>
							<td>
								<div class="fakeBox3">
									<xsl:value-of select="drp:civilJudicialDrpDetails/drp:processingDateCourtActionExactOrExplain/ns1:explanationInfo"/>
								</div>
							</td>
						</tr>
					</xsl:if>									
				</xsl:if>
				<tr>
					<td colspan="2" style="padding:0">
						<div class="information">
							<p>
								If Final or On Appeal, complete all items below.  For Pending Actions, complete Item 14 only.
							</p>
						</div>
					</td>
				</tr>						
				<xsl:if test="not(drp:civilJudicialDrpDetails/drp:eventCurrentStatus = 'Pending')">
					<tr>
						<td class="label">
							11. How was matter resolved (check appropriate item):
						</td>
						<td>
							<xsl:choose>
								<xsl:when test="drp:civilJudicialDrpDetails/drp:matterResolveType = 'Consent'">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;Consent<br/>
							<xsl:choose>
								<xsl:when test="drp:civilJudicialDrpDetails/drp:matterResolveType = 'Judgement Rendered'">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;Judgement Rendered<br/>	
							<xsl:choose>
								<xsl:when test="drp:civilJudicialDrpDetails/drp:matterResolveType = 'Settled'">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;Settled<br/>
							<xsl:choose>
								<xsl:when test="drp:civilJudicialDrpDetails/drp:matterResolveType = 'Dismissed'">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
							</xsl:when>
							<xsl:otherwise>
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;Dismissed<br/>
							<xsl:choose>
								<xsl:when test="drp:civilJudicialDrpDetails/drp:matterResolveType = 'Opinion'">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;Opinion<br/>
							<xsl:choose>
								<xsl:when test="drp:civilJudicialDrpDetails/drp:matterResolveType = 'Withdrawn'">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;Withdrawn<br/>
							<xsl:choose>
								<xsl:when test="drp:civilJudicialDrpDetails/drp:matterResolveType = 'Other'">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;Other							
						</td>
					</tr>
					<xsl:if test="drp:civilJudicialDrpDetails/drp:matterResolveType = 'Other'">
						<tr>
							<td class="label"><blockquote>If you selected "Other", please specify:</blockquote></td>
							<td>
								<div class="fakeBox3">
									<xsl:value-of select="drp:civilJudicialDrpDetails/drp:otherMatterResolveType"/>
								</div>
							</td>
						</tr>
					</xsl:if>
					<tr>
						<td class="label">12. Resolution Date (MM/DD/YYYY): </td>
						<td>
							<div class="fakeBox2">
								<xsl:value-of select="drp:civilJudicialDrpDetails/drp:resolutionDateExactOrExplain/ns1:date"/>
							</div>
						</td>
					</tr>
					<tr>
						<td class="label"><blockquote>Specify if Resolution Date is Exact or needs an Explanation</blockquote></td>
						<td>
							<xsl:choose>
								<xsl:when test="drp:civilJudicialDrpDetails/drp:resolutionDateExactOrExplain/ns1:exactOrExplanation = 'Exact'">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;Exact&#160;&#160;
							<xsl:choose>
								<xsl:when test="drp:civilJudicialDrpDetails/drp:resolutionDateExactOrExplain/ns1:exactOrExplanation = 'Explanation'">
									<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
								</xsl:otherwise>
							</xsl:choose>&#160;Explanation
						</td>
					</tr>
					<xsl:if test="drp:civilJudicialDrpDetails/drp:resolutionDateExactOrExplain/ns1:exactOrExplanation = 'Explanation'">
						<tr>
							<td class="label">
								<blockquote>
									<blockquote>
										If not exact, provide explanation:
									</blockquote>
								</blockquote>
							</td>
							<td>
								<div class="fakeBox3">
									<xsl:value-of select="drp:civilJudicialDrpDetails/drp:resolutionDateExactOrExplain/ns1:explanationInfo"/>
								</div>
							</td>
						</tr>
					</xsl:if>
					<tr>
						<td class="label">13. Resolution Detail:</td>
						<td></td>
					</tr>
					<xsl:variable name="element13_moneytary">
						<xsl:for-each select="drp:civilJudicialDrpDetails/drp:sanctionReliefType/drp:sanctionOrdered">
							<xsl:if test="contains(. , 'Monetary')"><xsl:value-of select="."/></xsl:if>
						</xsl:for-each>
					</xsl:variable>
					<xsl:variable name="element13_moneytary_bar">
						<xsl:for-each select="drp:civilJudicialDrpDetails/drp:sanctionReliefType/drp:sanctionOrdered">
							<xsl:if test="contains(. , 'Bar')"><xsl:value-of select="."/></xsl:if>
						</xsl:for-each>
					</xsl:variable>
					<xsl:variable name="element13_moneytary_revocation">
						<xsl:for-each select="drp:civilJudicialDrpDetails/drp:sanctionReliefType/drp:sanctionOrdered">
							<xsl:if test="contains(. , 'Revocation')"><xsl:value-of select="."/></xsl:if>
						</xsl:for-each>
					</xsl:variable>	
					<xsl:variable name="element13_moneytary_disgorgement">
						<xsl:for-each select="drp:civilJudicialDrpDetails/drp:sanctionReliefType/drp:sanctionOrdered">
							<xsl:if test="contains(. , 'Disgorgement')"><xsl:value-of select="."/></xsl:if>
						</xsl:for-each>
					</xsl:variable>	
					<xsl:variable name="element13_moneytary_cease">
						<xsl:for-each select="drp:civilJudicialDrpDetails/drp:sanctionReliefType/drp:sanctionOrdered">
							<xsl:if test="contains(. , 'Cease')"><xsl:value-of select="."/></xsl:if>
						</xsl:for-each>
					</xsl:variable>	
					<xsl:variable name="element13_moneytary_censure">
						<xsl:for-each select="drp:civilJudicialDrpDetails/drp:sanctionReliefType/drp:sanctionOrdered">
							<xsl:if test="contains(. , 'Censure')"><xsl:value-of select="."/></xsl:if>
						</xsl:for-each>
					</xsl:variable>	
					<xsl:variable name="element13_moneytary_suspension">
						<xsl:for-each select="drp:civilJudicialDrpDetails/drp:sanctionReliefType/drp:sanctionOrdered">
							<xsl:if test="contains(. , 'Suspension')"><xsl:value-of select="."/></xsl:if>
						</xsl:for-each>
					</xsl:variable>																	
					<tr>
						<td class="label">
							<blockquote>A. Were any of the following Sanctions Ordered 
							or Relief Granted (check appropriate item)?</blockquote>
						</td>
						<td>
							<xsl:choose>
								<xsl:when test="contains($element13_moneytary , 'Fine')">
									<img src="Images/box-checked.jpg" alt="Checkbox checked" />
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
								</xsl:otherwise>
							</xsl:choose>&#160;Monetary/Fine<br/>
							<xsl:choose>
								<xsl:when test="$element13_moneytary_bar = 'Bar'">
									<img src="Images/box-checked.jpg" alt="Checkbox checked" />
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
								</xsl:otherwise>
							</xsl:choose>&#160;Bar<br/>
							<xsl:choose>
								<xsl:when test="contains($element13_moneytary_revocation , 'Revocation')">
									<img src="Images/box-checked.jpg" alt="Checkbox checked" />
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
								</xsl:otherwise>
							</xsl:choose>&#160;Revocation/Expulsion/Denial<br/>
							<xsl:choose>
								<xsl:when test="$element13_moneytary_disgorgement = 'Disgorgement'">
									<img src="Images/box-checked.jpg" alt="Checkbox checked" />
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
								</xsl:otherwise>
							</xsl:choose>&#160;Disgorgement<br/>
							<xsl:choose>
								<xsl:when test="contains($element13_moneytary_cease , 'Cease')">
									<img src="Images/box-checked.jpg" alt="Checkbox checked" />
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
								</xsl:otherwise>
							</xsl:choose>&#160;Cease and Desist/ Injunction<br/>
							<xsl:choose>
								<xsl:when test="$element13_moneytary_censure = 'Censure'">
									<img src="Images/box-checked.jpg" alt="Checkbox checked" />
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
								</xsl:otherwise>
							</xsl:choose>&#160;Censure<br/>						
							<xsl:choose>
								<xsl:when test="$element13_moneytary_suspension = 'Suspension'">
									<img src="Images/box-checked.jpg" alt="Checkbox checked" />
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
								</xsl:otherwise>
							</xsl:choose>&#160;Suspension									
						</td>
					</tr>
					
					<xsl:if test="contains($element13_moneytary , 'Fine')">
						<tr>
							<td class="label">
								<blockquote>
									<blockquote>
										Amount:
									</blockquote>
								</blockquote>
							</td>
							<td>
								<div class="fakeBox2">
									<xsl:if test="count(drp:civilJudicialDrpDetails/drp:grantOrFineAmount) &gt; 0">
										<xsl:value-of select='format-number(drp:civilJudicialDrpDetails/drp:grantOrFineAmount , "$###,###,###,##0.00")' />
									</xsl:if>
								</div>
							</td>
						</tr>
					</xsl:if>	
					<tr>
						<td class="label"><blockquote>B. Other Sanctions Ordered:</blockquote></td>
						<td>
							<div class="fakeBox3">
								<xsl:value-of select="drp:civilJudicialDrpDetails/drp:otherSanctionsOrdered"/>
							</div>
						</td>
					</tr>		
					<tr>
						<td class="label"><blockquote>C. Sanction detail:  If suspended, enjoined or barred, 	
							provide duration including start date and capacities affected (General Securities Principal, Financial Operations Principal, etc.). If requalification by exam/retraining was a condition of the sanction, provide length of time given to requalify/retrain, type of exam required and whether condition has been satisfied. If disposition resulted in a fine, penalty, restitution, disgorgement or monetary compensation, provide total amount, portion levied against the applicant or an associated person, date paid and if any portion of penalty was waived:</blockquote>
						</td>
						<td>
							<div class="fakeBox3">
								<xsl:value-of select="drp:civilJudicialDrpDetails/drp:sanctionDetail"/>
							</div>
						</td>
					</tr>							
				</xsl:if>
				<tr>
					<td class="label">
						14. Provide a brief summary of circumstances related to the action(s), allegation(s), disposition(s) and/or finding(s) disclosed above:
					</td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="drp:civilJudicialDrpDetails/drp:summaryOfCircumstances"/>
						</div>
					</td>
				</tr>
		</table>
	</xsl:template>
</xsl:stylesheet>
<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:cf="http://www.sec.gov/edgar/crowdfunding"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:ns1="http://www.sec.gov/edgar/common"
	xmlns:ns2="http://www.sec.gov/edgar/statecodes" 
	xmlns:ns3="http://www.sec.gov/edgar/common_drp">

	<xsl:template name="execution">
		<h1>EXECUTION</h1>
		<div class="informationNoBorder">
			<p>
				The <em>funding portal</em> consents that service of any civil action brought by 
				or notice of any proceeding before the Securities and Exchange Commission or any 
				<em>self-regulatory organization</em> in connection with the <em>funding portal'</em>s
				investment-related business may be given by registered or certified mail to the 
				<em>funding portal'</em>s contact person at the main address, or mailing address, 
				if different, given in Items 1.E, 1.F. and 1.H.. If the applicant is a <em>nonresident 
				funding portal,</em> it must complete Schedule C to designate a U.S. agent for service of process.  
				<br/><br/>
				The undersigned represents and warrants that he/she has executed this form on behalf of, 
				and is duly authorized to bind, the <em>funding portal</em>. The undersigned and the 
				<em>funding portal</em> represent that the information and statements contained herein 
				and other information filed herewith, all of which are made a part hereof, are current, 
				true and complete. The undersigned and the <em>funding portal</em> further represent that, 
				if this is an amendment, to the extent that any information previously submitted is not amended, 
				such information is currently accurate and complete.
			</p>	
		</div>	
		<table role="presentation">
			<tr>
				<td class="label">Date:</td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="cf:execution/cf:executionDate"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">Full Legal Name of <em>Funding Portal</em>:</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="cf:execution/cf:fullLegalNameFundingPortal"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">By: (Signature)</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="cf:execution/cf:personSignature"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">Title:</td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="cf:execution/cf:personTitle"/>
					</div>
				</td>
			</tr>			
		</table>		
	
	</xsl:template>
	
</xsl:stylesheet>
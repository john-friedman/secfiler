<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:cf="http://www.sec.gov/edgar/crowdfunding"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:ns1="http://www.sec.gov/edgar/common"
	xmlns:ns2="http://www.sec.gov/edgar/statecodes" 
	xmlns:ns3="http://www.sec.gov/edgar/common_drp">

	<xsl:template name="tab6">
		<h1><xsl:value-of select="$submissionType"/>: Non-Securities Related Business</h1>
		<table role="presentation">
			<tr>
				<td class="label">
					Does the <em>applicant</em> engage in any non-securities related business?
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="cf:nonSecuritiesRelatedBusiness/cf:isEngagedInNonSecurities = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;Yes&#160;
					<xsl:choose>
						<xsl:when test="cf:nonSecuritiesRelatedBusiness/cf:isEngagedInNonSecurities = 'N'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked"/>
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
						</xsl:otherwise>
					</xsl:choose>&#160;No&#160;					
				</td>
			</tr>
			<xsl:if test="cf:nonSecuritiesRelatedBusiness/cf:isEngagedInNonSecurities = 'Y'">
				<tr>
					<td class="label">
						<blockquote>
							If "yes", briefly describe the non-securities business.
						</blockquote>
					</td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="cf:nonSecuritiesRelatedBusiness/cf:nonSecuritiesBusinessDesc"/>
						</div>
					</td>
				</tr>	
			</xsl:if>
		</table>
	
	</xsl:template>
	
</xsl:stylesheet>
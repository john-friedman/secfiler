<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE xsl:stylesheet [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:cf="http://www.sec.gov/edgar/crowdfunding" 
	xmlns:ns1="http://www.sec.gov/edgar/common">

	<xsl:import href="util.xsl" />

	<xsl:output 
		method="html" 
		indent="no" 
		encoding="iso-8859-1"
		doctype-public="-//W3C//DTD XHTML 1.0 Strict//EN" 
		doctype-system="http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd" />

	<xsl:template match="/">
		<html>
			<head>
				<link rel="stylesheet" type="text/css" href="css/SDR_print.css" />	
				<style type="text/css">
					.fakeBox {
						border-top: 2px solid #999;
					}
					ul{
						padding-left:10px;
						padding-right:10px;
					}
					.warning {
						font-weight:bold;   
						padding:10px; 
						margin:5px 0px;
						font-size:0.9em;
					}
					/* informations */
					.information, .informationNoBorder {
						font-weight:lighter   
						padding:0px; 
						font-size:0.9em;
					}
					img {
						vertical-align:text-top;
					}
					/* titles (order by font size)*/
					.title1, .title2, .title3, .titleNumber {
						font-family: Arial, Helvetica, sans-serif;
					    text-align: left;
					    line-height: 1.5;				
					    font-weight: bold;	
					}									
					.title1 { /* Largest title */
						margin: 10px 0px;
					    font-size: 1.3em;
					}
					.title2 { /* Second largest title */
						margin: 5px;
					    font-size: 1.1em;
					}	
					.title3 { /* Third largest title */
						margin: 10px 20px;
					}
					.titleNumber {
						margin: 10px 0px;
						line-height: 0.8;
					}
					h4{
						vertical-align:middle;
					}
					.fakeBox_duration {
						border-top: 2px solid #999;
						border-right: 1px solid #ccc;
						border-bottom: 1px solid #ccc;
						border-left: 2px solid #999;
						padding: 2px;
						min-width: 50px;
						width: 50px;
						height: 15px;
						word-wrap: break-word;
						font-size: 0.9em;
						color: blue;
					}
				</style>		
			</head>

			<body lang="en-US" text="#000000" bgcolor="#ffffff">
				<div style="display:none">
					<xsl:value-of select="cf:edgarSubmission/cf:schemaVersion"/>
				</div>
				<xsl:apply-templates/>
			</body>
		</html>
	</xsl:template>

	<!-- Header Template START -->
	<xsl:template name="header" match="cf:edgarSubmission/cf:headerData">
		<div class="contentwrapper">
			<table role="presentation" id="header">
				<tr>
					<td class="title" style="font-size:0.9em">Form Funding Portal Filer Information</td>
					<td rowspan="2" class="center">
						UNITED STATES<br/>
						SECURITIES AND EXCHANGE COMMISSION<br />
						Washington, D.C. 20549<br />
						FORM FUNDING PORTAL<br />
						UNDER THE SECURITIES EXCHANGE ACT OF 1934
					</td>
					<td class="title">OMB APPROVAL</td>
				</tr>	
				<tr>
					<td class="side" style="text-align: center;vertical-align:middle">
						<p>
							 FORM <xsl:value-of select="cf:submissionType" />
						</p>
					</td>
					<td width="25%" class="side">
						<p>OMB Number:&#160;&#160;3235-0727</p>
						<hr></hr>
						<p>
							Estimated average burden hours per response:&#160;
							<xsl:choose>
								<xsl:when test="contains($submissionType , 'CFPORTAL')">
									2.75
								</xsl:when>
								<xsl:when test="contains($submissionType , '/A')">
									0.33
								</xsl:when>
								<xsl:when test="contains($submissionType , '-W')">
									0.25
								</xsl:when>
							</xsl:choose>
							
						</p>
					</td>
				</tr>
			</table>
		</div>
	
		<div id="info">
			<div class="contentwrapper">
				<div class="content">
					<h1><xsl:value-of select="$submissionType"/>: Filer Information</h1>
					<table role="presentation" class="filerInformation">		
						<tr>
							<td class="label">Filer CIK</td>
							<td>
								<div class="fakeBox2">
									<xsl:value-of select="cf:filerInfo/cf:filer/cf:filerCredentials/cf:filerCik" />
								</div>
							</td>
						</tr>
						<tr>
							<td class="label">Filer CCC</td>
							<td>
								<div class="fakeBox2">				
									********
								</div>
							</td>
						</tr>				
						<tr>
							<td class="label">Is this a LIVE or TEST Filing?</td>
							<td>
								<xsl:choose>
									<xsl:when test="string(cf:filerInfo/cf:liveTestFlag) = 'LIVE'">
										<img src="Images/radio-checked.jpg"  alt="Radio button checked"/>
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
									</xsl:otherwise>
								</xsl:choose>&#160;LIVE
								<xsl:choose>
									<xsl:when test="string(cf:filerInfo/cf:liveTestFlag) = 'TEST'">
										<img src="Images/radio-checked.jpg"  alt="Radio button checked"/>
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/radio-unchecked.jpg" alt="Radio button not checked"/>
									</xsl:otherwise>
								</xsl:choose>&#160;TEST
							</td>
						</tr>
						
						<tr>
							<td class="label">
								Is this an electronic copy of an official filing submitted in paper format?
							</td>
							<td>
								<xsl:choose>
									<xsl:when test="string(cf:filerInfo/cf:flags/cf:confirmingCopyFlag) = 'true'">
										<img src="Images/box-checked.jpg" alt="Checkbox checked" />
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
									</xsl:otherwise>
								</xsl:choose>
							</td>
						</tr>
						<xsl:if test="cf:filerInfo/cf:flags/cf:confirmingCopyFlag = 'true'">
							<tr>
								<td class="label">File Number</td>
								<td>
									<div class="fakeBox2">
										<xsl:value-of select="cf:filerInfo/cf:filer/cf:fileNumber"/>
									</div>								
								</td>
							</tr>							
						</xsl:if>	
						<tr>
							<td class="label">Would you like a Return Copy?</td>
							<td>
								<xsl:choose>
									<xsl:when test="string(cf:filerInfo/cf:flags/cf:returnCopyFlag) = 'true'">
										<img src="Images/box-checked.jpg" alt="Checkbox checked" />
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
									</xsl:otherwise>
								</xsl:choose>
							</td>
						</tr>
						<tr>
							<td>
								<h4>Submission Contact Information</h4>
							</td>
						</tr>
						<tr>
							<td class="label">Name</td>
							<td>
								<div class="fakeBox3">
									<xsl:value-of select="cf:filerInfo/cf:contact/cf:contactName" />
								</div>
							</td>
						</tr>
						<tr>
							<td class="label">Phone Number</td>
							<td>
								<div class="fakeBox2">
									<xsl:value-of select="cf:filerInfo/cf:contact/cf:contactPhone" />
								</div>
							</td>
						</tr>
						<tr>
							<td class="label">E-Mail Address</td>
							<td>			
								<div class="fakeBox">
									<xsl:value-of select="cf:filerInfo/cf:contact/cf:contactEmail" />
								</div>
							</td>
						</tr>
						<tr>
							<td class="label">Notify via Filing Website only?</td>
							<td>
								<xsl:choose>
									<xsl:when test="string(cf:filerInfo/cf:flags/cf:overrideInternetFlag) = 'true'">
										<img src="Images/box-checked.jpg" alt="Checkbox checked" />
								</xsl:when>
								<xsl:otherwise>
									<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
									</xsl:otherwise>
								</xsl:choose>
							</td>
						</tr>
						<xsl:for-each select="cf:filerInfo/cf:notifications/cf:notificationEmail">
							<tr>
								<td class="label">Notification E-mail Address</td>
								<td>
									<div class="fakeBox">
										<xsl:value-of select="." />
									</div>
								</td>
							</tr>
						</xsl:for-each>
					</table>
				</div>
			</div>
		</div>
	</xsl:template>
	
	<xsl:variable name="submissionType"  select="cf:edgarSubmission/cf:headerData/cf:submissionType" />	
	
	<xsl:template name="formData" match="cf:edgarSubmission/cf:formData">
		<xsl:call-template name="tab1"/>
		<xsl:call-template name="tab2"/>
		<xsl:call-template name="tab3"/>
		<xsl:call-template name="tab4"/>						
		<xsl:call-template name="tab5"/>
		<xsl:call-template name="tab6"/>
		<xsl:call-template name="tab7"/>
		<xsl:call-template name="execution"/>		
		
		<xsl:call-template name="scheduleA"/>
		<xsl:call-template name="scheduleB"/>
		<xsl:call-template name="scheduleC"/>
		<xsl:call-template name="scheduleD"/>
		
		<xsl:call-template name="criminalAction"/>
		<xsl:call-template name="regulatoryAction"/>
		<xsl:call-template name="civilJudicial"/>
		<xsl:call-template name="bankruptcy"/>
		<xsl:call-template name="bond"/>
		<xsl:call-template name="judgementLien"/>				
	</xsl:template>
	
	<xsl:template name="documentsData" match="cf:edgarSubmission/cf:documents">
		<div style="display:none;">	
			<xsl:call-template name="InvisibleDocumentsInfo"/>
		</div>
	</xsl:template>
	
	<xsl:include href="CFPORTAL_item1.xsl"/>
	<xsl:include href="CFPORTAL_item2.xsl"/>
	<xsl:include href="CFPORTAL_item3.xsl" />
	<xsl:include href="CFPORTAL_item4.xsl" />
	<xsl:include href="CFPORTAL_item5.xsl" />
	<xsl:include href="CFPORTAL_item6.xsl" />
	<xsl:include href="CFPORTAL_item7.xsl" />
	<xsl:include href="CFPORTAL_execution.xsl" />
	<xsl:include href="CFPORTAL_scheduleA.xsl" />
	<xsl:include href="CFPORTAL_scheduleB.xsl" />
	<xsl:include href="CFPORTAL_scheduleC.xsl" />
	<xsl:include href="CFPORTAL_scheduleD.xsl" />	
	<xsl:include href="CFPORTAL_DRP1_criminalAction.xsl" />	
	<xsl:include href="CFPORTAL_DRP2_regulatoryAction.xsl" />	
	<xsl:include href="CFPORTAL_DRP3_civilJudicial.xsl" />
	<xsl:include href="CFPORTAL_DRP4_bankruptcy.xsl" />
	<xsl:include href="CFPORTAL_DRP5_bond.xsl" />
	<xsl:include href="CFPORTAL_DRP6_judgementLien.xsl" />
	
	<xsl:include href="CFPORTAL_documents.xsl" />
	<xsl:include href="SDR_State_Codes.xsl" />
	
</xsl:stylesheet>
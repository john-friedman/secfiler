<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0" 
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:p="http://www.sec.gov/edgar/seventeenafiler" 
	xmlns:ns1="http://www.sec.gov/edgar/common">

	<!-- Documents templates -->
    
	<xsl:template name="Documents">		
		<h3>
			<em>Documents</em>
		</h3>
		<xsl:call-template name="InvisibleDocumentsInfo"/>
	</xsl:template>

	<xsl:template name="InvisibleDocumentsInfo">
		<xsl:for-each select="ns1:document">
			<table role="presentation">
				<tr>
					<td class="label">FIle Name:
					</td>
					<td>
						<div class="fakeBox">
							<xsl:value-of select="ns1:conformedName" />
						</div>
					</td>
				</tr>
				<tr>
					<td class="label">Type:
					</td>
					<td>
						<div class="fakeBox">
							<xsl:value-of select="ns1:conformedDocumentType" />
						</div>
					</td>
				</tr>
				<tr>
					<td class="label">Description:
					</td>
					<td>
						<div class="fakeBox">
							<xsl:value-of select="ns1:description"/>
						</div>
					</td>
				</tr>					
				<tr>
					<td class="label">Contents:
					</td>
					<td>
						<div class="fakeBox">
							<xsl:value-of select="ns1:contents" />
						</div>
					</td>
				</tr>		
			</table>
		</xsl:for-each>
	</xsl:template>
</xsl:stylesheet>
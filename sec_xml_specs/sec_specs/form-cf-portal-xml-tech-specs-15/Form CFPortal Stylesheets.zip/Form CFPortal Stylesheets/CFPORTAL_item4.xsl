<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:cf="http://www.sec.gov/edgar/crowdfunding"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:ns1="http://www.sec.gov/edgar/common"
	xmlns:ns2="http://www.sec.gov/edgar/statecodes" 
	xmlns:ns3="http://www.sec.gov/edgar/common_drp">

	<xsl:template name="tab4">
		<h1><xsl:value-of select="$submissionType"/>: Control Relationships</h1>
		<table role="presentation">
			<tr>
				<td class="label">
					In this Item, identify every <em>person</em> that, directly or indirectly, <em>controls</em> the 
					<em>applicant, controls</em> management or policies of the <em>applicant,</em> or that the applicant
					directly or indirectly <em>controls.</em>
				</td>
				<td>
					<xsl:choose>
						<xsl:when test="count(cf:controlRelationships/cf:fullLegalNames) &gt; 0">
							<xsl:for-each select="cf:controlRelationships/cf:fullLegalNames">
								<div class="fakeBox3">
									<xsl:value-of select="cf:fullLegalName"/>
								</div>
								<br/><br/>
							</xsl:for-each>
						</xsl:when>
						<xsl:otherwise>
							<div class="fakeBox3"></div>
						</xsl:otherwise>
					</xsl:choose>
				</td>
			</tr>
		</table>
		<div class="information">			
			<p>
				If this is an initial application, the <em>applicant</em> also must complete Schedule A. 
				Schedule A asks for information about direct owners and executive officers.
				If this is an amendment updating information reported on the Schedule A filed with the
				<em>applicant'</em>s initial application, the <em>applicant</em> must complete Schedule B.
			</p>
		</div>
	</xsl:template>
</xsl:stylesheet>
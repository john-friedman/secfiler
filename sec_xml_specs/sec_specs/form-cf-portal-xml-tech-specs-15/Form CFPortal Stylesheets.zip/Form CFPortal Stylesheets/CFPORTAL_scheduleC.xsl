<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:cf="http://www.sec.gov/edgar/crowdfunding"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:ns1="http://www.sec.gov/edgar/common"
	xmlns:ns2="http://www.sec.gov/edgar/statecodes" 
	xmlns:ns3="http://www.sec.gov/edgar/common_drp">

	<xsl:template name="scheduleC">
		<h1>FORM FUNDING PORTAL SCHEDULE C</h1>
		<h4 class="title1"><em>Nonresident Funding Portals</em></h4>
		<div class="information">
			<p>
				<em>
					<b>Service of Process and Certification Regarding Prompt Access to Books and Records 
					and Ability to Submit to Inspections and Examinations</b>
				</em>
				<br/><br/>
				Each <em>nonresident funding portal applicant</em> shall use Schedule C of Form Funding Portal to: identify 
				its United States agent for service of process, and certify that it can, as a matter of law and will:
				(1) provide the Commission and any registered national securities association of which it becomes 
					a member with prompt access to its books and records, and
				(2) submit to onsite inspection and examination by the Commission and any registered national 
				securities association of which it becomes a member.
			</p>
		</div>
		<h4 class="title2">
			A. Agent for Service of Process:
		</h4>
		<table role="presentation">
			<tr>
				<td class="label">
						1. Name of United States <em>person applicant</em> designates and appoints as agent for service of process:
				</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="cf:scheduleC/cf:agentName"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">
						2. Address of United States <em>person applicant</em> designates and appoints as agent for service of process
				</td>
				<td></td>
			</tr>
			<tr>
				<td class="label">
						<blockquote>
							Address 1:
						</blockquote>
				</td>
				<td>
					<div class="fakeBox"><xsl:value-of select="cf:scheduleC/cf:agentAddress/ns1:street1"/></div>					
				</td>
			</tr>
			<tr>
				<td class="label">
						<blockquote>
							Address 2:
						</blockquote>
				</td>
				<td>
					<div class="fakeBox"><xsl:value-of select="cf:scheduleC/cf:agentAddress/ns1:street2"/></div>					
				</td>
			</tr>
			<tr>					
				<td class="label">
						<blockquote>
							City:
						</blockquote>
				</td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="cf:scheduleC/cf:agentAddress/ns1:city"/>
					</div>					
				</td>
			</tr>
			<tr>					
				<td class="label">
						<blockquote>
							State/Country:
						</blockquote>
				</td>
				<td>
					<div class="fakeBox">
						<xsl:call-template name="stateDescription">
							<xsl:with-param name="stateCode" 
								select="cf:scheduleC/cf:agentAddress/ns1:stateOrCountry" />
						</xsl:call-template>
					</div>					
				</td>
			</tr>
			<tr>					
				<td class="label">
						<blockquote>
							Mailing Zip/ Postal Code:
						</blockquote>
				</td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="cf:scheduleC/cf:agentAddress/ns1:zipCode"/>
					</div>					
				</td>
			</tr>
		</table>

		<div class="information">
			<ul style="list-style-type:none; padding:10px;">
				<li>
					The above identified agent for service of process may be
					served any process, pleadings, subpoenas, or other papers in:
					<br/><br/>
					(a) any investigation or administrative <em>proceeding</em> conducted by the 
					Commission that relates to the <em>applicant</em> or about which the 
					<em>applicant</em> may have information; and
					<br/><br/>
					(b) any civil or criminal suit or action or proceeding under the federal securities laws 
					brought against the <em>applicant</em> or to which the <em>applicant</em> has been joined as defendant 
					or respondent, in any appropriate court in any place subject to the jurisdiction of 
					any state or of the United States or of any of its territories or possessions or of 
					the District of Columbia. The <em>applicant</em> has stipulated and agreed that any such suit,
					action or administrative proceeding may be commenced by the service of process upon, 
					and that service of an administrative subpoena shall be effected by service upon, the
					above-named agent for service of process, and that service as aforesaid shall be taken 
					and held in all courts and administrative tribunals to be valid and binding as if 
					personal service thereof had been made.
				</li>
			</ul>	
		</div>
		
		<h4 class="title2">B. Certification regarding access to records and ability to submit to inspections and examinations:</h4>
		<div class="informationNoBorder">
			<ul style="list-style-type:none; padding:0px 10px 10px 10px;">
				<li>
					<em>Applicant</em> can, as a matter of law, and will:
					<br/><br/>
					1. provide the Commission and any registered national securities association of 
					which it becomes a member with prompt access to its books and records, and
					<br/>
					2. submit to onsite inspection and examination by the Commission and any 
					registered national securities association of which it becomes a member.
				</li>
				<br/>
				<li>	
					<em>
						Applicant must attach as an exhibit to this Form Funding Portal, Exhibit C, 
						a copy of the opinion of counsel it is required to obtain in accordance with 
						Rule 400(f) of Regulation Crowdfunding, i.e., the opinion of counsel that the 
						nonresident funding portal can, as a matter of law, provide the Commission and 
						any registered national securities association of which the nonresident funding 
						portal becomes a member with prompt access to the books and records of such 
						nonresident funding portal, and that the nonresident funding portal can, as a 
						matter of law, submit to onsite inspection and examination by the Commission 
						and any registered national securities association of which the nonresident 
						funding portal becomes a member.
					</em>
				</li>
				<br/>
				<li>
					<h4><u>EXECUTION FOR NON-RESIDENT FUNDING PORTALS</u></h4>
				</li>
				<li style="list-style-type:none;">
					The undersigned represents and warrants that he/she has executed this form 
					on behalf of, and is duly authorized to bind, the <em>nonresident funding portal</em>. 
					The undersigned and the <em>nonresident funding portal</em> represent that the information 
					and statements contained herein and other information filed herewith, all of which 
					are made a part hereof, are current, true and complete.  The undersigned and the 
					<em>nonresident funding portal</em> further represent that, if this is an amendment, to 
					the extent that any information previously submitted is not amended, such information 
					is currently accurate and complete.
				</li>
				<br/>
				<li style="list-style-type:none;">
					The undersigned certifies that the <em>nonresident funding portal</em> can, as a matter 
					of law, and will provide the Commission and any registered national securities 
					association of which it becomes a member with prompt access to the books and 
					records of such <em>nonresident funding portal</em> and can, as a matter of law, and 
					will submit to onsite inspection and examination by the Commission and any 
					national securities association of which it becomes a member.  Finally, the 
					undersigned authorizes any person having custody or possession of these books 
					and records to make them available to federal regulatory representatives.
				</li>
			</ul>
		</div>
		<table role="presentation">
			<tr>
				<td class="label">Signature:</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="cf:scheduleC/cf:personSignature"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">Printed Name:</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="cf:scheduleC/cf:printedName"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">Title:</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="cf:scheduleC/cf:personTitle"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">Date:</td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="cf:scheduleC/cf:signatureDate"/>
					</div>
				</td>
			</tr>			
		</table>
	</xsl:template>
</xsl:stylesheet>
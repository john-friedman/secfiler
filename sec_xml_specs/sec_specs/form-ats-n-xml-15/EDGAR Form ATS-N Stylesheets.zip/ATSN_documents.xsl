<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>

<xsl:stylesheet 
    version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:m1="http://www.sec.gov/edgar/atsn"
	
	xmlns:com="http://www.sec.gov/edgar/common"
    xmlns:acom="http://www.sec.gov/edgar/atsncommon">
	
	 <xsl:template name="InvisibleDocumentsInfo">
	 
	   
		<xsl:call-template name="docs"/>
	 
	 
	 </xsl:template>
	
	
	<xsl:template name="docs">
	   
	   		<xsl:for-each select="acom:document">
			<table role="presentation">
				<tr>
					<td class="label">File Name:
					</td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="acom:conformedName" />
						</div>
					</td>
				</tr>
				<tr>
					<td class="label">Type:
					</td>
					<td>
						<div class="fakeBox">
							<xsl:value-of select="acom:conformedDocumentType" />
						</div>
					</td>
				</tr>
							
				<tr>
					<td class="label">Contents:
					</td>
					<td>
						<div class="fakeBox3">
							<xsl:value-of select="acom:contents" />
						</div>
					</td>
				</tr>		
			</table>
			<br/>
			<br/>
		</xsl:for-each>
	
	</xsl:template>
	

</xsl:stylesheet>
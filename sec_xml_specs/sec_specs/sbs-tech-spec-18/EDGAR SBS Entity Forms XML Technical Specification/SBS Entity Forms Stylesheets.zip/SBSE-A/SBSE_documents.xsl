<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0" 
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:p="http://www.sec.gov/edgar/sbse/sbsefiler"
    xmlns:p1="http://www.sec.gov/edgar/common">

	<!-- Documents templates -->
    
	<xsl:template name="sbse_documents">		
		<h3>
			<em>Documents</em>
		</h3>
		<xsl:call-template name="invisibleSBSEDocumentsInfo"/>
	</xsl:template>

	<xsl:template name="invisibleSBSEDocumentsInfo">
		<xsl:for-each select="p1:document">
			<table role="presentation">
				<tr>
					<td class="label">FIle Name:
					</td>
					<td>
						<div class="fakeBox">
							<xsl:value-of select="p1:conformedName" />
						</div>
					</td>
				</tr>
				<tr>
					<td class="label">Type:
					</td>
					<td>
						<div class="fakeBox">
							<xsl:value-of select="p1:conformedDocumentType" />
						</div>
					</td>
				</tr>
				<tr>
					<td class="label">Description:
					</td>
					<td>
						<div class="fakeBox">
							<xsl:value-of select="p1:description"/>
						</div>
					</td>
				</tr>					
				<tr>
					<td class="label">Contents:
					</td>
					<td>
						<div class="fakeBox">
							<xsl:value-of select="p1:contents" />
						</div>
					</td>
				</tr>		
			</table>
		</xsl:for-each>
	</xsl:template>
</xsl:stylesheet>
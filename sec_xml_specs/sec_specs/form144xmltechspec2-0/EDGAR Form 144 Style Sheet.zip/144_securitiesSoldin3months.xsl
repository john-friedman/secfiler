<!DOCTYPE xsl:stylesheet  [
		<!ENTITY ndash "&#8211;">
		]>
<xsl:stylesheet version="1.0"
				xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
				xmlns:p="http://www.sec.gov/edgar/ownership"
				xmlns:p1="http://www.sec.gov/edgar/common">

	<xsl:template name="securitiesSold">
		<table role="presentation" class="tableClass" id="submissionInformation">
			<tr width="100%" class="tableClassWithBg">
				<th width="33%" class="tableClass">Name and Address of Seller</th>
				<th width="33%" class="tableClass">Title of Securities Sold</th>
				<th width="8%" class="tableClass">Date of Sale</th>
				<th width="12%" class="tableClass">Amount of Securities Sold</th>
				<th width="14%" class="tableClass">Gross Proceeds</th>
			</tr>
			<xsl:for-each select="p:securitiesSoldInPast3Months">
				<tr>
					<td width="33%" class="tableClass">
						<xsl:value-of select="p:sellerDetails/p:name" />
						<br></br>
						<xsl:value-of select="p:sellerDetails/p:address/p1:street1" />
						<br></br>
						<xsl:if test="p:sellerDetails/p:address/p1:street2 !='' ">
							<xsl:value-of select="p:sellerDetails/p:address/p1:street2" />
							<br></br>
						</xsl:if>
						<xsl:value-of select="p:sellerDetails/p:address/p1:city" />
						&#160;
						<xsl:value-of select="p:sellerDetails/p:address/p1:stateOrCountry" />
						&#160;
						<xsl:value-of select="p:sellerDetails/p:address/p1:zipCode" />
					</td>
					<td width="33%" class="tableClass">
						<xsl:value-of select="p:securitiesClassTitle" />
					</td>
					<td width="8%" class="tableClass">
						<xsl:value-of select="p:saleDate" />
					</td>
					<td width="12%" class="tableClass">
						<xsl:value-of select="p:amountOfSecuritiesSold" />
					</td>
					<td width="14%" class="tableClass">
						<xsl:value-of select="p:grossProceeds" />
					</td>
				</tr>
			</xsl:for-each>
			<xsl:if test="not(p:securitiesSoldInPast3Months)">
				<tr>
					<td width="33%" class="tableClass"></td>
					<td width="33%" class="tableClass"></td>
					<td width="8%" class="tableClass"></td>
					<td width="12%" class="tableClass"></td>
					<td width="14%" class="tableClass"></td>
				</tr>
			</xsl:if>
		</table>
	</xsl:template>
</xsl:stylesheet>

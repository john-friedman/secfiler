<!DOCTYPE xsl:stylesheet  [
		<!ENTITY ndash "&#8211;">
		]>
<xsl:stylesheet version="1.0"
				xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
				xmlns:p="http://www.sec.gov/edgar/ownership"
				xmlns:p1="http://www.sec.gov/edgar/common">

	<xsl:template name="securitiesInfo">
		<table role="presentation" class="tableClass" id="submissionInformation">
			<tr width="100%" class="tableClassWithBg">
				<th width="23%" class="tableClass">Title of the Class of Securities To Be Sold</th>
				<th width="22%" class="tableClass">Name and Address of the Broker</th>
				<th width="11%" class="tableClass">Number of Shares or Other Units To Be Sold</th>
				<th width="12%" class="tableClass">Aggregate Market Value</th>
				<th width="11%" class="tableClass">Number of Shares or Other Units Outstanding</th>
				<th width="8%" class="tableClass">Approximate Date of Sale</th>
				<th width="12%" class="tableClass">Name the Securities Exchange</th>
			</tr>
			<xsl:for-each select="p:securitiesInformation">
				<tr width="100%" class="tableClass">
					<td width="23%" class="tableClass">
						<xsl:value-of select="p:securitiesClassTitle" />
					</td>
					<td width="22%" class="tableClass">
						<xsl:for-each select="p:brokerOrMarketmakerDetails">
							<div>
								<xsl:value-of select="p:name" />
								<br></br>
								<xsl:value-of select="p:address/p1:street1" />
								<br></br>
								<xsl:if test="p:address/p1:street2 != '' ">
									<xsl:value-of select="p:address/p1:street2" />
									<br></br>
								</xsl:if>
								<xsl:value-of select="p:address/p1:city" />
								&#160;
								<xsl:value-of select="p:address/p1:stateOrCountry" />
								&#160;
								<xsl:value-of select="p:address/p1:zipCode" />
							</div>
						</xsl:for-each>
					</td>
					<td width="11%" class="tableClass">
						<xsl:value-of select="p:noOfUnitsSold" />
					</td>
					<td width="12%" class="tableClass">
						<xsl:value-of select="p:aggregateMarketValue" />
					</td>
					<td width="11%" class="tableClass">
						<xsl:value-of select="p:noOfUnitsOutstanding" />
					</td>
					<td width="8%" class="tableClass">
						<xsl:value-of select="p:approxSaleDate" />
					</td>
					<td width="12%" class="tableClass">
						<xsl:for-each select="p:securitiesExchangeName">
							<div>
								<xsl:value-of select="." />
							</div>
						</xsl:for-each>
					</td>
				</tr>
			</xsl:for-each>
			<xsl:if test="not(p:securitiesInformation)">
				<tr>
					<td width="23%" class="tableClass"></td>
					<td width="22%" class="tableClass"></td>
					<td width="11%" class="tableClass"></td>
					<td width="12%" class="tableClass"></td>
					<td width="11%" class="tableClass"></td>
					<td width="8%" class="tableClass"></td>
					<td width="12%" class="tableClass"></td>
				</tr>
			</xsl:if>
		</table>
	</xsl:template>
</xsl:stylesheet>

<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0" 
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:p="http://www.sec.gov/edgar/ownership" 
	xmlns:p1="http://www.sec.gov/edgar/common">
	
	<xsl:template name="issuerInformation">
		<table role="presentation" class="filingInformation" id="submissionInformation">
			<tr>
				<td class="label">Name of Issuer</td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="p:issuerInfo/p:issuerName" />
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">SEC File Number</td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="p:issuerInfo/p:secFileNumber" />
					</div>				
				</td>
			</tr>
			<tr>
				<td class="label">Address of Issuer</td>
						<td>
								<div class="fakeBox">
									<xsl:value-of select="string(p:issuerInfo/p:issuerAddress/p1:street1)" />
						<br></br>
						<xsl:if test="string(p:issuerInfo/p:issuerAddress/p1:street2)!=''">
									<xsl:value-of select="string(p:issuerInfo/p:issuerAddress/p1:street2)" />
						<br></br>
        				</xsl:if>
									<xsl:value-of select="string(p:issuerInfo/p:issuerAddress/p1:city)" />
						<br></br>
									<xsl:call-template name="stateDescription">
							<xsl:with-param name="stateCode" select="string(./p:issuerInfo/p:issuerAddress/p1:stateOrCountry)" />
									</xsl:call-template>
						<br></br>
										<xsl:value-of select="string(p:issuerInfo/p:issuerAddress/p1:zipCode)" />
								</div>
						</td>
					</tr>
					<tr>
						<td class="label">Phone</td>
						<td>
					<div class="fakeBox">
										<xsl:value-of select="string(p:issuerInfo/p:issuerContactPhone)" />
								</div>
				</td>
			</tr>
			<tr>
				<td class="label">Name of Person for Whose Account the Securities are To Be Sold</td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="p:issuerInfo/p:nameOfPersonForWhoseAccountTheSecuritiesAreToBeSold" />
					</div>				
				</td>
			</tr>
			<tr>
				<td colspan="2">
				<div class="information" style="text-align:justify">
						See the definition of "person" in paragraph (a) of Rule 144. Information is to be given not only as to the person for whose account  
						the securities are to be sold but also as to all other persons included in that definition. In addition, information shall be given 
						as to sales by all persons whose sales are required by paragraph (e) of Rule 144 to be aggregated with sales  
						for the account of the person filing this notice.
					<br/>
					<br/>
				</div>
				</td>
			</tr>
			<xsl:for-each select="p:issuerInfo/p:relationshipsToIssuer/p:relationshipToIssuer">
			<tr>
				<td class="label">Relationship to Issuer</td>
				<td>
					<div class="fakeBox">
							<xsl:value-of select="." />
					</div>				
				</td>
			</tr>
			</xsl:for-each>
		</table>
	</xsl:template>
</xsl:stylesheet>

<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0" 
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:p="http://www.sec.gov/edgar/ownership" 
	xmlns:p1="http://www.sec.gov/edgar/common">
	
	<xsl:template name="signatureInfo">
		<table role="presentation" class="filingInformation" id="submissionInformation">
			<tr>
				<td class="label">Remarks</td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="p:remarks" />
					</div>				
				</td>
			</tr>
			<tr>
				<td class="label">Date of Notice</td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="p:noticeSignature/p:noticeDate" />
					</div>
				</td>
			</tr>
			<xsl:for-each select="p:noticeSignature/p:planAdoptionDates/p:planAdoptionDate">
			<tr>
				<td class="label">Date of Plan Adoption or Giving of Instruction, If Relying on Rule 10b5-1</td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="." />
					</div>
				</td>
			</tr>
			</xsl:for-each>
			<tr>
			<td colspan="2">
					<h4>
						<em>ATTENTION:</em>
					</h4>
			</td>
			</tr>
			<tr>
				<td colspan="2" style="text-align:justify">
					The person for whose account the securities to which this notice relates are to be sold hereby represents by signing
					this notice that he does not know any material adverse information in regard to the current and prospective
					operations of the Issuer of the securities to be sold which has not been publicly disclosed. If such person has
					adopted a written trading plan or given trading instructions to satisfy Rule 10b5-1 under the Exchange Act, by
					signing the form and indicating the date that the plan was adopted or the instruction given, that person makes
					such representation as of the plan adoption or instruction date.
				</td>
			</tr>
			<tr>
				<td class="label">Signature</td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="p:noticeSignature/p:signature" />
					</div>
				</td>
			</tr>
			<tr>
			<td colspan="2">
					<h4 style="text-align:center">
						<em>ATTENTION: Intentional misstatements or omission of facts constitute Federal Criminal Violations (See 18 U.S.C. 1001)</em>
					</h4>
			</td>
			</tr>
		</table>
	</xsl:template>
</xsl:stylesheet>

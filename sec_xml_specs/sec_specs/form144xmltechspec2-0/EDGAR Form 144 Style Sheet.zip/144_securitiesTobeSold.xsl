<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0" 
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:p="http://www.sec.gov/edgar/ownership" 
	xmlns:p1="http://www.sec.gov/edgar/common">
	
	<xsl:template name="securitiesToBeSold">
		<table role="presentation" class="tableClass" id="securitiesToBeSold">
		 <tr width="100%" class="tableClassWithBg">
				<th  width="14%" class="tableClassRight" >Title of the Class</th>
				<th  width="8%" class="tableClass">Date you Acquired</th>
				<th  width="16%" class="tableClass">Nature of Acquisition Transaction</th>
				<th  width="14%" class="tableClass">Name of Person from Whom Acquired</th>
				<th  width="4%" class="tableClass">Is this a Gift?</th>
				<th  width="8%" class="tableClass">Date Donor Acquired</th>
				<th  width="12%" class="tableClass">Amount of Securities Acquired</th>
				<th  width="8%" class="tableClass">Date of Payment</th>
				<th  width="16%" class="tableClassLeft">Nature of Payment <b>*</b></th>
				
			</tr>
			<xsl:for-each select="p:securitiesToBeSold">		
			<tr width="100%" class="tableClass">
				<td width="14%" class="tableClassRight">
						<xsl:value-of select="p:securitiesClassTitle" />
				</td>
				<td width="8%" class="tableClass">
						<xsl:value-of select="p:acquiredDate" />
				</td>
				<td width="16%" class="tableClass">
						<xsl:value-of select="p:natureOfAcquisitionTransaction" />
				</td>
				<td width="14%" class="tableClass">
						<xsl:value-of select="p:nameOfPersonfromWhomAcquired" />
				</td>
				<td width="4%" class="tableClass">
					<xsl:choose>
						<xsl:when test="p:isGiftTransaction = 'Y' or p:donarAcquiredDate!=''">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>
					</td>
				<td width="8%" class="tableClass">
							<xsl:value-of select="p:donarAcquiredDate" />
					</td>
				<td width="12%" class="tableClass">
						<xsl:value-of select="p:amountOfSecuritiesAcquired" />
				</td>
				<td width="8%" class="tableClass">
						<xsl:value-of select="p:paymentDate" />
				</td>
				<td width="16%" class="tableClassLeft">
						<xsl:value-of select="p:natureOfPayment" />
				</td>
			</tr>
			</xsl:for-each>
			<xsl:if test="not(p:securitiesToBeSold)">
				<tr>
					<td width="14%" class="tableClass"></td>
					<td width="8%" class="tableClass"></td>
					<td width="16%" class="tableClass"></td>
					<td width="14%" class="tableClass"></td>
					<td width="4%" class="tableClass"></td>
					<td width="8%" class="tableClass"></td>
					<td width="12%" class="tableClass"></td>
					<td width="8%" class="tableClass"></td>
					<td width="16%" class="tableClass"></td>
				</tr>
			</xsl:if>
		</table>
		<br/>
		<div class="information" style="text-align:justify">
			<b>*</b> If the securities were purchased and full payment therefor was not made in cash at the time of purchase, explain in the table or in a note 
			thereto the nature of the consideration given. If the consideration consisted of any note or other obligation, or if payment was made
			in installments describe the arrangement and state when the note or other obligation was discharged in full or the last installment paid.
		</div>
		<br/>
	</xsl:template>
</xsl:stylesheet>

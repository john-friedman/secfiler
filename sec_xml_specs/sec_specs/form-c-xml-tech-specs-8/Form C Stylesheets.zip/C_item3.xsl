<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:m1="http://www.sec.gov/edgar/formc"
	xmlns:ns1="http://www.sec.gov/edgar/common">

	<!-- Item 3 templates -->
	<xsl:template name="Item3">
		<h3>
			<em>Annual Report Disclosure Requirements
			</em>
		</h3>
		<xsl:call-template name="disclosureReq" />
	</xsl:template>

	<xsl:template name="disclosureReq">
		<table role="presentation">
			<tr>
			<xsl:if test="count(m1:annualReportDisclosureRequirements/m1:currentEmployees) &gt; 0">
				<td class="label">Current Number of Employees:</td>
					<td>
						<p>
							<div class="fakeBox2">
								<xsl:value-of
									select="string(m1:annualReportDisclosureRequirements/m1:currentEmployees)" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:annualReportDisclosureRequirements/m1:accountReview) &gt; 0">
				<td class="label">Mark here if the accountant’s review report includes modifications or if the audit report is qualified:  </td>
				<td>
					<xsl:choose>
						<xsl:when
							test="string(m1:annualReportDisclosureRequirements/m1:accountReview) = 'true'">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>
				</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:annualReportDisclosureRequirements/m1:totalAssetMostRecentFiscalYear) &gt; 0">
				<td class="label">Total Assets Most Recent Fiscal Year-end:</td>
					<td>
						<p>
							<div class="fakeBox2">
								<xsl:value-of
									select="string(m1:annualReportDisclosureRequirements/m1:totalAssetMostRecentFiscalYear)" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:annualReportDisclosureRequirements/m1:totalAssetPriorFiscalYear) &gt; 0">
				<td class="label">Total Assets Prior Fiscal Year-end:</td>
					<td>
						<p>
							<div class="fakeBox2">
								<xsl:value-of
									select="string(m1:annualReportDisclosureRequirements/m1:totalAssetPriorFiscalYear)" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:annualReportDisclosureRequirements/m1:cashEquiMostRecentFiscalYear) &gt; 0">
				<td class="label">Cash and Cash Equivalents Most Recent Fiscal Year-end:</td>
					<td>
						<p>
							<div class="fakeBox2">
								<xsl:value-of
									select="string(m1:annualReportDisclosureRequirements/m1:cashEquiMostRecentFiscalYear)" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:annualReportDisclosureRequirements/m1:cashEquiPriorFiscalYear) &gt; 0">
				<td class="label">Cash and Cash Equivalents Prior Fiscal Year-end:</td>
					<td>
						<p>
							<div class="fakeBox2">
								<xsl:value-of
									select="string(m1:annualReportDisclosureRequirements/m1:cashEquiPriorFiscalYear)" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:annualReportDisclosureRequirements/m1:actReceivedMostRecentFiscalYear) &gt; 0">
				<td class="label">Accounts Receivable Most Recent Fiscal Year-end:</td>
					<td>
						<p>
							<div class="fakeBox2">
								<xsl:value-of
									select="string(m1:annualReportDisclosureRequirements/m1:actReceivedMostRecentFiscalYear)" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:annualReportDisclosureRequirements/m1:actReceivedPriorFiscalYear) &gt; 0">
				<td class="label">Accounts Receivable Prior Fiscal Year-end:</td>
					<td>
						<p>
							<div class="fakeBox2">
								<xsl:value-of
									select="string(m1:annualReportDisclosureRequirements/m1:actReceivedPriorFiscalYear)" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:annualReportDisclosureRequirements/m1:shortTermDebtMostRecentFiscalYear) &gt; 0">
				<td class="label">Short-term Debt Most Recent Fiscal Year-end:</td>
					<td>
						<p>
							<div class="fakeBox2">
								<xsl:value-of
									select="string(m1:annualReportDisclosureRequirements/m1:shortTermDebtMostRecentFiscalYear)" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:annualReportDisclosureRequirements/m1:shortTermDebtPriorFiscalYear) &gt; 0">
				<td class="label">Short-term Debt Prior Fiscal Year-end:</td>
					<td>
						<p>
							<div class="fakeBox2">
								<xsl:value-of
									select="string(m1:annualReportDisclosureRequirements/m1:shortTermDebtPriorFiscalYear)" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:annualReportDisclosureRequirements/m1:longTermDebtMostRecentFiscalYear) &gt; 0">
				<td class="label">Long-term Debt Most Recent Fiscal Year-end:</td>
					<td>
						<p>
							<div class="fakeBox2">
								<xsl:value-of
									select="string(m1:annualReportDisclosureRequirements/m1:longTermDebtMostRecentFiscalYear)" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:annualReportDisclosureRequirements/m1:longTermDebtPriorFiscalYear) &gt; 0">
				<td class="label">Long-term Debt Prior Fiscal Year-end:</td>
					<td>
						<p>
							<div class="fakeBox2">
								<xsl:value-of
									select="string(m1:annualReportDisclosureRequirements/m1:longTermDebtPriorFiscalYear)" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:annualReportDisclosureRequirements/m1:revenueMostRecentFiscalYear) &gt; 0">
				<td class="label">Revenue/Sales Most Recent Fiscal Year-end:</td>
					<td>
						<p>
							<div class="fakeBox2">
								<xsl:value-of
									select="string(m1:annualReportDisclosureRequirements/m1:revenueMostRecentFiscalYear)" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:annualReportDisclosureRequirements/m1:revenuePriorFiscalYear) &gt; 0">
				<td class="label">Revenue/Sales Prior Fiscal Year-end:</td>
					<td>
						<p>
							<div class="fakeBox2">
								<xsl:value-of
									select="string(m1:annualReportDisclosureRequirements/m1:revenuePriorFiscalYear)" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:annualReportDisclosureRequirements/m1:costGoodsSoldMostRecentFiscalYear) &gt; 0">
				<td class="label">Cost of Goods Sold Most Recent Fiscal Year-end:</td>
					<td>
						<p>
							<div class="fakeBox2">
								<xsl:value-of
									select="string(m1:annualReportDisclosureRequirements/m1:costGoodsSoldMostRecentFiscalYear)" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:annualReportDisclosureRequirements/m1:costGoodsSoldPriorFiscalYear) &gt; 0">
				<td class="label">Cost of Goods Sold Prior Fiscal Year-end:</td>
					<td>
						<p>
							<div class="fakeBox2">
								<xsl:value-of
									select="string(m1:annualReportDisclosureRequirements/m1:costGoodsSoldPriorFiscalYear)" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:annualReportDisclosureRequirements/m1:taxPaidMostRecentFiscalYear) &gt; 0">
				<td class="label">Taxes Paid Most Recent Fiscal Year-end:</td>
					<td>
						<p>
							<div class="fakeBox2">
								<xsl:value-of
									select="string(m1:annualReportDisclosureRequirements/m1:taxPaidMostRecentFiscalYear)" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:annualReportDisclosureRequirements/m1:taxPaidPriorFiscalYear) &gt; 0">
				<td class="label">Taxes Paid Prior Fiscal Year-end:</td>
					<td>
						<p>
							<div class="fakeBox2">
								<xsl:value-of
									select="string(m1:annualReportDisclosureRequirements/m1:taxPaidPriorFiscalYear)" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:annualReportDisclosureRequirements/m1:netIncomeMostRecentFiscalYear) &gt; 0">
				<td class="label">Net Income Most Recent Fiscal Year-end:</td>
					<td>
						<p>
							<div class="fakeBox2">
								<xsl:value-of
									select="string(m1:annualReportDisclosureRequirements/m1:netIncomeMostRecentFiscalYear)" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:annualReportDisclosureRequirements/m1:netIncomePriorFiscalYear) &gt; 0">
				<td class="label">Net Income Prior Fiscal Year-end:</td>
					<td>
						<p>
							<div class="fakeBox2">
								<xsl:value-of
									select="string(m1:annualReportDisclosureRequirements/m1:netIncomePriorFiscalYear)" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
			</xsl:if>
			</tr>
			</table>
			
			<xsl:for-each select="m1:annualReportDisclosureRequirements/m1:issueJurisdictionSecuritiesOffering">
			<table role="presentation">
				<tr>
					<td class="label">Using the list below, select the jurisdictions in which the issuer intends to offer the securities:</td>
					<td>
						<p>
							<div class="fakeBox">
							<xsl:call-template name="stateDescription">
								<xsl:with-param name="stateCode" select="." />
								</xsl:call-template>
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
				</tr>
			</table>
			</xsl:for-each>

	</xsl:template>
</xsl:stylesheet>
<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:m1="http://www.sec.gov/edgar/formc"
	xmlns:ns1="http://www.sec.gov/edgar/common">

	<!-- Documents templates -->
    
	<xsl:template name="Documents">		
		<h3>
			<em>Documents</em>
		</h3>
		<xsl:call-template name="Formc_Documents"/>
	</xsl:template>
	

	<xsl:template name="Formc_Documents">
		<table role="presentation">
			<tr>
				<td class="label">File Name:
				</td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="ns1:conformedName" />
						<span>
							<xsl:text>&#160;</xsl:text>
						</span>
					</div>
				</td>
			</tr>
			<tr>
                <td class="label">Type:
                </td>
                <td>
                    <div class="fakeBox">
                        <xsl:value-of select="ns1:conformedDocumentType" />
                        <span>
                            <xsl:text>&#160;</xsl:text>
                        </span>
                    </div>
                </td>
            </tr>
            <tr>
                <td class="label">Description:
                </td>
                <td>
                    <div class="fakeBox">
                        <xsl:value-of select="ns1:description" />
                        <span>
                            <xsl:text>&#160;</xsl:text>
                        </span>
                    </div>
                </td>
            </tr>
            <tr>
                <td class="label">Contents:
                </td>
                <td>
                    <div class="fakeBox">
                        <xsl:value-of select="ns1:contents" />
                        <span>
                            <xsl:text>&#160;</xsl:text>
                        </span>
                    </div>
                </td>
            </tr>
		</table>
	</xsl:template>
</xsl:stylesheet>
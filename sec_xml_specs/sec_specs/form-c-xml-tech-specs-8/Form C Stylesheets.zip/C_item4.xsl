<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:m1="http://www.sec.gov/edgar/formc"
	xmlns:ns1="http://www.sec.gov/edgar/common">

	<!-- Item 5 templates -->
	<xsl:template name="Item4">
		<h3>
			<em>Signature
			</em>
		</h3>
		<xsl:call-template name="signature" />
	</xsl:template>
	<xsl:template name="signature">
		<!-- repeatable -->
		<xsl:for-each select="m1:signatureInfo/m1:issuerSignature">
			<table role="presentation">
			<h4>Pursuant to the requirements of Sections 4(a)(6) and 4A of the Securities Act of 1933 and Regulation Crowdfunding (§ 227.100-503), 
			the issuer certifies that it has reasonable grounds to  believe that it meets all of the requirements 
			for filing on Form C and has duly caused this Form to be signed on its behalf by the duly authorized undersigned.</h4>
				<tr>
					<td class="label">Issuer: </td>
					<td>
						<p>
							<div class="fakeBox">
								<xsl:value-of select="m1:issuer" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
				</tr>
				<tr>
					<td class="label">Signature:
					</td>
					<td>
						<p>
							<div class="fakeBox3">
								<xsl:value-of select="m1:issuerSignature" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
				</tr>
				<tr>
					<td class="label">Title: </td>
					<td>
						<p>
							<div class="fakeBox3">
								<xsl:value-of select="m1:issuerTitle" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
				</tr>

			</table>
		</xsl:for-each>
		<xsl:for-each select="m1:signatureInfo/m1:signaturePersons/m1:signaturePerson">
		<h4>Pursuant to the requirements of Sections 4(a)(6) and 4A of the Securities Act of 1933 and Regulation Crowdfunding 
			(§ 227.100-503), this Form C has been signed by the following persons in the capacities and on the dates indicated.</h4>
			<table role="presentation">
				<tr>
					<td class="label">Signature: </td>
					<td>
						<p>
							<div class="fakeBox">
								<xsl:value-of select="m1:personSignature" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
				</tr>
				<tr>
					<td class="label">Title:
					</td>
					<td>
						<p>
							<div class="fakeBox3">
								<xsl:value-of select="m1:personTitle" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
				</tr>
				<tr>
					<td class="label">Date: </td>
					<td>
						<p>
							<div class="fakeBox">
								<xsl:value-of select="m1:signatureDate" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
				</tr>
				</table>
		</xsl:for-each>			
	</xsl:template>
</xsl:stylesheet>
<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:m1="http://www.sec.gov/edgar/formc"
	xmlns:ns1="http://www.sec.gov/edgar/common">

	<!-- Item 1 templates -->
	<xsl:template name="Item1">
		<h3>
			<em>Issuer Information </em>
		</h3>
		<xsl:call-template name="issuerInfo" />
	</xsl:template>

	<xsl:template name="issuerInfo">
		<table role="presentation">
			<tr>
				<td class="label">Name of Issuer: </td>
				<td>
					<p>
						<div class="fakeBox">
							<xsl:value-of select="string(m1:issuerInformation/m1:issuerInfo/m1:nameOfIssuer)" />
							<span>
								<xsl:text>&#160;</xsl:text>
							</span>
						</div>
					</p>
				</td>
			</tr>
			<tr>
			<xsl:if test="count(m1:issuerInformation/m1:isAmendment) &gt; 0">
				<td class="label">Check box if Amendment is material and investors will have five business days to reconfirm </td>
				<td>
					<xsl:choose>
						<xsl:when
							test="string(m1:issuerInformation/m1:isAmendment) = 'true'">
							<img src="Images/box-checked.jpg" alt="Checkbox checked" />
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
						</xsl:otherwise>
					</xsl:choose>
				</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:issuerInformation/m1:progressUpdate) &gt; 0">
				<td class="label">Describe Progress Update: </td>
				<td>
					<p>
						<div class="fakeBox3">
							<xsl:value-of select="string(m1:issuerInformation/m1:progressUpdate)" />
							<span>
								<xsl:text>&#160;</xsl:text>
							</span>
						</div>
					</p>
				</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:issuerInformation/m1:natureOfAmendment) &gt; 0">
				<td class="label">Describe the Nature of the Amendment: </td>
				<td>
					<p>
						<div class="fakeBox3">
							<xsl:value-of select="string(m1:issuerInformation/m1:natureOfAmendment)" />
							<span>
								<xsl:text>&#160;</xsl:text>
							</span>
						</div>
					</p>
				</td>
			</xsl:if>
			</tr>
		</table>
		<xsl:if test="count(m1:issuerInformation/m1:issuerInfo/m1:legalStatus) &gt; 0">
				<h4>Legal Status of Issuer: </h4>
		<table role="presentation">
			<tr>
				<td class="label">Form: </td>
				<td>
					<p>
						<div class="fakeBox">
							<xsl:value-of select="string(m1:issuerInformation/m1:issuerInfo/m1:legalStatus/m1:legalStatusForm)" />
							<span>
								<xsl:text>&#160;</xsl:text>
							</span>
						</div>
					</p>
				</td>
			</tr>
			<xsl:choose>
			<xsl:when test="string(m1:issuerInformation/m1:issuerInfo/m1:legalStatus/m1:legalStatusForm) = 'Other'">
			<tr>
				<td class="label">Specify: </td>
				<td>
					<p>
						<div class="fakeBox3">
							<xsl:value-of select="string(m1:issuerInformation/m1:issuerInfo/m1:legalStatus/m1:legalStatusOtherDesc)" />
							<span>
								<xsl:text>&#160;</xsl:text>
							</span>
						</div>
					</p>
				</td>
			</tr>
			</xsl:when>
			</xsl:choose>
			<tr>
				<td class="label">Jurisdiction of Incorporation/Organization: </td>
				<td>
					<p>
						<div class="fakeBox">
						<xsl:call-template name="stateDescription">
							<xsl:with-param name="stateCode" select="string(m1:issuerInformation/m1:issuerInfo/m1:legalStatus/m1:jurisdictionOrganization)" />
						</xsl:call-template>
							<span>
								<xsl:text>&#160;</xsl:text>	
							</span>
						</div>
					</p>
				</td>
			</tr>
			<tr>
				<td class="label">Date of Incorporation/Organization: </td>
				<td>
					<p>
						<div class="fakeBox">
							<xsl:value-of select="string(m1:issuerInformation/m1:issuerInfo/m1:legalStatus/m1:dateIncorporation)" />
							<span>
								<xsl:text>&#160;</xsl:text>
							</span>
						</div>
					</p>
				</td>
			</tr>
		</table>
				<h4>Physical Address of Issuer: </h4>
		<table role="presentation">
			<tr>
				<td class="label">Address 1: </td>
				<td>
					<p>
						<div class="fakeBox">
							<xsl:value-of select="string(m1:issuerInformation/m1:issuerInfo/m1:issuerAddress/ns1:street1)" />
							<span>
								<xsl:text>&#160;</xsl:text>
							</span>
						</div>
					</p>
				</td>
			</tr>
			<tr>
			<xsl:if test="count(m1:issuerInformation/m1:issuerInfo/m1:issuerAddress/ns1:street2) &gt; 0">
				<td class="label">Address 2: </td>
				<td>
					<p>
						<div class="fakeBox">
							<xsl:value-of select="string(m1:issuerInformation/m1:issuerInfo/m1:issuerAddress/ns1:street2)" />
							<span>
								<xsl:text>&#160;</xsl:text>
							</span>
						</div>
					</p>
				</td>
			</xsl:if>
			</tr>
			<tr>
				<td class="label">City: </td>
				<td>
					<p>
						<div class="fakeBox">
							<xsl:value-of select="string(m1:issuerInformation/m1:issuerInfo/m1:issuerAddress/ns1:city)" />
							<span>
								<xsl:text>&#160;</xsl:text>
							</span>
						</div>
					</p>
				</td>
			</tr>
			<tr>
				<td class="label">State/Country: </td>
				<td>
					<p>
						<div class="fakeBox">
							<xsl:call-template name="stateDescription">
								<xsl:with-param name="stateCode"
									select="string(m1:issuerInformation/m1:issuerInfo/m1:issuerAddress/ns1:stateOrCountry)" />
							</xsl:call-template>
							<span>
								<xsl:text>&#160;</xsl:text>
							</span>
						</div>
					</p>
				</td>
			</tr>
			<tr>
				<td class="label">Mailing Zip/Postal Code: </td>
				<td>
					<p>
						<div class="fakeBox2">
							<xsl:value-of select="string(m1:issuerInformation/m1:issuerInfo/m1:issuerAddress/ns1:zipCode)" />
							<span>
								<xsl:text>&#160;</xsl:text>
							</span>
						</div>
					</p>
				</td>
			</tr>
			<tr>
				<td class="label">Website of Issuer: </td>
				<td>
					<p>
						<div class="fakeBox3">
							<xsl:value-of select="string(m1:issuerInformation/m1:issuerInfo/m1:issuerWebsite)" />
							<span>
								<xsl:text>&#160;</xsl:text>
							</span>
						</div>
					</p>
				</td>
			</tr>
		</table>
		</xsl:if>

	<table role="presentation">
		<tr>
			<xsl:if
				test="count(m1:issuerInformation/m1:isCoIssuer) &gt; 0">
				<td class="label">Is there a Co-issuer?  </td>
				<td>
					<xsl:choose>
						<xsl:when
							test="string(m1:issuerInformation/m1:isCoIssuer) = 'Y'">
							<img src="Images/radio-checked.jpg"
								alt="Radio button checked" />
							Yes
							<img src="Images/radio-unchecked.jpg"
								alt="Radio button not checked" />
							No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg"
								alt="Radio button not checked" />
							Yes
							<img src="Images/radio-checked.jpg"
								alt="Radio button checked" />
							No
						</xsl:otherwise>
					</xsl:choose>
				</td>
			</xsl:if>
		</tr>
	</table>
	<xsl:if test="string(m1:issuerInformation/m1:isCoIssuer) = 'Y'">
		<h4>
			If yes, specify the following for the Co-issuer:
		</h4>
		<xsl:for-each
			select="m1:issuerInformation/m1:coIssuers/m1:coIssuerInfo">
			<table role="presentation">
				<tr>
					<td class="label">EDGAR Filer?</td>
					<td>
						<table role="presentation">
							<tr>
								<td>
									<xsl:choose>
										<xsl:when test="m1:isEdgarFiler = 'EdgarFiler'">
											<img src="Images/box-checked.jpg" alt="Checkbox checked" />
										</xsl:when>
										<xsl:otherwise>
											<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
										</xsl:otherwise>
									</xsl:choose>
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td class="label">CIK of Co-issuer:  </td>
					<td>
						<p>
							<div class="fakeBox">
								<xsl:value-of select="m1:coIssuerCik" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
				</tr>
				<tr>
					<td class="label">Name of Co-issuer: </td>
					<td>
						<p>
							<div class="fakeBox">
								<xsl:value-of select="m1:nameOfCoIssuer" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
				</tr>
			</table>
			<xsl:if test="count(m1:coIssuerLegalStatus) &gt; 0">
				<h4>Legal Status of Co-issuer: </h4>
			<table role="presentation">
				<tr>
					<td class="label">Form: </td>
					<td>
						<p>
							<div class="fakeBox">
								<xsl:value-of
									select="m1:coIssuerLegalStatus/m1:legalStatusForm" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
				</tr>
				<xsl:choose>
					<xsl:when
						test="string(m1:coIssuerLegalStatus/m1:legalStatusForm) = 'Other'">
						<tr>
							<td class="label">Specify: </td>
							<td>
								<p>
									<div class="fakeBox3">
										<xsl:value-of
											select="string(m1:coIssuerLegalStatus/m1:legalStatusOtherDesc)" />
										<span>
											<xsl:text>&#160;</xsl:text>
										</span>
									</div>
								</p>
							</td>
						</tr>
					</xsl:when>
				</xsl:choose>
				<tr>
					<td class="label">Jurisdiction of Incorporation/Organization: </td>
					<td>
						<p>
							<div class="fakeBox">
								<xsl:call-template name="stateDescription">
									<xsl:with-param name="stateCode"
										select="m1:coIssuerLegalStatus/m1:jurisdictionOrganization" />
								</xsl:call-template>
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
				</tr>
				<tr>
					<td class="label">Date of Incorporation/Organization: </td>
					<td>
						<p>
							<div class="fakeBox">
								<xsl:value-of
									select="m1:coIssuerLegalStatus/m1:dateIncorporation" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
				</tr>
			</table>
			</xsl:if>
			<xsl:if test="count(m1:coIssuerAddress) &gt; 0">
			<h4>Physical Address of Co-issuer: </h4>
			<table role="presentation">
				<tr>
					<td class="label">Address 1: </td>
					<td>
						<p>
							<div class="fakeBox">
								<xsl:value-of
									select="m1:coIssuerAddress/ns1:street1" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
				</tr>
				<tr>
					<xsl:if test="count(m1:coIssuerAddress/ns1:street2) &gt; 0">
						<td class="label">Address 2: </td>
						<td>
							<p>
								<div class="fakeBox">
									<xsl:value-of
										select="string(m1:coIssuerAddress/ns1:street2)" />
									<span>
										<xsl:text>&#160;</xsl:text>
									</span>
								</div>
							</p>
						</td>
					</xsl:if>
				</tr>
				<tr>
					<td class="label">City: </td>
					<td>
						<p>
							<div class="fakeBox">
								<xsl:value-of select="m1:coIssuerAddress/ns1:city" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
				</tr>
				<tr>
					<td class="label">State/Country: </td>
					<td>
						<p>
							<div class="fakeBox">
								<xsl:call-template name="stateDescription">
									<xsl:with-param name="stateCode"
										select="m1:coIssuerAddress/ns1:stateOrCountry" />
								</xsl:call-template>
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
				</tr>
				<tr>
					<td class="label">Mailing Zip/Postal Code: </td>
					<td>
						<p>
							<div class="fakeBox2">
								<xsl:value-of
									select="string(m1:coIssuerAddress/ns1:zipCode)" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
				</tr>
				<tr>
					<td class="label">Website of Co-issuer: </td>
					<td>
						<p>
							<div class="fakeBox3">
								<xsl:value-of
									select="m1:coIssuerWebsite" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</p>
					</td>
				</tr>
			</table>
			<br/>
			</xsl:if>
		</xsl:for-each>
	</xsl:if>
		<table role="presentation">
		<xsl:if test="count(m1:issuerInformation/m1:commissionCik) &gt; 0">
				<h4>Intermediary through which the Offering will be Conducted: </h4>
		
			<tr>
				<td class="label">CIK: </td>
				<td>
					<p>
						<div class="fakeBox2">
							<xsl:value-of select="string(m1:issuerInformation/m1:commissionCik)" />
							<span>
								<xsl:text>&#160;</xsl:text>
							</span>
						</div>
					</p>
				</td>
			</tr>
			<tr>
				<td class="label">Company Name: </td>
				<td>
					<p>
						<div class="fakeBox">
							<xsl:value-of select="string(m1:issuerInformation/m1:companyName)" />
							<span>
								<xsl:text>&#160;</xsl:text>
							</span>
						</div>
					</p>
				</td>
			</tr>
			<tr>
				<td class="label">Commission File Number: </td>
				<td>
					<p>
						<div class="fakeBox2">
							<xsl:value-of select="string(m1:issuerInformation/m1:commissionFileNumber)" />
							<span>
								<xsl:text>&#160;</xsl:text>
							</span>
						</div>
					</p>
				</td>
			</tr>
		</xsl:if>
		<xsl:if test="count(m1:issuerInformation/m1:crdNumber) &gt; 0">
			<tr>
				<td class="label">CRD Number: </td>
				<td>
					<p>
						<div class="fakeBox">
							<xsl:value-of select="string(m1:issuerInformation/m1:crdNumber)" />
							<span>
								<xsl:text>&#160;</xsl:text>
							</span>
						</div>
					</p>
				</td>
			</tr>
		</xsl:if>
		</table>
	</xsl:template>
</xsl:stylesheet>
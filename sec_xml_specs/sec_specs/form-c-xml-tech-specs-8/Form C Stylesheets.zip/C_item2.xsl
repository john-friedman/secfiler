<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:m1="http://www.sec.gov/edgar/formc"
	xmlns:ns1="http://www.sec.gov/edgar/common">

	<!-- Item 2 templates -->
	<xsl:template name="Item2">
		<h3>
			<em>Offering Information
			</em>
		</h3>
		<xsl:call-template name="offeringInfo" />
	</xsl:template>

	<xsl:template name="offeringInfo">
		<table role="presentation">
		<xsl:if test="count(m1:offeringInformation/m1:compensationAmount) &gt; 0">
			<tr>
				<td class="label">Amount of compensation to be paid to the intermediary, 
				whether as a dollar amount or a percentage of the offering amount, 
				or a good faith estimate if the exact amount is not available at the time of the filing,
				for conducting the offering, including the amount of referral and any other fees associated with the offering:
				</td>
				<td>
					<p>
						<div class="fakeBox3">
							<xsl:value-of
								select="string(m1:offeringInformation/m1:compensationAmount)" />
							<span>
								<xsl:text>&#160;</xsl:text>
							</span>
						</div>
					</p>
				</td>
			</tr>
			</xsl:if>
			<tr>
			<xsl:if test="count(m1:offeringInformation/m1:financialInterest) &gt; 0">
				<td class="label">
					Any other financial interest in the issuer held by the intermediary, or any arrangement for the intermediary to acquire such an interest:
				</td>
				<td>
					<p>
						<div class="fakeBox3">
							<xsl:value-of
								select="string(m1:offeringInformation/m1:financialInterest)" />
							<span>
								<xsl:text>&#160;</xsl:text>
							</span>
						</div>
					</p>
				</td>
			</xsl:if>
			</tr>
		</table>
		<table role="presentation">
			<tr>
			<xsl:if test="count(m1:offeringInformation/m1:securityOfferedType) &gt; 0">
				<td class="label">Type of Security Offered:
				</td>
				<td>
					<p>
						<div class="fakeBox2">
							<xsl:value-of
								select="string(m1:offeringInformation/m1:securityOfferedType)" />
							<span>
								<xsl:text>&#160;</xsl:text>
							</span>
						</div>
					</p>
				</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:offeringInformation/m1:securityOfferedOtherDesc) &gt; 0">
				<td class="label">Specify:
				</td>
				<td>
					<p>
						<div class="fakeBox3">
							<xsl:value-of
								select="string(m1:offeringInformation/m1:securityOfferedOtherDesc)" />
							<span>
								<xsl:text>&#160;</xsl:text>
							</span>
						</div>
					</p>
				</td>
			</xsl:if>
			</tr>
		</table>
		<table role="presentation">
			<tr>
			<xsl:if test="count(m1:offeringInformation/m1:noOfSecurityOffered) &gt; 0">
				<td class="label">
					Target Number of Securities to be Offered:
				</td>
				<td>
					<p>
						<div class="fakeBox2">
							<xsl:value-of
								select="string(m1:offeringInformation/m1:noOfSecurityOffered)" />
							<span>
								<xsl:text>&#160;</xsl:text>
							</span>
						</div>
					</p>
				</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:offeringInformation/m1:price) &gt; 0">
				<td class="label">Price: </td>
				<td>
					<p>
						<div class="fakeBox2">
							<xsl:value-of
								select="string(m1:offeringInformation/m1:price)" />
							<span>
								<xsl:text>&#160;</xsl:text>
							</span>
						</div>
					</p>
				</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:offeringInformation/m1:priceDeterminationMethod) &gt; 0">
				<td class="label">Price (or Method for Determining Price): </td>
				<td>
					<p>
						<div class="fakeBox3">
							<xsl:value-of
								select="string(m1:offeringInformation/m1:priceDeterminationMethod)" />
							<span>
								<xsl:text>&#160;</xsl:text>
							</span>
						</div>
					</p>
				</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:offeringInformation/m1:offeringAmount) &gt; 0">
				<td class="label">Target Offering Amount: </td>
				<td>
					<p>
						<div class="fakeBox2">
							<xsl:value-of
								select="string(m1:offeringInformation/m1:offeringAmount)" />
							<span>
								<xsl:text>&#160;</xsl:text>
							</span>
						</div>
					</p>
				</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:offeringInformation/m1:maximumOfferingAmount) &gt; 0">
				<td class="label">Maximum Offering Amount (if different from Target Offering Amount):  </td>
				<td>
					<p>
						<div align="left">
							<div class="fakeBox2">
								<xsl:value-of
									select="string(m1:offeringInformation/m1:maximumOfferingAmount)" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</div>
					</p>
				</td>
			</xsl:if>
			</tr>
			</table>
			<table role="presentation">
			<tr>
			<xsl:if test="count(m1:offeringInformation/m1:overSubscriptionAccepted) &gt; 0">
				<td class="label">Oversubscriptions Accepted:  </td>
				<td>
					<xsl:choose>
						<xsl:when
							test="string(m1:offeringInformation/m1:overSubscriptionAccepted) = 'Y'">
							<img src="Images/radio-checked.jpg" alt="Radio button checked" />
								Yes
								<img src="Images/radio-unchecked.jpg" alt="Radio button not checked" />
								No
						</xsl:when>
						<xsl:otherwise>
							<img src="Images/radio-unchecked.jpg" alt="Radio button not checked" />
								Yes
								<img src="Images/radio-checked.jpg" alt="Radio button checked" />
								No
						</xsl:otherwise>
					</xsl:choose>
				</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:offeringInformation/m1:overSubscriptionAllocationType) &gt; 0">
				<td class="label">
					If yes, disclose how oversubscriptions will be allocated:
				</td>
				<td>
					<p>
						<div align="left">
							<div class="fakeBox2">
								<xsl:value-of
									select="string(m1:offeringInformation/m1:overSubscriptionAllocationType)" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</div>
					</p>
				</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:offeringInformation/m1:descOverSubscription) &gt; 0">
				<td class="label">
					Provide a description:
				</td>
				<td>
					<p>
						<div align="left">
							<div class="fakeBox3">
								<xsl:value-of
									select="string(m1:offeringInformation/m1:descOverSubscription)" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</div>
					</p>
				</td>
			</xsl:if>
			</tr>
			<tr>
			<xsl:if test="count(m1:offeringInformation/m1:deadlineDate) &gt; 0">
				<td class="label">
					Deadline to reach the Target Offering Amount:
				</td>
				<td>
					<p>
						<div align="left">
							<div class="fakeBox2">
								<xsl:value-of
									select="string(m1:offeringInformation/m1:deadlineDate)" />
								<span>
									<xsl:text>&#160;</xsl:text>
								</span>
							</div>
						</div>
					</p>
				</td>
			</xsl:if>
			</tr>
		</table>
		<tr>
			<xsl:if test="count(m1:offeringInformation/m1:deadlineDate) &gt; 0">
					<tr>
						<p>NOTE: If the sum of the investment commitments does not equal
						or exceed the target offering amount at the offering deadline,
						no securities will be sold in the offering, investment commitments will be cancelled and committed funds will be returned.</p>
					</tr>
				</xsl:if>	
			</tr>
	</xsl:template>
</xsl:stylesheet>
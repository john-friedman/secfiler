﻿<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:m1="http://www.sec.gov/edgar/formc"
	xmlns:ns1="http://www.sec.gov/edgar/common">

	<xsl:import href="util.xsl" />

	<xsl:output method="html" indent="no" encoding="iso-8859-1"
		doctype-public="-//W3C//DTD XHTML 1.0 Strict//EN" doctype-system="http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd" />

	<xsl:template match="/">
		<html>
			<head>
				<link rel="stylesheet" type="text/css" href="css/SDR_print.css" />
			</head>

			<body lang="en-US" text="#000000" bgcolor="#ffffff">
				<div style="display:none">
					schemaVersion:
					<xsl:value-of select="string(m1:edgarSubmission/m1:schemaVersion)" />
				</div>
				<xsl:call-template name="header" />
				<xsl:apply-templates>
					<xsl:with-param name="submissionType"
						select="string(m1:edgarSubmission/m1:headerData/m1:submissionType)" />
				</xsl:apply-templates>

			</body>
		</html>
	</xsl:template>

	<!-- Header Template START -->
	<xsl:template name="header">
		<div class="contentwrapper">
			<table role="presentation" id="header">
				<tr>
					<td class="title">FORM C </td>
					<td rowspan="2" class="center">
						UNITED STATES
						<br />
						SECURITIES AND EXCHANGE COMMISSION
						<br />
						Washington, D.C. 20549

						<br />
					</td>
					<td class="title">OMB APPROVAL</td>
				</tr>
				<xsl:if test="m1:edgarSubmission/m1:headerData/m1:submissionType = 'C'">
					<tr>
						<td class="side" style="text-align: center;">
							<p>
								<br />
								FORM C
								<br />
							</p>
						</td>
						<td width="25%" class="side">
							<p>OMB Number:&#160;&#160;####-####</p>
							<hr></hr>
							<p>Estimated average burden hours per response:&#160;##.#</p>
						</td>
					</tr>
				</xsl:if>
				<xsl:if test="m1:edgarSubmission/m1:headerData/m1:submissionType = 'C-W'">
					<tr>
						<td class="side" style="text-align: center;">
							<p>
								<br />
								FORM C-W
								<br />
							</p>
						</td>
						<td width="25%" class="side">
							<p>OMB Number:&#160;&#160;####-####</p>
							<hr></hr>
							<p>Estimated average burden hours per response:&#160;##.#</p>
						</td>
					</tr>
				</xsl:if>

				<xsl:if
					test="m1:edgarSubmission/m1:headerData/m1:submissionType = 'C-U'">
					<tr>
						<td class="side" style="text-align: center;">
							<p>
								<br />
								FORM C-U
								<br />
							</p>
						</td>
						<td width="25%" class="side">
							<p>OMB Number:&#160;&#160;####-####</p>
							<hr></hr>
							<p>Estimated average burden hours per response:&#160;##.#</p>
						</td>
					</tr>
				</xsl:if>

				<xsl:if
					test="m1:edgarSubmission/m1:headerData/m1:submissionType = 'C-U-W'">
					<tr>
						<td class="side" style="text-align: center;">
							<p>
								<br />
								FORM C-U-W
								<br />
							</p>
						</td>
						<td width="25%" class="side">
							<p>OMB Number:&#160;&#160;####-####</p>
							<hr></hr>
							<p>Estimated average burden hours per response:&#160;##.#</p>
						</td>
					</tr>
				</xsl:if>

				<xsl:if
					test="m1:edgarSubmission/m1:headerData/m1:submissionType = 'C/A'">
					<tr>
						<td class="side" style="text-align: center;">
							<p>
								<br />
								FORM C/A
								<br />
							</p>
						</td>
						<td width="25%" class="side">
							<p>OMB Number:&#160;&#160;####-####</p>
							<hr></hr>
							<p>Estimated average burden hours per response:&#160;##.#</p>
						</td>
					</tr>
				</xsl:if>
				<xsl:if test="m1:edgarSubmission/m1:headerData/m1:submissionType = 'C/A-W'">
					<tr>
						<td class="side" style="text-align: center;">
							<p>
								<br />
								FORM C/A-W
								<br />
							</p>
						</td>
						<td width="25%" class="side">
							<p>OMB Number:&#160;&#160;####-####</p>
							<hr></hr>
							<p>Estimated average burden hours per response:&#160;##.#</p>
						</td>
					</tr>
				</xsl:if>
				<xsl:if test="m1:edgarSubmission/m1:headerData/m1:submissionType = 'C-AR'">
					<tr>
						<td class="side" style="text-align: center;">
							<p>
								<br />
								FORM C-AR
								<br />
							</p>
						</td>
						<td width="25%" class="side">
							<p>OMB Number:&#160;&#160;####-####</p>
							<hr></hr>
							<p>Estimated average burden hours per response:&#160;##.#</p>
						</td>
					</tr>
				</xsl:if>
				<xsl:if test="m1:edgarSubmission/m1:headerData/m1:submissionType = 'C-AR-W'">
					<tr>
						<td class="side" style="text-align: center;">
							<p>
								<br />
								FORM C-AR-W
								<br />
							</p>
						</td>
						<td width="25%" class="side">
							<p>OMB Number:&#160;&#160;####-####</p>
							<hr></hr>
							<p>Estimated average burden hours per response:&#160;##.#</p>
						</td>
					</tr>
				</xsl:if>
				<xsl:if test="m1:edgarSubmission/m1:headerData/m1:submissionType = 'C-AR/A'">
					<tr>
						<td class="side" style="text-align: center;">
							<p>
								<br />
								FORM C-AR/A
								<br />
							</p>
						</td>
						<td width="25%" class="side">
							<p>OMB Number:&#160;&#160;####-####</p>
							<hr></hr>
							<p>Estimated average burden hours per response:&#160;##.#</p>
						</td>
					</tr>
				</xsl:if>
				<xsl:if test="m1:edgarSubmission/m1:headerData/m1:submissionType = 'C-AR/A-W'">
					<tr>
						<td class="side" style="text-align: center;">
							<p>
								<br />
								FORM C-AR/A-W
								<br />
							</p>
						</td>
						<td width="25%" class="side">
							<p>OMB Number:&#160;&#160;####-####</p>
							<hr></hr>
							<p>Estimated average burden hours per response:&#160;##.#</p>
						</td>
					</tr>
				</xsl:if>
				<xsl:if test="m1:edgarSubmission/m1:headerData/m1:submissionType = 'C-TR'">
					<tr>
						<td class="side" style="text-align: center;">
							<p>
								<br />
								FORM C-TR
								<br />
							</p>
						</td>
						<td width="25%" class="side">
							<p>OMB Number:&#160;&#160;####-####</p>
							<hr></hr>
							<p>Estimated average burden hours per response:&#160;##.#</p>
						</td>
					</tr>
				</xsl:if>
				<xsl:if test="m1:edgarSubmission/m1:headerData/m1:submissionType = 'C-TR-W'">
					<tr>
						<td class="side" style="text-align: center;">
							<p>
								<br />
								FORM C-TR-W
								<br />
							</p>
						</td>
						<td width="25%" class="side">
							<p>OMB Number:&#160;&#160;####-####</p>
							<hr></hr>
							<p>Estimated average burden hours per response:&#160;##.#</p>
						</td>
					</tr>
				</xsl:if>
			</table>
		</div>
	</xsl:template>
	<!-- Header Template END -->

	<!-- Form C: Filer Information Template START -->
	<xsl:template name="headerData" match="m1:edgarSubmission/m1:headerData">
		<div id="info">
			<div class="contentwrapper">
				<div class="content">
					<h1>Form C: Filer Information</h1>
					<table role="presentation">
						<tr>
							<td class="label">Filer CIK:</td>
							<td>
								<div class="fakeBox2">
									<xsl:value-of
										select="string(m1:filerInfo/m1:filer/m1:filerCredentials/m1:filerCik)" />
									<span>
										<xsl:text>&#160;</xsl:text>
									</span>
								</div>
							</td>
						</tr>
						<tr>
							<td class="label">Filer CCC:</td>
							<td>
								<div class="fakeBox2">
									<xsl:value-of
										select="string(m1:filerInfo/m1:filer/m1:filerCredentials/m1:filerCcc)" />
									<span>
										<xsl:text>&#160;</xsl:text>
									</span>
								</div>

							</td>
						</tr>
						<tr>
						<xsl:if test="count(m1:filerInfo/m1:filer/m1:fileNumber) &gt; 0">
							<td class="label">File Number:</td>
							<td>
								<div class="fakeBox2">
									<xsl:value-of
										select="string(m1:filerInfo/m1:filer/m1:fileNumber)" />
									<span>
										<xsl:text>&#160;</xsl:text>
									</span>
								</div>
							</td>
						</xsl:if>
						</tr>
						<tr>
						<xsl:if test="count(m1:filerInfo/m1:period) &gt; 0">
							<td class="label">Period: </td>
							<td>
								<p>
									<div class="fakeBox">
										<xsl:value-of select="string(m1:filerInfo/m1:period)" />
										<span>
											<xsl:text>&#160;</xsl:text>
										</span>
									</div>
								</p>
							</td>
						</xsl:if>
						</tr>
						<tr>
							<td class="label">Is this a LIVE or TEST Filing?</td>
							<td>
								<span class="yesNo">
									<xsl:choose>
										<xsl:when test="count(m1:filerInfo/m1:liveTestFlag) &gt; 0">
											<xsl:choose>
												<xsl:when test="string(m1:filerInfo/m1:liveTestFlag) = 'LIVE'">
													<img src="Images/radio-checked.jpg" alt="Radio button checked" />
													LIVE
													<img src="Images/radio-unchecked.jpg" alt="Radio button not checked" />
													TEST
												</xsl:when>
											</xsl:choose>
											<xsl:choose>
												<xsl:when test="string(m1:filerInfo/m1:liveTestFlag) = 'TEST'">
													<img src="Images/radio-unchecked.jpg" alt="Radio button not checked" />
													LIVE
													<img src="Images/radio-checked.jpg" alt="Radio button checked" />
													TEST
												</xsl:when>
											</xsl:choose>
										</xsl:when>
										<xsl:otherwise>
											<img src="Images/radio-unchecked.jpg" alt="Radio button not checked" />
											LIVE
											<img src="Images/radio-unchecked.jpg" alt="Radio button not checked" />
											TEST
										</xsl:otherwise>
									</xsl:choose>
								</span>
							</td>
						</tr>
						<tr>
						<xsl:if test="count(m1:filerInfo/m1:flags/m1:confirmingCopyFlag) &gt; 0">
							<td class="label">Is this an electronic copy of an official filing
								submitted in paper format in connection with a hardship
								exemption?</td>
							<td>
								<xsl:choose>
									<xsl:when
										test="string(m1:filerInfo/m1:flags/m1:confirmingCopyFlag) = 'true'">
										<img src="Images/box-checked.jpg" alt="Checkbox checked" />
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
									</xsl:otherwise>
								</xsl:choose>
							</td>
							</xsl:if>
						</tr>
						<tr>
						<xsl:if test="count(m1:filerInfo/m1:flags/m1:returnCopyFlag) &gt; 0">
							<td class="label">Would you like a Return Copy?</td>
							<td>
								<xsl:choose>
									<xsl:when
										test="string(m1:filerInfo/m1:flags/m1:returnCopyFlag) = 'true'">
										<img src="Images/box-checked.jpg" alt="Checkbox checked" />
									</xsl:when>
									<xsl:otherwise>
										<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
									</xsl:otherwise>
								</xsl:choose>
							</td>
						</xsl:if>
						</tr>
					</table>
					<h4>Submission Contact Information</h4>
					<table role="presentation">
						<tr>
							<td class="label">Name:</td>
							<td>
								<div class="fakeBox3">
									<xsl:value-of select="string(m1:filerInfo/m1:contact/m1:contactName)" />
									<span>
										<xsl:text>&#160;</xsl:text>
									</span>
								</div>
							</td>
						</tr>
						<tr>
							<td class="label">Phone Number:</td>
							<td>
								<div class="fakeBox2">
									<xsl:value-of
										select="string(m1:filerInfo/m1:contact/m1:contactPhone)" />
									<span>
										<xsl:text>&#160;</xsl:text>
									</span>
								</div>

							</td>
						</tr>
						<tr>
							<td class="label">Contact E-Mail Address:</td>
							<td>
								<div class="fakeBox">
									<xsl:value-of
										select="string(m1:filerInfo/m1:contact/m1:contactEmail)" />
									<span>
										<xsl:text>&#160;</xsl:text>
									</span>
								</div>
							</td>
						</tr>
						<tr>
						<xsl:if test="count(m1:filerInfo/m1:flags/m1:overrideInternetFlag) &gt; 0">
							<td class="label">Notify via Filing Website only?</td>
							<td>
								<xsl:choose>
									<xsl:when
										test="string(m1:filerInfo/m1:flags/m1:overrideInternetFlag) = 'true'">
										<img src="Images/box-checked.jpg" alt="Checkbox checked" />

									</xsl:when>
									<xsl:otherwise>
										<img src="Images/box-unchecked.jpg" alt="Checkbox not checked" />
									</xsl:otherwise>
								</xsl:choose>
							</td>
						</xsl:if>
						</tr>
						<xsl:if test="count(m1:filerInfo/m1:notifications/m1:notificationEmail) &gt; 0">
						<xsl:for-each
						select="m1:filerInfo/m1:notifications/m1:notificationEmail">
								<tr>
									<td class="label">Notification Email Address:</td>
									<td>
										<div class="fakeBox">
											<xsl:value-of select="." />
											<span>
												<xsl:text>&#160;</xsl:text>
											</span>
										</div>
									</td>
								</tr>
						</xsl:for-each>
						</xsl:if>
					</table>
				</div>
			</div>
		</div>
	</xsl:template>
	<!-- Form C: Filer Template Information END -->

	<!-- Form Data Template START -->
	<xsl:template name="formData" match="m1:edgarSubmission/m1:formData">
		<xsl:param name="submissionType" />
		<div class="content">
			<h1>Form C: Issuer Information</h1>
			<div class="form1">
				<xsl:call-template name="Item1">
				</xsl:call-template>
			</div>
		<xsl:if
			test="count(m1:offeringInformation) &gt; 0">
			<h1>Form C: Offering Information</h1>
			<div class="form1">
				<xsl:call-template name="Item2" />
			</div>
		</xsl:if>
		<xsl:if 
			test="count(m1:annualReportDisclosureRequirements) &gt; 0">
			<h1>Form C: Annual Report Disclosure Requirements</h1>
			<div class="form1">
				<xsl:call-template name="Item3" />
			</div>
		</xsl:if>
			<h1>Form C: Signature</h1>
			<div class="form1">
				<xsl:call-template name="Item4" />
			</div>
		</div>
	</xsl:template>
	<!-- Form Data Template END -->

	<!-- FormC Documents Template START -->

	<xsl:template name="documents"
		match="m1:edgarSubmission/m1:documents/ns1:document">
		<div style="display:none">
			<div class="content">
				<h1>Attach Documents List</h1>
				<div class="form1">
					<xsl:call-template name="Documents" />
				</div>
			</div>
		</div>
	</xsl:template>

	<!-- FormC Documents Template END -->

	<!-- items START -->
	<xsl:include href="C_item1.xsl" />
	<xsl:include href="C_item2.xsl" />
	<xsl:include href="C_item3.xsl" />
	<xsl:include href="C_item4.xsl" />
	<xsl:include href="C_documents.xsl" />
	<!-- items END -->
	<xsl:include href="SDR_State_Codes.xsl" />
</xsl:stylesheet>
    
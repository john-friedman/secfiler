<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:m1="http://www.sec.gov/edgar/ma_common_drp"
	xmlns:ns1="http://www.sec.gov/edgar/common" xmlns:ns3="http://www.sec.gov/edgar/common_drp"
	xmlns:ns2="http://www.sec.gov/edgar/common_ma" xmlns:ns4="http://www.sec.gov/edgar/mai_drp"
	xmlns:n2="http://www.sec.gov/edgar/maifiler">



	<!-- Item 2 templates -->

	<xsl:template name="Item2">
		<link href="style.css" rel="stylesheet" type="text/css" />
		<div id="maiItem5">
			<div class="contentwrapper">
				<div class="content">
					<h1>Item 2 Other Names</h1>
					<div class="form1">
                    <!-- <h2>Full Legal Name</h2>  -->
          <p>Enter  the following information for all other names that the individual 
           has used or is using, or by which the individual is known or has been known, other 
           than the individual&#180;s legal name, since  the age of 18.&#160; </p>
          <p>This space should  include, for example, nicknames, aliases, and names used 
          before or after marriage.</p>
     <xsl:if
			test="(count(n2:otherNames/n2:otherName) &gt; 0)">
             <p class="minutia">(Enter all the letters of each name and not
              initials or other abbreviations. If no middle name, enter NMN
              on that line.)</p>
      <xsl:for-each
			select="n2:otherNames/n2:otherName">
			
			<div class="tableStyle" style="margin-left:0; margin-right:0;">
			<div class="tableRow">
				<div class="tdStyle1 tdTwoCol1"><strong>Last Name:</strong></div>
				<div class="tdStyle1 tdTwoCol2Textbox">
					<xsl:value-of select="ns2:lastName" /> 					
				</div>
			</div><div style="clear:both"></div>
			<div class="tableRow">
				<div class="tdStyle1 tdTwoCol1"><strong>First Name:</strong></div>
				<div class="tdStyle1 tdTwoCol2Textbox"> 
					<xsl:value-of select="ns2:firstName" /> 					
				</div>
			</div><div style="clear:both"></div>
			<div class="tableRow">
				<div class="tdStyle1 tdTwoCol1"><strong>Middle Name:</strong></div>
				<div class="tdStyle1 tdTwoCol2Textbox">
					<xsl:value-of select="ns2:middleName" /> 					
				</div>
			</div><div style="clear:both"></div>
			<div class="tableRow">
				<div class="tdStyle1 tdTwoCol1"><strong>Suffix:</strong></div>
				<div class="tdStyle1 tdTwoCol2Textbox">
					<xsl:value-of select="ns2:suffix" />  					
				</div>
			</div><div style="clear:both"></div>	
			</div>
        <br /> <br />
      
	  
	  </xsl:for-each>
     </xsl:if> 
    </div>
  </div>
  </div>
</div>
</xsl:template>
</xsl:stylesheet>
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:m1="http://www.sec.gov/edgar/ma_common_drp"
	xmlns:ns1="http://www.sec.gov/edgar/common" xmlns:ns3="http://www.sec.gov/edgar/common_drp"
	xmlns:ns2="http://www.sec.gov/edgar/common_ma" xmlns:ns4="http://www.sec.gov/edgar/mai_drp"
	xmlns:n2="http://www.sec.gov/edgar/maifiler">



	<!-- Item 7 templates -->

	<xsl:template name="Item7"><link href="style.css" rel="stylesheet" type="text/css" />
		
		<div id="maiItem7">
  <div class="contentwrapper">
    <div class="content">
      <h1>Item 7 Signature and Self-Certification</h1>

          <p>NOTE: &#160;In addition to completing Item 7, to the extent that the individual is 
          a <em>non-resident</em>, a Form MA-NR completed and signed by the individual must be 
          attached as an exhibit to this Form MA-I.</p>		
      <h2>Complete Either Subpart A or Subpart B:</h2>

      <p><em>By typing a name in the signature field, the signatory acknowledges and 
       represents that the entry constitutes in every way, use, or aspect, his or her 
       legally binding signature.</em></p>

      <h3>A. For <em>Municipal Advisory Firms</em> filing this form:</h3>
      
      <p>The <em>municipal advisory firm</em> has obtained and retained written 
      consent from the individual that service of any civil action brought by, 
      or notice of any <em>proceeding</em> before, the <em>SEC</em> or any 
      <em>self-regulatory organization</em> in connection with the individual's 
      <em>municipal advisory activities</em> may be given by registered or 
      certified mail to the individual's address given in Item 1.</p>
      
      <p>I, the undersigned, sign this Form MA-I on behalf of, and with the authority of, 
      the <em>municipal advisory firm</em> that is filing this form.  The 
      <em>municipal advisory firm</em> and I both certify, under penalty of perjury under 
      the laws of the United States of America, that the information and statements made 
      in this Form MA-I, including exhibits and any other information submitted, are true 
      and correct, and that I am signing this Form MA-I as a 
      free and voluntary act.</p>
	      
      <div class="form1">
	   <div class="mainDiv2" style="margin-left:0; margin-right:0;">
		<div class="tableRow">
			<div class="tdStyle1 tdCrmCol1">
			<strong>Date:</strong>
			</div>
			<div class="tdStyle1 tdCrmCol2Textbox"> 						
				<xsl:value-of select="n2:signatureInfo/ns2:signature/ns2:dateSigned" />
			</div>
		</div>
		<div style="clear:both"></div>
	    <div class="tableRow">
			<div class="tdStyle1 tdCrmCol1">
			<strong> By  (signature):</strong>
			</div>
			<div class="tdStyle1 tdCrmCol2Textbox"> 						
				<xsl:value-of select="n2:signatureInfo/ns2:signature/ns2:signature" />
			</div>
		</div>
		<div style="clear:both"></div>
        <div class="tableRow">
			<div class="tdStyle1 tdCrmCol1">
			<strong> Title: </strong>
			</div>
			<div class="tdStyle1 tdCrmCol2Textbox"> 						
				<xsl:value-of select="n2:signatureInfo/ns2:signature/ns2:title" />
			</div>
		</div>    
		<div style="clear:both"></div>		
		</div>
		
        <h3>B. For Natural Person <em>Municipal Advisors</em> (Sole Proprietors) filing this form:</h3>
        
        <p>The individual named below consents that service of any civil action brought by, or 
        notice of any <em>proceeding</em> before, the <em>SEC</em> or any 
        <em>self-regulatory organization</em> in connection with the individual's 
        <em>municipal advisory activities</em> may be given by registered or certified mail to 
        the individual's address given in Item 1.</p>

        <p>I, the undersigned, certify, under penalty of perjury under the laws of the 
        United States of America, that the information and statements made in this Form MA-I, 
        including exhibits and any other information submitted, are true and correct, 
        and that I am signing this Form MA-I Execution Page as a free and voluntary act.</p>
		
		<div class="mainDiv2" style="margin-left:0; margin-right:0;">
		<div class="tableRow">
			<div class="tdStyle1 tdCrmCol1">
			<strong>Date:</strong>
			</div>
			<div class="tdStyle1 tdCrmCol2Textbox"> 						
				<xsl:value-of select="n2:selfCertification/ns2:signature/ns2:dateSigned" />
			</div>
		</div> 
		</div>

        <p><strong>Full Legal Name of <em>Municipal Advisor:</em></strong>
        
        <br />Enter all the letters of each name and not initials or other abbreviations. 
        If no middle name, enter NMN on that line.
        </p>
		
		<div class="mainDiv2" style="margin-left:0; margin-right:0;">
		<div class="tableRow">
			<div class="tdStyle1 tdCrmCol1">
			<strong>Last Name:</strong>
			</div>
			<div class="tdStyle1 tdCrmCol2Textbox"> 						
				<xsl:value-of select="n2:selfCertification/ns2:signature/ns2:nameOfApplicant/ns2:lastName" />
			</div>
		</div>
		<div style="clear:both"></div>
		<div class="tableRow">
			<div class="tdStyle1 tdCrmCol1">
			<strong>First Name:</strong>
			</div>
			<div class="tdStyle1 tdCrmCol2Textbox"> 						
				<xsl:value-of select="n2:selfCertification/ns2:signature/ns2:nameOfApplicant/ns2:firstName" />
			</div>
		</div>
		<div style="clear:both"></div>
		<div class="tableRow">
			<div class="tdStyle1 tdCrmCol1">
			<strong>Middle Name:</strong>
			</div>
			<div class="tdStyle1 tdCrmCol2Textbox"> 						
				<xsl:value-of select="n2:selfCertification/ns2:signature/ns2:nameOfApplicant/ns2:middleName" />
			</div>
		</div>
		<div style="clear:both"></div>
		<div class="tableRow">
			<div class="tdStyle1 tdCrmCol1">
			<strong>Suffix:</strong>
			</div>
			<div class="tdStyle1 tdCrmCol2Textbox"> 						
				<xsl:value-of select="n2:selfCertification/ns2:signature/ns2:nameOfApplicant/ns2:suffix" />
			</div>
		</div>
		<div style="clear:both"></div>
		<div class="tableRow">
			<div class="tdStyle1 tdCrmCol1">
			<strong>Individual <em>CRD</em> No. (if any):</strong>
			</div>
			<div class="tdStyle1 tdCrmCol2Textbox"> 						
				<xsl:call-template name="CRDFormatting">
					<xsl:with-param name="CRD" select="n2:selfCertification/ns2:crdNumber" />
				</xsl:call-template> 
			</div>
		</div>
		<div style="clear:both"></div>
		<div class="tableRow">
			<div class="tdStyle1 tdCrmCol1">
			<strong> By (signature): </strong>
			</div>
			<div class="tdStyle1 tdCrmCol2Textbox"> 						
				<xsl:value-of select="n2:selfCertification/ns2:signature/ns2:signature" />
			</div>
		</div>	
		<div style="clear:both"></div>
        </div>
        <p>Warning: Intentional misstatements or omissions of fact constitute Federal criminal violations. See 18 U.S.C. 1001 and 15 U.S.C. 78ff(a).12. </p>
      </div>
    </div>
  </div>
</div>
		
	</xsl:template>

</xsl:stylesheet>
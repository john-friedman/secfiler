<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE xsl:stylesheet [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet
	version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:p="http://www.sec.gov/edgar/ta/tawfiler"
	xmlns:ns1="http://www.sec.gov/edgar/common"
	xmlns:n1="http://www.sec.gov/edgar/common_drp"
	xmlns:ns2="http://www.sec.gov/edgar/statecodes">
	<xsl:template name="Item5">
		<h3>
			Signature
		</h3>
		<xsl:call-template name="signature" />
	</xsl:template>

	<xsl:template  name="signature">
		
		<table role="presentation" >	
			<tr>
				SIGNATURE: The registrant submitting this Form and its attachments
					and the person executing it represent hereby that it and all
					materials filed in connection therewith contain a true, correct and
					complete statement of all required information. Registrant also
					consents hereby to make the books and records it is required to
					preserver by Rules 17A d-6 and 7 under the Securities Exchange Act of
					1934 (17 CFR 240.17A d-6 and 7) available for examination by
					authorized representatives of the Securities and Exchange Commission
					during the period the rules require registrant to preserve such books
					and records and hereby authorizes the person having custody of such
					books and records to make them available to such representatives.
			</tr>
			<tr>
				<td class="label">	
					<b>13(a).</b> Signature of Official responsible for Form: 						
				</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="p:formData/p:signatureData/p:signatureName"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">	
					<b>13(b).</b> Telephone Number: 						
				</td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="p:formData/p:signatureData/p:signaturePhoneNumber"/>
					</div>
				</td>
			</tr>  
			<tr>
				<td class="label">	
					<b>13(c).</b> Title of Signing Officer: 						
				</td>
				<td>
					<div class="fakeBox3">
						<xsl:value-of select="p:formData/p:signatureData/p:signatureTitle"/>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">	
					<b>13(d).</b> Date Signed (Month/Day/Year):					
				</td>
				<td>
					<div class="fakeBox2">
						<xsl:value-of select="p:formData/p:signatureData/p:signatureDate"/>
					</div>
				</td>
			</tr>									      
      </table>
	
	</xsl:template>
</xsl:stylesheet>
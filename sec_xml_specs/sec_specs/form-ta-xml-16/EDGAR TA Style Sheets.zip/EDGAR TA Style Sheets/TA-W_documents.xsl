<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE xsl:stylesheet [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:p="http://www.sec.gov/edgar/ta/tawfiler"	xmlns:ns1="http://www.sec.gov/edgar/common" xmlns:n1="http://www.sec.gov/edgar/common_drp"
	xmlns:ns2="http://www.sec.gov/edgar/statecodes">
	
	
		<xsl:template name="Documents">
		<h3>
			<em>Documents</em>
		</h3>
		<xsl:call-template name="TA-W_Documents"/>
	</xsl:template>
	
	<xsl:template name="TA-W_Documents">
		<table>
			<tr>
				<td class="label">FILE NAME
				</td>
				<td>
					<div class="fakeBox">
						<xsl:value-of select="string(ns1:conformedName)" />
						<span>
							<xsl:text>&#160;</xsl:text>
						</span>
					</div>
				</td>
			</tr>
			<tr>
                <td class="label">TYPE
                </td>
                <td>
                    <div class="fakeBox">
                        <xsl:value-of select="string(ns1:conformedDocumentType)" />
                        <span>
                            <xsl:text>&#160;</xsl:text>
                        </span>
                    </div>
                </td>
            </tr>
            <tr>
                <td class="label">DESCRIPTION
                </td>
                <td>
                    <div class="fakeBox">
                        <xsl:value-of select="string(ns1:description)" />
                        <span>
                            <xsl:text>&#160;</xsl:text>
                        </span>
                    </div>
                </td>
            </tr>	
            <tr>
                <td class="label">Content
                </td>
                <td>
                    <div class="fakeBox">
                        <xsl:value-of select="string(ns1:contents)" />
                        <span>
                            <xsl:text>&#160;</xsl:text>
                        </span>
                    </div>
                </td>
            </tr>	            
	</table>
	</xsl:template>
	
</xsl:stylesheet>	
<!DOCTYPE xsl:stylesheet  [
<!ENTITY ndash "&#8211;">
]>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xmlns:ta1="http://www.sec.gov/edgar/ta/taonefiler">

	<xsl:template name="item4_signature" match="ta1:signatureInfo">
		<h1>
			<xsl:value-of select="$submissionType" />
			: Signature
		</h1>
      <p></p>      
						ATTENTION: INTENTIONAL MISSTATEMENTS OR OMISSIONS
						OF FACT CONSTITUTE FEDERAL
						CRIMINAL VIOLATIONS. See 18 U.S.C. 1001
						and 15 U.S.C. 78ff(a)
      <p></p> 
						SIGNATURE: The registrant submitting this form,
						and as required, the SEC
						supplement and Schedules A-D,
						And the
						executing official hereby represent that all the information
						contained herein is true, correct and complete.
		<p></p>				

		<table role="presentation" class="independentRegistrant">
			<tr>
				<td class="label">
					<font face="Times New Roman">
						<b>11(a). </b>
					</font>
					Signature of Official responsible for Form:
				</td>
				<td>
					<div class="fakeBox">
						<xsl:call-template name="stateDescription">
							<xsl:with-param name="stateCode" select="ta1:formData/ta1:signature/ta1:signatureName" />
						</xsl:call-template>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">
					<font face="Times New Roman">
						<b>11(b). </b>
					</font>
					Telephone Number:
				</td>
				<td>
					<div class="fakeBox2">
						<xsl:call-template name="stateDescription">
							<xsl:with-param name="stateCode" select="ta1:formData/ta1:signature/ta1:signaturePhoneNumber" />
						</xsl:call-template>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">
					<font face="Times New Roman">
						<b>11(c). </b>
					</font>
					Title of Signing Officer:
				</td>
				<td>
					<div class="fakeBox">
						<xsl:call-template name="stateDescription">
							<xsl:with-param name="stateCode" select="ta1:formData/ta1:signature/ta1:signatureTitle" />
						</xsl:call-template>
					</div>
				</td>
			</tr>
			<tr>
				<td class="label">
					<font face="Times New Roman">
						<b>11(d). </b>
					</font>
					Date Signed (Month/Day/Year):
				</td>
				<td>
					<div class="fakeBox2">
						<xsl:call-template name="stateDescription">
							<xsl:with-param name="stateCode" select="ta1:formData/ta1:signature/ta1:signatureDate" />
						</xsl:call-template>
					</div>
				</td>
			</tr>
		</table>
	</xsl:template>
</xsl:stylesheet>